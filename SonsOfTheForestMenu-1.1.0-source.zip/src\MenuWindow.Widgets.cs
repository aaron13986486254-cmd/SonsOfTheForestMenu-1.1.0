// ═══════════════════════════════════════════════════════════════════════════
//  MenuWindow.Widgets.cs · reusable drawing primitives and icons
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using Il2CppInterop.Runtime.Attributes;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// Reusable drawing primitives shared by the tab bodies: section headers,
    /// lede text, on/off switches, and the data-driven renderers over the
    /// game's console commands (switches / actions / value fields / setup
    /// rows). All of these are pure presentation — they read feature state,
    /// draw, and write back only what the user changed.
    /// </summary>
    public partial class MenuWindow
    {
        // values for numeric-argument commands, keyed by group+index
        readonly System.Collections.Generic.Dictionary<string, string> _fieldValues =
            new System.Collections.Generic.Dictionary<string, string>();

        // ── section-header icons ────────────────────────────────────────
        // Icons are authored on a 48×48 canvas and drawn into a small on-screen
        // slot, so the bilinear downsample smooths whatever the 3×3 coverage
        // sampling in each primitive leaves behind. Colour is baked into the
        // texture rather than applied with GUI.color, which is what lets a
        // single icon carry two or three tones — a rust apple with an olive
        // leaf reads at 18px where a flat silhouette does not.
        //
        // Authoring coordinates are TOP-DOWN (y = 0 is the top of the icon),
        // because that is how the shapes are easiest to read and edit. Texture2D
        // row 0 is the BOTTOM of the texture, so BuildIcon flips the rows on
        // upload — the same correction Theme.RoundTexture makes for its corner
        // cutouts. Without it every icon renders upside down.
        static readonly Dictionary<string, System.Action<Color32[]>> SectionIcons = new()
        {
            // ── player / survival ───────────────────────────────────────
            ["SURVIVAL"]              = HeartIcon,
            ["NEEDS"]                 = AppleIcon,
            ["STATUS EFFECTS"]        = LightningIcon,
            ["GAME CHEATS"]           = GamepadIcon,

            // ── generic command groups ──────────────────────────────────
            ["ACTIONS"]               = PlayIcon,
            ["VALUES"]                = HashIcon,

            // ── combat ──────────────────────────────────────────────────
            ["WEAPONS"]               = BladesIcon,
            ["COMBAT TUNING"]         = SlidersIcon,
            ["ENEMIES"]               = SkullIcon,
            ["AREA EFFECTS"]          = BlastIcon,
            ["ENEMY TUNING"]          = GaugeIcon,
            ["CLEANUP"]               = BroomIcon,

            // ── world ───────────────────────────────────────────────────
            ["CONSTRUCTION"]          = HammerIcon,
            ["SEASON"]                = LeafIcon,
            ["WORLD CHEATS"]          = GlobeBoltIcon,
            ["TIME & WEATHER"]        = ClockIcon,
            ["GAME SETUP — WORLD"]    = GearIcon,
            ["GAME SETUP — SURVIVAL"] = FlameIcon,
            ["WORLD ACTIONS"]         = GlobeIcon,

            // ── engine cheats ───────────────────────────────────────────
            ["ENGINE CHEATS"]         = CogRustIcon,
            ["WATER"]                 = DropletIcon,
            ["ARMOUR"]                = ShieldIcon,
            ["ACHIEVEMENTS"]          = TrophyIcon,
            ["WORLD SIMULATION"]      = AtomIcon,

            // ── gear ────────────────────────────────────────────────────
            ["HANG GLIDER"]           = GliderIcon,
            ["KNIGHT V"]              = BuggyIcon,
            ["FLASHLIGHT"]            = TorchIcon,
            ["REBREATHER"]            = MaskIcon,

            // ── vision ──────────────────────────────────────────────────
            ["ACTORS"]                = PersonIcon,
            ["ITEM ESP"]              = EyeCrateIcon,
            ["RANGE & RADAR"]         = RadarIcon,
            ["OVERLAYS"]              = LayersIcon,

            // ── movement ────────────────────────────────────────────────
            ["ON FOOT"]               = BootIcon,
            ["GAME MOVEMENT CHEATS"]  = SprintIcon,
            ["FLIGHT"]                = UpdraftIcon,
            ["TELEPORT & CAMERA"]     = PinIcon,
            ["SAVED SPOTS"]           = BookmarkIcon,
            ["NAMED LOCATIONS (WIKI)"]= FoldedMapIcon,

            // ── spawn ───────────────────────────────────────────────────
            ["ITEMS"]                 = CrateIcon,
            ["COMPANIONS & STORY"]    = CompanionsIcon,
            ["MUTANTS & CANNIBALS"]   = BiohazardIcon,
            ["ANIMALS"]               = PawIcon,
            ["PREFABS (BOLT)"]        = CubeIcon,
            ["CUTSCENES"]             = ClapperIcon,

            // ── online ──────────────────────────────────────────────────
            ["ROSTER"]                = RosterIcon,
            ["SESSION"]               = LinkIcon,
            ["TARGETED"]              = CrosshairIcon,
            ["NETWORK DEBUG"]         = AntennaIcon,

            // ── console ─────────────────────────────────────────────────
            ["COMMON (WIKI)"]         = BookIcon,
            ["RUN"]                   = TerminalIcon,
            ["RECENT"]                = HistoryIcon,
            ["ALL COMMANDS"]          = ListIcon,

            // ── settings ────────────────────────────────────────────────
            ["STEAM API KEY"]         = KeyIcon,
            ["APPEARANCE"]            = PaletteIcon,
            ["SCROLLING"]             = MouseIcon,
        };

        // ── raster canvas ────────────────────────────────────────────────
        /// <summary>Authoring resolution. Downsampled to IconS when drawn.</summary>
        const int IconRes = 48;
        /// <summary>On-screen icon size, shared with the season chips.</summary>
        const int IconS = 16;
        /// <summary>Coverage samples per axis. 3×3 = 9 levels of edge alpha.</summary>
        const int IconSub = 3;

        /// <summary>Lightens a palette colour towards bone, for highlights.</summary>
        static Color Lift(Color c, float t) => Color.Lerp(c, Theme.IconBone, t);

        /// <summary>Darkens a palette colour towards ink, for shading.</summary>
        static Color Shade(Color c, float t) => Color.Lerp(c, Theme.Ink, t);

        /// <summary>
        /// Source-over composite of one coverage sample onto the canvas. Shapes
        /// are drawn back-to-front and blend properly at their edges, so a
        /// highlight laid over a body does not leave a hard seam.
        /// </summary>
        static void Plot(Color32[] p, int x, int y, Color c, float a)
        {
            if (a <= 0f) return;
            if ((uint)x >= IconRes || (uint)y >= IconRes) return;
            if (a > 1f) a = 1f;

            int i = y * IconRes + x;
            Color32 dst = p[i];
            float da = dst.a / 255f;
            float outA = a + da * (1f - a);
            if (outA <= 0.0001f) { p[i] = new Color32(0, 0, 0, 0); return; }

            float r = (c.r * a + (dst.r / 255f) * da * (1f - a)) / outA;
            float g = (c.g * a + (dst.g / 255f) * da * (1f - a)) / outA;
            float b = (c.b * a + (dst.b / 255f) * da * (1f - a)) / outA;
            p[i] = new Color32((byte)(Mathf.Clamp01(r) * 255f),
                               (byte)(Mathf.Clamp01(g) * 255f),
                               (byte)(Mathf.Clamp01(b) * 255f),
                               (byte)(Mathf.Clamp01(outA) * 255f));
        }

        /// <summary>
        /// Fills every pixel in the bounding box whose sub-samples fall inside
        /// the shape. Runs once per icon at first use and the result is cached,
        /// so the per-sample delegate call is not on any hot path.
        /// </summary>
        static void Raster(Color32[] p, float x0, float y0, float x1, float y1,
                           Func<float, float, bool> inside, Color c)
        {
            int ix0 = Mathf.Max(0, Mathf.FloorToInt(x0));
            int iy0 = Mathf.Max(0, Mathf.FloorToInt(y0));
            int ix1 = Mathf.Min(IconRes - 1, Mathf.CeilToInt(x1));
            int iy1 = Mathf.Min(IconRes - 1, Mathf.CeilToInt(y1));

            const float step = 1f / IconSub;
            const float half = step * 0.5f;
            const float total = IconSub * IconSub;

            for (int y = iy0; y <= iy1; y++)
            {
                for (int x = ix0; x <= ix1; x++)
                {
                    int hits = 0;
                    for (int sy = 0; sy < IconSub; sy++)
                        for (int sx = 0; sx < IconSub; sx++)
                            if (inside(x + sx * step + half, y + sy * step + half))
                                hits++;
                    if (hits > 0) Plot(p, x, y, c, hits / total);
                }
            }
        }

        // ── shape primitives (all take top-down coordinates) ─────────────

        static void Disc(Color32[] p, float cx, float cy, float r, Color c)
        {
            Raster(p, cx - r - 1f, cy - r - 1f, cx + r + 1f, cy + r + 1f,
                   (x, y) => (x - cx) * (x - cx) + (y - cy) * (y - cy) <= r * r, c);
        }

        static void Ring(Color32[] p, float cx, float cy, float ro, float ri, Color c)
        {
            Raster(p, cx - ro - 1f, cy - ro - 1f, cx + ro + 1f, cy + ro + 1f,
                   (x, y) =>
                   {
                       float d2 = (x - cx) * (x - cx) + (y - cy) * (y - cy);
                       return d2 <= ro * ro && d2 >= ri * ri;
                   }, c);
        }

        /// <summary>Ring segment between two angles, degrees, 0 = east, clockwise.</summary>
        static void Arc(Color32[] p, float cx, float cy, float ro, float ri,
                        float from, float to, Color c)
        {
            Raster(p, cx - ro - 1f, cy - ro - 1f, cx + ro + 1f, cy + ro + 1f,
                   (x, y) =>
                   {
                       float dx = x - cx, dy = y - cy;
                       float d2 = dx * dx + dy * dy;
                       if (d2 > ro * ro || d2 < ri * ri) return false;
                       float a = Mathf.Atan2(dy, dx) * Mathf.Rad2Deg;
                       if (a < 0f) a += 360f;
                       return from <= to ? (a >= from && a <= to)
                                         : (a >= from || a <= to);
                   }, c);
        }

        static void Box(Color32[] p, float x0, float y0, float x1, float y1, Color c)
        {
            Raster(p, x0, y0, x1, y1,
                   (x, y) => x >= x0 && x <= x1 && y >= y0 && y <= y1, c);
        }

        static void RBox(Color32[] p, float x0, float y0, float x1, float y1,
                         float rad, Color c)
        {
            Raster(p, x0, y0, x1, y1, (x, y) =>
            {
                if (x < x0 || x > x1 || y < y0 || y > y1) return false;
                float qx = Mathf.Max(Mathf.Max(x0 + rad - x, 0f), Mathf.Max(x - (x1 - rad), 0f));
                float qy = Mathf.Max(Mathf.Max(y0 + rad - y, 0f), Mathf.Max(y - (y1 - rad), 0f));
                return qx * qx + qy * qy <= rad * rad;
            }, c);
        }

        /// <summary>Round-capped line of the given thickness.</summary>
        static void Stroke(Color32[] p, float ax, float ay, float bx, float by,
                           float thick, Color c)
        {
            float h = thick * 0.5f;
            float minX = Mathf.Min(ax, bx) - h - 1f, maxX = Mathf.Max(ax, bx) + h + 1f;
            float minY = Mathf.Min(ay, by) - h - 1f, maxY = Mathf.Max(ay, by) + h + 1f;
            float vx = bx - ax, vy = by - ay;
            float len2 = vx * vx + vy * vy;

            Raster(p, minX, minY, maxX, maxY, (x, y) =>
            {
                float t = len2 <= 0.0001f ? 0f
                        : Mathf.Clamp01(((x - ax) * vx + (y - ay) * vy) / len2);
                float dx = x - (ax + vx * t), dy = y - (ay + vy * t);
                return dx * dx + dy * dy <= h * h;
            }, c);
        }

        static void Tri(Color32[] p, float ax, float ay, float bx, float by,
                        float cx, float cy, Color col)
        {
            Poly(p, new[] { ax, ay, bx, by, cx, cy }, col);
        }

        /// <summary>Even-odd polygon fill. Points are a flat x,y,x,y… array.</summary>
        static void Poly(Color32[] p, float[] pts, Color c)
        {
            int n = pts.Length / 2;
            if (n < 3) return;

            float minX = pts[0], maxX = pts[0], minY = pts[1], maxY = pts[1];
            for (int i = 1; i < n; i++)
            {
                minX = Mathf.Min(minX, pts[i * 2]);     maxX = Mathf.Max(maxX, pts[i * 2]);
                minY = Mathf.Min(minY, pts[i * 2 + 1]); maxY = Mathf.Max(maxY, pts[i * 2 + 1]);
            }

            Raster(p, minX - 1f, minY - 1f, maxX + 1f, maxY + 1f, (x, y) =>
            {
                bool inside = false;
                for (int i = 0, j = n - 1; i < n; j = i++)
                {
                    float xi = pts[i * 2], yi = pts[i * 2 + 1];
                    float xj = pts[j * 2], yj = pts[j * 2 + 1];
                    if ((yi > y) != (yj > y) &&
                        x < (xj - xi) * (y - yi) / (yj - yi) + xi)
                        inside = !inside;
                }
                return inside;
            }, c);
        }

        /// <summary>
        /// Rasterises one icon and uploads it, flipping rows so the top-down
        /// authoring coordinates land the right way up (see the note above).
        /// </summary>
        static Texture2D BuildIcon(System.Action<Color32[]> draw)
        {
            var px = new Color32[IconRes * IconRes];
            draw(px);

            var flipped = new Color32[px.Length];
            for (int y = 0; y < IconRes; y++)
                Array.Copy(px, y * IconRes,
                           flipped, (IconRes - 1 - y) * IconRes, IconRes);

            var t = new Texture2D(IconRes, IconRes, TextureFormat.RGBA32, false);
            t.filterMode = FilterMode.Bilinear;
            t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.DontSave;
            t.SetPixels32(flipped);
            t.Apply();
            return t;
        }

        // ── individual icon shapes ───────────────────────────────────────
        // Each is drawn back-to-front: body, then shading, then highlight.

        /// <summary>SURVIVAL — vitality, not defence (ARMOUR owns the shield).</summary>
        static void HeartIcon(Color32[] p)
        {
            Disc(p, 16f, 18f, 9.5f, Theme.IconRust);
            Disc(p, 32f, 18f, 9.5f, Theme.IconRust);
            Tri(p, 6.8f, 20f, 41.2f, 20f, 24f, 42f, Theme.IconRust);
            Tri(p, 24f, 27f, 41f, 22f, 24f, 42f, Shade(Theme.IconRust, 0.22f));
            Disc(p, 15f, 14f, 3.4f, Lift(Theme.IconRust, 0.55f));
        }

        /// <summary>NEEDS — hunger, thirst, warmth, rest.</summary>
        static void AppleIcon(Color32[] p)
        {
            Disc(p, 17f, 28f, 11f, Theme.IconRust);
            Disc(p, 31f, 28f, 11f, Theme.IconRust);
            Box(p, 17f, 20f, 31f, 39f, Theme.IconRust);
            Disc(p, 33f, 31f, 9f, Shade(Theme.IconRust, 0.20f));
            Stroke(p, 24f, 19f, 26f, 8f, 2.6f, Theme.IconAmber);
            Poly(p, new[] { 27f, 12f, 38f, 6f, 39f, 14f, 29f, 17f }, Theme.IconOlive);
            Disc(p, 16f, 22f, 3.2f, Lift(Theme.IconRust, 0.6f));
        }

        /// <summary>GAME CHEATS — the game's own cheat flags, not our toggles.</summary>
        static void GamepadIcon(Color32[] p)
        {
            RBox(p, 4f, 17f, 44f, 36f, 9f, Theme.IconSlate);
            Disc(p, 12f, 34f, 8f, Theme.IconSlate);
            Disc(p, 36f, 34f, 8f, Theme.IconSlate);
            Box(p, 4f, 29f, 44f, 36f, Shade(Theme.IconSlate, 0.25f));
            // d-pad
            Box(p, 9f, 24f, 20f, 27f, Theme.IconBone);
            Box(p, 13f, 20f, 16f, 31f, Theme.IconBone);
            // face buttons — the colour is what says "game"
            Disc(p, 33f, 22f, 3.2f, Theme.IconRust);
            Disc(p, 39f, 26f, 3.2f, Theme.IconGold);
            Disc(p, 33f, 30f, 3.2f, Theme.IconOlive);
            Disc(p, 27f, 26f, 3.2f, Theme.IconSteel);
        }

        static void PlayIcon(Color32[] p)
        {
            Tri(p, 14f, 8f, 14f, 40f, 40f, 24f, Theme.IconOlive);
            Tri(p, 14f, 24f, 14f, 40f, 40f, 24f, Shade(Theme.IconOlive, 0.22f));
        }

        static void HashIcon(Color32[] p)
        {
            Stroke(p, 17f, 7f, 13f, 41f, 4.2f, Theme.IconGold);
            Stroke(p, 33f, 7f, 29f, 41f, 4.2f, Theme.IconGold);
            Stroke(p, 8f, 18f, 40f, 18f, 4.2f, Theme.IconAmber);
            Stroke(p, 7f, 31f, 39f, 31f, 4.2f, Theme.IconAmber);
        }

        static void LightningIcon(Color32[] p)
        {
            Poly(p, new[] { 28f, 4f, 13f, 27f, 22f, 27f, 18f, 44f, 35f, 20f, 26f, 20f },
                 Theme.IconGold);
            Poly(p, new[] { 28f, 4f, 13f, 27f, 22f, 27f, 22f, 20f }, Lift(Theme.IconGold, 0.4f));
        }

        static void BladesIcon(Color32[] p)
        {
            Stroke(p, 10f, 38f, 36f, 10f, 5f, Theme.IconBone);
            Stroke(p, 38f, 38f, 12f, 10f, 5f, Lift(Theme.IconAsh, 0.15f));
            Stroke(p, 7f, 41f, 15f, 33f, 5.5f, Theme.IconAmber);
            Stroke(p, 41f, 41f, 33f, 33f, 5.5f, Theme.IconAmber);
        }

        static void SlidersIcon(Color32[] p)
        {
            Stroke(p, 7f, 13f, 41f, 13f, 3.2f, Theme.IconSlate);
            Stroke(p, 7f, 24f, 41f, 24f, 3.2f, Theme.IconSlate);
            Stroke(p, 7f, 35f, 41f, 35f, 3.2f, Theme.IconSlate);
            Disc(p, 31f, 13f, 6f, Theme.IconSteel);
            Disc(p, 16f, 24f, 6f, Theme.IconSteel);
            Disc(p, 35f, 35f, 6f, Theme.IconSteel);
            Disc(p, 29.5f, 11.5f, 2.2f, Theme.IconSky);
            Disc(p, 14.5f, 22.5f, 2.2f, Theme.IconSky);
            Disc(p, 33.5f, 33.5f, 2.2f, Theme.IconSky);
        }

        static void SkullIcon(Color32[] p)
        {
            Disc(p, 24f, 20f, 15f, Theme.IconBone);
            Box(p, 15f, 20f, 33f, 32f, Theme.IconBone);
            Disc(p, 15f, 30f, 6f, Theme.IconBone);
            Disc(p, 33f, 30f, 6f, Theme.IconBone);
            Box(p, 18f, 33f, 30f, 41f, Theme.IconBone);
            Disc(p, 24f, 41f, 6f, Theme.IconBone);
            // sockets, nasal cavity, teeth gaps
            Disc(p, 17f, 20f, 5.4f, Shade(Theme.IconSlate, 0.62f));
            Disc(p, 31f, 20f, 5.4f, Shade(Theme.IconSlate, 0.62f));
            Tri(p, 24f, 26f, 20.5f, 33f, 27.5f, 33f, Shade(Theme.IconSlate, 0.62f));
            Box(p, 20f, 37f, 21.5f, 44f, Shade(Theme.IconSlate, 0.5f));
            Box(p, 26.5f, 37f, 28f, 44f, Shade(Theme.IconSlate, 0.5f));
        }

        static void BlastIcon(Color32[] p)
        {
            Ring(p, 24f, 24f, 21f, 17.5f, Shade(Theme.IconRust, 0.35f));
            Ring(p, 24f, 24f, 14f, 10.5f, Theme.IconRust);
            Disc(p, 24f, 24f, 6.5f, Theme.IconGold);
            Disc(p, 22f, 22f, 2.6f, Lift(Theme.IconGold, 0.55f));
        }

        static void GaugeIcon(Color32[] p)
        {
            Arc(p, 24f, 30f, 19f, 13f, 180f, 360f, Theme.IconSlate);
            Arc(p, 24f, 30f, 19f, 13f, 290f, 360f, Theme.IconRust);
            Stroke(p, 24f, 30f, 35f, 18f, 3.4f, Theme.IconBone);
            Disc(p, 24f, 30f, 4.2f, Theme.IconBone);
        }

        static void BroomIcon(Color32[] p)
        {
            Stroke(p, 31f, 5f, 20f, 25f, 3.6f, Theme.IconAmber);
            Poly(p, new[] { 13f, 26f, 27f, 26f, 33f, 43f, 8f, 43f }, Theme.IconOlive);
            Box(p, 12.5f, 26f, 27.5f, 31f, Theme.IconAmber);
            Stroke(p, 17f, 32f, 14f, 42f, 1.6f, Shade(Theme.IconOlive, 0.35f));
            Stroke(p, 22f, 32f, 21f, 42f, 1.6f, Shade(Theme.IconOlive, 0.35f));
            Stroke(p, 27f, 32f, 28f, 42f, 1.6f, Shade(Theme.IconOlive, 0.35f));
        }

        static void HammerIcon(Color32[] p)
        {
            Stroke(p, 26f, 18f, 13f, 42f, 4.4f, Theme.IconAmber);
            Poly(p, new[] { 20f, 6f, 42f, 12f, 39f, 22f, 17f, 16f }, Theme.IconAsh);
            Poly(p, new[] { 20f, 6f, 42f, 12f, 41f, 15f, 19f, 10f }, Lift(Theme.IconAsh, 0.35f));
        }

        static void LeafIcon(Color32[] p)
        {
            Poly(p, new[] { 40f, 7f, 41f, 22f, 31f, 37f, 15f, 41f, 8f, 33f,
                            12f, 18f, 26f, 9f }, Theme.IconOlive);
            Poly(p, new[] { 40f, 7f, 41f, 22f, 31f, 37f, 24f, 40f }, Theme.IconGold);
            Stroke(p, 39f, 8f, 12f, 40f, 2.2f, Shade(Theme.IconMoss, 0.25f));
            Stroke(p, 30f, 18f, 34f, 25f, 1.6f, Shade(Theme.IconMoss, 0.15f));
            Stroke(p, 22f, 27f, 26f, 34f, 1.6f, Shade(Theme.IconMoss, 0.15f));
        }

        static void GlobeIcon(Color32[] p)
        {
            Disc(p, 24f, 24f, 19f, Theme.IconSteel);
            Ring(p, 24f, 24f, 19f, 16.5f, Theme.IconSky);
            Stroke(p, 5.5f, 24f, 42.5f, 24f, 2.4f, Theme.IconSky);
            Ring(p, 24f, 24f, 9.5f, 7.1f, Theme.IconSky);
            Stroke(p, 24f, 5.5f, 24f, 42.5f, 2.4f, Theme.IconSky);
        }

        static void GlobeBoltIcon(Color32[] p)
        {
            GlobeIcon(p);
            Poly(p, new[] { 30f, 8f, 19f, 26f, 26f, 26f, 20f, 42f, 36f, 21f, 28f, 21f },
                 Theme.IconRust);
        }

        static void ClockIcon(Color32[] p)
        {
            Disc(p, 24f, 24f, 19f, Theme.IconBone);
            Ring(p, 24f, 24f, 19f, 15.5f, Theme.IconAsh);
            Stroke(p, 24f, 24f, 24f, 12f, 3f, Theme.IconRust);
            Stroke(p, 24f, 24f, 33f, 28f, 3f, Theme.IconEmber);
            Disc(p, 24f, 24f, 2.6f, Theme.IconSlate);
        }

        static void GearIcon(Color32[] p) => Cog(p, Theme.IconSteel, Theme.IconSky);
        static void CogRustIcon(Color32[] p) => Cog(p, Theme.IconRust, Theme.IconGold);

        /// <summary>Shared cog body — GAME SETUP and ENGINE CHEATS differ by hue.</summary>
        static void Cog(Color32[] p, Color body, Color core)
        {
            for (int i = 0; i < 8; i++)
            {
                float a = i * Mathf.PI / 4f;
                float cs = Mathf.Cos(a), sn = Mathf.Sin(a);
                Stroke(p, 24f + cs * 12f, 24f + sn * 12f,
                          24f + cs * 20f, 24f + sn * 20f, 7f, body);
            }
            Disc(p, 24f, 24f, 15f, body);
            Disc(p, 24f, 24f, 7f, Shade(body, 0.55f));
            Ring(p, 24f, 24f, 7f, 5f, core);
        }

        static void FlameIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 4f, 34f, 18f, 33f, 27f, 38f, 24f, 39f, 34f,
                            24f, 44f, 9f, 34f, 12f, 21f, 17f, 25f, 16f, 15f },
                 Theme.IconRust);
            Poly(p, new[] { 24f, 17f, 31f, 29f, 28f, 40f, 18f, 39f, 16f, 29f },
                 Theme.IconGold);
            Disc(p, 24f, 35f, 4f, Lift(Theme.IconGold, 0.5f));
        }

        static void DropletIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 4f, 36f, 24f, 38f, 31f, 24f, 44f, 10f, 31f, 12f, 24f },
                 Theme.IconSteel);
            Disc(p, 24f, 31f, 12f, Theme.IconSteel);
            Disc(p, 19f, 30f, 4.2f, Theme.IconSky);
            Stroke(p, 16f, 24f, 15f, 30f, 2.4f, Theme.IconSky);
        }

        static void ShieldIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 4f, 41f, 10f, 41f, 24f, 36f, 34f, 24f, 44f,
                            12f, 34f, 7f, 24f, 7f, 10f }, Theme.IconBone);
            Poly(p, new[] { 24f, 4f, 41f, 10f, 41f, 24f, 36f, 34f, 24f, 44f },
                 Shade(Theme.IconBone, 0.18f));
            Poly(p, new[] { 24f, 13f, 34f, 20f, 34f, 26f, 24f, 19f, 14f, 26f, 14f, 20f },
                 Theme.IconRust);
        }

        static void TrophyIcon(Color32[] p)
        {
            Poly(p, new[] { 14f, 6f, 34f, 6f, 32f, 24f, 24f, 30f, 16f, 24f },
                 Theme.IconGold);
            Ring(p, 11f, 13f, 6.5f, 4.2f, Theme.IconAmber);
            Ring(p, 37f, 13f, 6.5f, 4.2f, Theme.IconAmber);
            Box(p, 21.5f, 29f, 26.5f, 36f, Theme.IconAmber);
            RBox(p, 13f, 36f, 35f, 42f, 2f, Theme.IconGold);
            Stroke(p, 19f, 9f, 19f, 22f, 2.6f, Lift(Theme.IconGold, 0.5f));
        }

        static void AtomIcon(Color32[] p)
        {
            Ring(p, 24f, 24f, 19f, 16f, Theme.IconSteel);
            Raster(p, 4f, 4f, 44f, 44f, (x, y) =>
            {
                // two ellipses rotated ±45°, drawn as a thin annulus each
                float dx = x - 24f, dy = y - 24f;
                float u = (dx + dy) * 0.7071f, v = (dx - dy) * 0.7071f;
                float e1 = (u * u) / (19f * 19f) + (v * v) / (8f * 8f);
                float e2 = (v * v) / (19f * 19f) + (u * u) / (8f * 8f);
                return (e1 <= 1f && e1 >= 0.55f) || (e2 <= 1f && e2 >= 0.55f);
            }, Theme.IconSky);
            Disc(p, 24f, 24f, 5f, Theme.IconRust);
        }

        static void GliderIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 10f, 45f, 26f, 26f, 24f }, Theme.IconBone);
            Poly(p, new[] { 24f, 10f, 3f, 26f, 22f, 24f }, Shade(Theme.IconBone, 0.2f));
            Stroke(p, 24f, 10f, 24f, 30f, 2f, Theme.IconAsh);
            Disc(p, 24f, 34f, 5f, Theme.IconRust);
            Stroke(p, 24f, 30f, 24f, 31f, 2f, Theme.IconAsh);
        }

        static void BuggyIcon(Color32[] p)
        {
            Poly(p, new[] { 8f, 30f, 14f, 18f, 30f, 18f, 38f, 27f, 42f, 30f, 42f, 34f,
                            8f, 34f }, Theme.IconRust);
            Poly(p, new[] { 16f, 20f, 29f, 20f, 34f, 27f, 16f, 27f },
                 Shade(Theme.IconSteel, 0.25f));
            Ring(p, 15f, 36f, 7f, 3.2f, Theme.IconSlate);
            Ring(p, 35f, 36f, 7f, 3.2f, Theme.IconSlate);
            Disc(p, 41f, 28f, 2.6f, Theme.IconGold);
        }

        static void TorchIcon(Color32[] p)
        {
            RBox(p, 8f, 17f, 22f, 31f, 3f, Theme.IconSlate);
            Box(p, 22f, 19f, 27f, 29f, Theme.IconAsh);
            Poly(p, new[] { 27f, 12f, 44f, 6f, 44f, 42f, 27f, 36f }, Theme.IconGold);
            Poly(p, new[] { 27f, 17f, 44f, 14f, 44f, 34f, 27f, 31f },
                 Lift(Theme.IconGold, 0.45f));
            Disc(p, 12f, 24f, 2.4f, Theme.IconRust);
        }

        static void MaskIcon(Color32[] p)
        {
            RBox(p, 9f, 12f, 39f, 34f, 11f, Theme.IconSteel);
            Disc(p, 18f, 22f, 5.4f, Shade(Theme.IconSlate, 0.55f));
            Disc(p, 30f, 22f, 5.4f, Shade(Theme.IconSlate, 0.55f));
            Disc(p, 16.5f, 20.5f, 2f, Theme.IconSky);
            Disc(p, 28.5f, 20.5f, 2f, Theme.IconSky);
            RBox(p, 18f, 34f, 30f, 43f, 4f, Theme.IconSlate);
            Stroke(p, 24f, 34f, 24f, 43f, 2f, Shade(Theme.IconSlate, 0.4f));
        }

        static void PersonIcon(Color32[] p)
        {
            Disc(p, 24f, 13f, 7.5f, Theme.IconBone);
            Poly(p, new[] { 24f, 22f, 37f, 33f, 37f, 43f, 11f, 43f, 11f, 33f },
                 Theme.IconAsh);
        }

        static void EyeCrateIcon(Color32[] p)
        {
            // eye
            Raster(p, 2f, 8f, 46f, 32f, (x, y) =>
            {
                float dx = (x - 23f) / 21f, dy = (y - 20f) / 11f;
                return dx * dx + dy * dy <= 1f;
            }, Theme.IconBone);
            Disc(p, 23f, 20f, 8f, Theme.IconOlive);
            Disc(p, 23f, 20f, 4f, Shade(Theme.IconMoss, 0.7f));
            Disc(p, 20.5f, 17.5f, 2.2f, Theme.IconBone);
            // crate, lower right
            RBox(p, 27f, 30f, 45f, 45f, 2f, Theme.IconAmber);
            Stroke(p, 27f, 35f, 45f, 35f, 2f, Shade(Theme.IconAmber, 0.4f));
            Stroke(p, 36f, 30f, 36f, 45f, 2f, Shade(Theme.IconAmber, 0.4f));
        }

        static void RadarIcon(Color32[] p)
        {
            Ring(p, 24f, 24f, 20f, 17.5f, Theme.IconMoss);
            Ring(p, 24f, 24f, 12f, 10f, Theme.IconMoss);
            Arc(p, 24f, 24f, 17.5f, 0f, 270f, 340f, Shade(Theme.IconOlive, 0.45f));
            Stroke(p, 24f, 24f, 24f, 6f, 2.4f, Theme.IconOlive);
            Stroke(p, 24f, 24f, 39f, 15f, 2.4f, Theme.IconOlive);
            Disc(p, 32f, 31f, 3.2f, Theme.IconRust);
            Disc(p, 16f, 30f, 2.6f, Theme.IconGold);
        }

        static void LayersIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 30f, 43f, 38f, 24f, 45f, 5f, 38f },
                 Shade(Theme.IconSteel, 0.4f));
            Poly(p, new[] { 24f, 19f, 43f, 27f, 24f, 34f, 5f, 27f }, Theme.IconSteel);
            Poly(p, new[] { 24f, 8f, 43f, 16f, 24f, 23f, 5f, 16f }, Theme.IconSky);
        }

        static void BootIcon(Color32[] p)
        {
            Poly(p, new[] { 13f, 6f, 25f, 6f, 27f, 26f, 41f, 32f, 41f, 40f, 13f, 40f },
                 Theme.IconAsh);
            Box(p, 12f, 39f, 42f, 44f, Theme.IconSlate);
            Stroke(p, 14f, 13f, 24f, 13f, 2f, Shade(Theme.IconAsh, 0.35f));
            Stroke(p, 14f, 20f, 25f, 20f, 2f, Shade(Theme.IconAsh, 0.35f));
        }

        static void SprintIcon(Color32[] p)
        {
            Disc(p, 30f, 10f, 5.5f, Theme.IconGold);
            Stroke(p, 28f, 17f, 22f, 28f, 4.4f, Theme.IconGold);
            Stroke(p, 22f, 28f, 28f, 41f, 4.2f, Theme.IconGold);
            Stroke(p, 25f, 26f, 15f, 34f, 4.2f, Theme.IconGold);
            Stroke(p, 27f, 20f, 38f, 24f, 4f, Theme.IconAmber);
            Stroke(p, 3f, 16f, 15f, 16f, 2.6f, Theme.IconAmber);
            Stroke(p, 5f, 24f, 14f, 24f, 2.6f, Theme.IconAmber);
        }

        static void UpdraftIcon(Color32[] p)
        {
            Poly(p, new[] { 44f, 12f, 30f, 30f, 8f, 30f, 22f, 12f }, Theme.IconSky);
            Poly(p, new[] { 44f, 12f, 30f, 30f, 20f, 30f }, Theme.IconSteel);
            Stroke(p, 12f, 38f, 24f, 38f, 2.6f, Theme.IconSteel);
            Stroke(p, 20f, 44f, 34f, 44f, 2.6f, Theme.IconSteel);
        }

        static void PinIcon(Color32[] p)
        {
            Disc(p, 24f, 18f, 13f, Theme.IconRust);
            Tri(p, 13f, 25f, 35f, 25f, 24f, 45f, Theme.IconRust);
            Tri(p, 24f, 25f, 35f, 25f, 24f, 45f, Shade(Theme.IconRust, 0.25f));
            Disc(p, 24f, 18f, 5.5f, Theme.IconBone);
        }

        static void BookmarkIcon(Color32[] p)
        {
            Poly(p, new[] { 11f, 4f, 37f, 4f, 37f, 44f, 24f, 33f, 11f, 44f },
                 Theme.IconGold);
            Poly(p, new[] { 24f, 4f, 37f, 4f, 37f, 44f, 24f, 33f },
                 Shade(Theme.IconGold, 0.25f));
        }

        static void FoldedMapIcon(Color32[] p)
        {
            Poly(p, new[] { 3f, 11f, 17f, 6f, 17f, 38f, 3f, 43f }, Theme.IconBone);
            Poly(p, new[] { 17f, 6f, 31f, 11f, 31f, 43f, 17f, 38f },
                 Shade(Theme.IconBone, 0.2f));
            Poly(p, new[] { 31f, 11f, 45f, 6f, 45f, 38f, 31f, 43f }, Theme.IconBone);
            Stroke(p, 8f, 32f, 22f, 20f, 2.2f, Theme.IconOlive);
            Stroke(p, 22f, 20f, 38f, 26f, 2.2f, Theme.IconOlive);
            Disc(p, 38f, 26f, 3.6f, Theme.IconRust);
        }

        static void CrateIcon(Color32[] p)
        {
            RBox(p, 6f, 12f, 42f, 42f, 2.5f, Theme.IconAmber);
            Box(p, 6f, 12f, 42f, 19f, Theme.IconGold);
            Stroke(p, 8f, 22f, 40f, 40f, 3f, Shade(Theme.IconAmber, 0.4f));
            Stroke(p, 40f, 22f, 8f, 40f, 3f, Shade(Theme.IconAmber, 0.4f));
        }

        static void CompanionsIcon(Color32[] p)
        {
            Disc(p, 32f, 16f, 7f, Theme.IconBone);
            Poly(p, new[] { 32f, 24f, 45f, 33f, 45f, 43f, 19f, 43f, 19f, 33f },
                 Shade(Theme.IconBone, 0.2f));
            Disc(p, 16f, 15f, 8f, Theme.IconOlive);
            Poly(p, new[] { 16f, 24f, 30f, 34f, 30f, 44f, 2f, 44f, 2f, 34f },
                 Theme.IconMoss);
        }

        static void BiohazardIcon(Color32[] p)
        {
            for (int i = 0; i < 3; i++)
            {
                float a = -Mathf.PI / 2f + i * 2f * Mathf.PI / 3f;
                float cx = 24f + Mathf.Cos(a) * 11f;
                float cy = 24f + Mathf.Sin(a) * 11f;
                Ring(p, cx, cy, 10.5f, 6f, Theme.IconBlood);
            }
            Disc(p, 24f, 24f, 8.5f, Theme.Ink);
            Disc(p, 24f, 24f, 5.5f, Theme.IconBlood);
        }

        static void PawIcon(Color32[] p)
        {
            Disc(p, 24f, 32f, 11f, Theme.IconOlive);
            Disc(p, 12f, 20f, 5.5f, Theme.IconOlive);
            Disc(p, 20f, 12f, 5.5f, Theme.IconOlive);
            Disc(p, 29f, 12f, 5.5f, Theme.IconOlive);
            Disc(p, 37f, 20f, 5.5f, Theme.IconOlive);
            Disc(p, 21f, 29f, 4f, Shade(Theme.IconMoss, 0.2f));
        }

        static void CubeIcon(Color32[] p)
        {
            Poly(p, new[] { 24f, 4f, 43f, 15f, 24f, 26f, 5f, 15f }, Theme.IconSky);
            Poly(p, new[] { 5f, 15f, 24f, 26f, 24f, 45f, 5f, 34f }, Theme.IconSteel);
            Poly(p, new[] { 43f, 15f, 24f, 26f, 24f, 45f, 43f, 34f },
                 Shade(Theme.IconSteel, 0.35f));
        }

        static void ClapperIcon(Color32[] p)
        {
            Box(p, 5f, 20f, 43f, 43f, Theme.IconSlate);
            Poly(p, new[] { 5f, 11f, 43f, 5f, 43f, 18f, 5f, 24f }, Theme.IconBone);
            Poly(p, new[] { 12f, 10f, 18f, 9f, 14f, 22f, 8f, 23f },
                 Shade(Theme.IconSlate, 0.3f));
            Poly(p, new[] { 26f, 8f, 32f, 7f, 28f, 20f, 22f, 21f },
                 Shade(Theme.IconSlate, 0.3f));
            Disc(p, 24f, 32f, 6f, Theme.IconGold);
            Tri(p, 22f, 28f, 22f, 36f, 29f, 32f, Theme.IconSlate);
        }

        static void RosterIcon(Color32[] p)
        {
            Disc(p, 15f, 16f, 7f, Theme.IconBone);
            Poly(p, new[] { 15f, 24f, 28f, 33f, 28f, 43f, 2f, 43f, 2f, 33f },
                 Theme.IconAsh);
            Disc(p, 34f, 18f, 6f, Shade(Theme.IconBone, 0.15f));
            Poly(p, new[] { 34f, 25f, 46f, 33f, 46f, 43f, 24f, 43f, 24f, 33f },
                 Shade(Theme.IconAsh, 0.25f));
        }

        static void LinkIcon(Color32[] p)
        {
            Raster(p, 3f, 12f, 30f, 36f, (x, y) =>
            {
                float dx = (x - 17f) / 13f, dy = (y - 24f) / 10f;
                float d = dx * dx + dy * dy;
                return d <= 1f && d >= 0.4f;
            }, Theme.IconSteel);
            Raster(p, 18f, 12f, 45f, 36f, (x, y) =>
            {
                float dx = (x - 31f) / 13f, dy = (y - 24f) / 10f;
                float d = dx * dx + dy * dy;
                return d <= 1f && d >= 0.4f;
            }, Theme.IconSky);
        }

        static void CrosshairIcon(Color32[] p)
        {
            Ring(p, 24f, 24f, 18f, 14.5f, Theme.IconRust);
            Stroke(p, 24f, 2f, 24f, 15f, 3f, Theme.IconRust);
            Stroke(p, 24f, 33f, 24f, 46f, 3f, Theme.IconRust);
            Stroke(p, 2f, 24f, 15f, 24f, 3f, Theme.IconRust);
            Stroke(p, 33f, 24f, 46f, 24f, 3f, Theme.IconRust);
            Disc(p, 24f, 24f, 3.4f, Theme.IconGold);
        }

        static void AntennaIcon(Color32[] p)
        {
            Stroke(p, 24f, 20f, 24f, 44f, 3.2f, Theme.IconSlate);
            Box(p, 15f, 42f, 33f, 45f, Theme.IconSlate);
            Disc(p, 24f, 18f, 4.4f, Theme.IconRust);
            Arc(p, 24f, 18f, 12f, 9.4f, 200f, 340f, Theme.IconSteel);
            Arc(p, 24f, 18f, 19f, 16.4f, 205f, 335f, Theme.IconSky);
        }

        static void BookIcon(Color32[] p)
        {
            RBox(p, 6f, 7f, 42f, 41f, 3f, Theme.IconOlive);
            Box(p, 10f, 10f, 42f, 38f, Theme.IconBone);
            Box(p, 6f, 7f, 12f, 41f, Theme.IconMoss);
            Stroke(p, 16f, 17f, 37f, 17f, 2.2f, Theme.IconAsh);
            Stroke(p, 16f, 24f, 37f, 24f, 2.2f, Theme.IconAsh);
            Stroke(p, 16f, 31f, 30f, 31f, 2.2f, Theme.IconAsh);
        }

        static void TerminalIcon(Color32[] p)
        {
            RBox(p, 4f, 8f, 44f, 40f, 3f, Theme.IconSlate);
            Box(p, 7f, 15f, 41f, 37f, Theme.Ink);
            Stroke(p, 4f, 11.5f, 44f, 11.5f, 5f, Theme.IconSlate);
            Disc(p, 9f, 11.5f, 1.8f, Theme.IconRust);
            Disc(p, 15f, 11.5f, 1.8f, Theme.IconGold);
            Disc(p, 21f, 11.5f, 1.8f, Theme.IconOlive);
            Stroke(p, 12f, 21f, 18f, 26f, 2.6f, Theme.IconOlive);
            Stroke(p, 18f, 26f, 12f, 31f, 2.6f, Theme.IconOlive);
            Stroke(p, 22f, 32f, 33f, 32f, 2.6f, Theme.IconOlive);
        }

        static void HistoryIcon(Color32[] p)
        {
            Arc(p, 24f, 24f, 18f, 14f, 300f, 240f, Theme.IconAsh);
            Poly(p, new[] { 24f, 1f, 24f, 15f, 12f, 8f }, Theme.IconAsh);
            Stroke(p, 24f, 24f, 24f, 15f, 2.8f, Theme.IconRust);
            Stroke(p, 24f, 24f, 32f, 27f, 2.8f, Theme.IconRust);
            Disc(p, 24f, 24f, 2.4f, Theme.IconBone);
        }

        static void ListIcon(Color32[] p)
        {
            Disc(p, 8f, 11f, 3.2f, Theme.IconRust);
            Disc(p, 8f, 24f, 3.2f, Theme.IconGold);
            Disc(p, 8f, 37f, 3.2f, Theme.IconOlive);
            Stroke(p, 17f, 11f, 42f, 11f, 3.4f, Theme.IconAsh);
            Stroke(p, 17f, 24f, 42f, 24f, 3.4f, Theme.IconAsh);
            Stroke(p, 17f, 37f, 42f, 37f, 3.4f, Theme.IconAsh);
        }

        static void KeyIcon(Color32[] p)
        {
            Ring(p, 15f, 17f, 11f, 5.5f, Theme.IconGold);
            Stroke(p, 21f, 24f, 41f, 41f, 4.6f, Theme.IconGold);
            Stroke(p, 33f, 40f, 39f, 33f, 4.2f, Theme.IconAmber);
            Stroke(p, 27f, 35f, 33f, 28f, 4.2f, Theme.IconAmber);
            Disc(p, 12f, 14f, 2.6f, Lift(Theme.IconGold, 0.5f));
        }

        static void PaletteIcon(Color32[] p)
        {
            Disc(p, 24f, 24f, 20f, Theme.IconBone);
            Disc(p, 33f, 32f, 6.5f, Theme.Ink);
            Disc(p, 15f, 15f, 4.2f, Theme.IconRust);
            Disc(p, 27f, 12f, 4.2f, Theme.IconGold);
            Disc(p, 36f, 20f, 4.2f, Theme.IconOlive);
            Disc(p, 12f, 27f, 4.2f, Theme.IconSteel);
            Disc(p, 18f, 36f, 4.2f, Theme.IconBlood);
        }

        static void MouseIcon(Color32[] p)
        {
            RBox(p, 12f, 5f, 36f, 43f, 12f, Theme.IconBone);
            Stroke(p, 24f, 6f, 24f, 20f, 2f, Theme.IconAsh);
            Stroke(p, 13f, 20f, 35f, 20f, 2f, Theme.IconAsh);
            RBox(p, 22f, 10f, 26f, 19f, 2f, Theme.IconRust);
            Stroke(p, 41f, 14f, 41f, 24f, 2.4f, Theme.IconAsh);
            Poly(p, new[] { 41f, 10f, 44f, 15f, 38f, 15f }, Theme.IconAsh);
            Poly(p, new[] { 41f, 28f, 44f, 23f, 38f, 23f }, Theme.IconAsh);
        }

        // ── section header constants ────────────────────────────────────
        const float SecHeaderH = 26f;
        // 18px rather than 16: the icons carry two or three tones now, and the
        // extra two pixels are what let the second tone register at all. Still
        // fits the 26px header row with the optical offset below.
        const float SecIconH = 18f;
        const float SecIconYOff = 2f;
        const float SecIconGap = 7f;
        const float SecLineGap = 10f;

        static Dictionary<string, Texture2D> _sectionTex;

        void Group(string title)
        {
            GUILayout.Space(6);
            var t = title.ToUpper();

            if (_sectionTex == null)
                _sectionTex = new Dictionary<string, Texture2D>();
            Texture2D icon = null;
            if (SectionIcons.TryGetValue(t, out var draw) &&
                !_sectionTex.TryGetValue(t, out icon))
            {
                icon = BuildIcon(draw);
                _sectionTex[t] = icon;
            }

            // Explicit rect: fills the content row. Icon is positioned
            // optically 3px below geometric centre so it reads as centred
            // against the title text (which sits on the baseline).
            Rect hr = GUILayoutUtility.GetRect(1f, SecHeaderH,
                GUILayout.ExpandWidth(true));

            float iconY = Mathf.Round(hr.y + (hr.height - SecIconH) * 0.5f + SecIconYOff);
            Rect iconRect = new Rect(hr.x + 2f, iconY, SecIconH, SecIconH);

            Color prevC = GUI.color;
            if (icon != null)
            {
                // White, not a tint: the icon's colours are baked into the
                // texture so each one can carry its own two or three tones.
                // Tinting here would flatten every icon back to one hue.
                GUI.color = Color.white;
                GUI.DrawTexture(iconRect, icon);
            }
            else if (SectionIcons.ContainsKey(t))
            {
                // Fallback: draw a visible dot so we know the layout is correct
                GUI.color = Theme.IconAsh;
                GUI.DrawTexture(new Rect(iconRect.x + 2, iconRect.y + 2,
                    iconRect.width - 4, iconRect.height - 4), Texture2D.whiteTexture);
            }

            GUIContent titleC = new GUIContent(t);
            float titleW = Theme.GroupLabel.CalcSize(titleC).x;
            float titleX = iconRect.xMax + SecIconGap;
            GUI.color = Color.white;
            GUI.Label(new Rect(titleX, hr.y, titleW, hr.height), titleC, Theme.GroupLabel);

            float lineX = titleX + titleW + SecLineGap;
            float lineY = Mathf.Round(hr.center.y) + 1f;
            float lineW = Mathf.Max(0f, hr.xMax - lineX);
            if (lineW > 0f)
            {
                GUI.color = Theme.Line;
                GUI.DrawTexture(new Rect(lineX, lineY, lineW, 1f), Texture2D.whiteTexture);
            }
            GUI.color = prevC;

            GUILayout.Space(2);
        }

        void Lede(string text)
        {
            GUILayout.Label(text, Theme.Lede);
            GUILayout.Space(4);
        }

        // ── toggle switch ───────────────────────────────────────────────
        // Track geometry. Constants rather than locals because PillTex bakes
        // the stadium at exactly this aspect ratio.
        const float TrackW = 36f, TrackH = 18f, ThumbD = 14f, ThumbPad = 2f;

        static Texture2D _circleTex, _pillTex;

        static Texture2D CircleTex()
        {
            if (_circleTex != null) return _circleTex;
            const int S = 16;
            _circleTex = new Texture2D(S, S, TextureFormat.RGBA32, false);
            _circleTex.filterMode = FilterMode.Bilinear;
            // Centre is S/2 and the radius fills the texture: at 7.5 / r=7 the
            // disc sat half a pixel up-and-left of the texture centre and left
            // a wider gap on the right, so the thumb rendered slightly off
            // centre inside its own rect.
            const float cx = S * 0.5f, cy = S * 0.5f, R = S * 0.5f;
            var px = new Color32[S * S];
            for (int y = 0; y < S; y++)
                for (int x = 0; x < S; x++)
                {
                    float dx = x + 0.5f - cx, dy = y + 0.5f - cy;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(R - dist + 0.5f);
                    px[y * S + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            _circleTex.SetPixels32(px);
            _circleTex.Apply();
            return _circleTex;
        }

        /// <summary>
        /// The toggle track as one anti-aliased stadium, supersampled 4× and
        /// left to the bilinear filter on the way down.
        ///
        /// It must be a single texture drawn in a single tinted call. The track
        /// used to be composed live from two end-cap circles plus a centre bar,
        /// and the bar overlapped each cap by 10px. The OFF colour is only 70%
        /// opaque, so those overlap bands composited twice — 1-(1-0.7)² = 0.91
        /// against 0.70 at the ends — which drew a vertical seam down each side
        /// of an unlit toggle. Lit toggles hid it because Theme.Live is opaque.
        /// </summary>
        static Texture2D PillTex()
        {
            if (_pillTex != null) return _pillTex;

            const int Super = 4;
            int w = (int)TrackW * Super, h = (int)TrackH * Super;
            float radius = h * 0.5f;

            var px = new Color32[w * h];
            for (int y = 0; y < h; y++)
            {
                for (int x = 0; x < w; x++)
                {
                    // Distance to the stadium's spine: a horizontal segment
                    // inset by the cap radius at both ends.
                    float fx = x + 0.5f, fy = y + 0.5f;
                    float spineX = Mathf.Clamp(fx, radius, w - radius);
                    float dx = fx - spineX, dy = fy - radius;
                    float dist = Mathf.Sqrt(dx * dx + dy * dy);
                    float a = Mathf.Clamp01(radius - dist + 0.5f);
                    px[y * w + x] = new Color32(255, 255, 255, (byte)(a * 255f));
                }
            }

            _pillTex = new Texture2D(w, h, TextureFormat.RGBA32, false);
            _pillTex.filterMode = FilterMode.Bilinear;
            _pillTex.wrapMode = TextureWrapMode.Clamp;
            _pillTex.hideFlags = HideFlags.DontSave;
            _pillTex.SetPixels32(px);
            _pillTex.Apply();
            return _pillTex;
        }

        // ── toggle animation ────────────────────────────────────────────
        // Each toggle stores a raw linear value (0→1) that is eased before
        // rendering. Easing is cubic ease-out: fast start, gentle deceleration
        // into the target — feels physical rather than mechanical. Animation
        // speed: 8 units/sec ≈ 125 ms to cross the full range.
        static readonly Dictionary<string, float> _toggleAnim = new();
        const float ToggleSpeed = 8f;

        static float EaseOut(float t) => 1f - (1f - t) * (1f - t) * (1f - t);

        /// <summary>
        /// Renders a label + pill-toggle row. A click anywhere on the row
        /// flips the state. The toggle is custom-drawn: a colored pill track
        /// with a sliding circular thumb that animates smoothly with ease-out
        /// — green when ON (rust when danger), dark when OFF.
        /// </summary>
        bool Switch(string label, bool value, bool danger = false)
        {
            // ── smooth animation ────────────────────────────────────────
            if (!_toggleAnim.TryGetValue(label, out float raw))
                raw = value ? 1f : 0f;
            float target = value ? 1f : 0f;
            raw = Mathf.MoveTowards(raw, target, ToggleSpeed * Time.deltaTime);
            _toggleAnim[label] = raw;

            // Apply ease-out curve: fast start, gentle settle
            float anim = EaseOut(raw);

            // Interpolate track colour: dark grey → green (or rust)
            var offCol = new Color(0.22f, 0.22f, 0.20f, 0.70f);
            var onCol = danger ? Theme.RustBright : Theme.Live;
            var trackCol = Color.Lerp(offCol, onCol, anim);

            // Label transitions earlier (at raw=0.4 instead of 0.5) so the
            // text washes bright before the thumb arrives, not after.
            GUILayout.BeginHorizontal(GUILayout.Height(ROW));
            var labelStyle = raw > 0.4f
                ? (danger ? Theme.SwitchDanger : Theme.SwitchOn)
                : Theme.SwitchOff;
            if (GUILayout.Button(label, labelStyle, GUILayout.Height(ROW),
                                 GUILayout.ExpandWidth(true)))
                value = !value;

            GUILayout.Space(2);

            var toggleRect = GUILayoutUtility.GetRect(TrackW + 4, ROW,
                GUILayout.Width(TrackW + 4), GUILayout.Height(ROW));
            float ty = toggleRect.y + (toggleRect.height - TrackH) * 0.5f;
            var track = new Rect(toggleRect.x, ty, TrackW, TrackH);

            // Track: one stadium, one tinted draw — see PillTex for why this
            // must not go back to being assembled from overlapping pieces.
            var prevC = GUI.color;
            GUI.color = trackCol;
            GUI.DrawTexture(track, PillTex());
            GUI.color = prevC;

            // Thumb: white circle that eases smoothly between left and right.
            // Subtle scale bump: thumb grows 10% at mid-travel for a tactile
            // "pop" then returns to normal size at rest.
            float thumbX = track.x + ThumbPad
                         + anim * (TrackW - ThumbD - 2f * ThumbPad);
            float thumbScale = 1f + 0.10f * (1f - Mathf.Abs(anim - 0.5f) * 2f);
            float scaledThumbD = ThumbD * thumbScale;
            float scaledOffset = (scaledThumbD - ThumbD) * 0.5f;
            GUI.color = Theme.Bone;
            GUI.DrawTexture(new Rect(thumbX - scaledOffset,
                track.y + ThumbPad - scaledOffset, scaledThumbD, scaledThumbD),
                CircleTex());
            GUI.color = prevC;

            // Click on the toggle area also toggles
            if (Event.current.type == EventType.MouseDown &&
                Event.current.button == 0 &&
                toggleRect.Contains(Event.current.mousePosition))
            {
                value = !value;
                Event.current.Use();
            }

            GUILayout.EndHorizontal();
            return value;
        }

        // ── data-driven renderers over the game's console commands ───────
        // These take custom struct arrays / tuples that Il2CppInterop cannot
        // marshal into native — they are only ever called from managed draw
        // code, so hide them from the interop generator (which otherwise
        // warns at class registration about "unsupported parameter").
        [HideFromIl2Cpp]
        void SwitchRows(ToggleCommand[] rows)
        {
            for (int i = 0; i < rows.Length; i++)
            {
                bool cur = Features.GetCmd(rows[i].Command);
                bool next = Switch(rows[i].Label, cur, rows[i].Danger);
                if (next != cur) Features.SetCmd(rows[i].Command, next);
            }
        }

        [HideFromIl2Cpp]
        /// <summary>Equal-width button for a 2-column grid. Must be laid out
        /// inside a horizontal with a gap before the second button.</summary>
        float ColW(int cols = 2, float gap = 6f)
        {
            float paneW = W - RAIL - 2f;
            float viewW = paneW - SCROLLW;
            float contentW = viewW - 2f * PAD;
            return (contentW - (cols - 1) * gap) / cols;
        }

        /// <summary>Renders a full-width button (single column, no gap).</summary>
        bool FullButton(string label, GUIStyle style = null, float height = 26f)
        {
            return GUILayout.Button(label.ToUpper(), style ?? Theme.BtnPrimary,
                                    GUILayout.Height(height));
        }

        /// <summary>Standardised gear-apply button. Uses BtnPrimary, 26px tall,
        /// with consistent spacing above.</summary>
        [HideFromIl2Cpp]
        void GearApply(string label, System.Action click)
        {
            GUILayout.Space(4);
            if (GUILayout.Button(label.ToUpper(), Theme.BtnPrimary,
                                 GUILayout.Height(26)))
                click();
        }

        [HideFromIl2Cpp]
        void ActionRows(ActionCommand[] rows)
        {
            int perRow = 2;
            float gap = RowGap;
            float eachW = ColW(perRow, gap);
            for (int i = 0; i < rows.Length; i += perRow)
            {
                GUILayout.BeginHorizontal();
                for (int k = i; k < i + perRow && k < rows.Length; k++)
                {
                    // Uniform grey, rail-active wash on hover. Danger no longer paints
                    // the button rust: a grid with half its rows permanently red
                    // reads as an error state rather than a set of available
                    // actions, and a constant alarm stops carrying meaning.
                    // The flag still describes the command, it is just not
                    // rendered here — see the note on ActionCommand.Danger.
                    if (GUILayout.Button(rows[k].Label.ToUpper(), Theme.Btn,
                                         GUILayout.Height(26),
                                         GUILayout.Width(eachW)))
                        Features.RunCmd(rows[k].Command);
                    // Gap so paired buttons don't touch in the centre
                    if (k < i + perRow - 1 && k < rows.Length - 1)
                        GUILayout.Space(gap);
                }
                GUILayout.EndHorizontal();
                GUILayout.Space(4);
            }
        }

        /// <summary>
        /// A text field that shows placeholder text while it is empty and
        /// unfocused.
        ///
        /// <para>IMGUI has no placeholder of its own, so an empty
        /// <see cref="Theme.Field"/> is a plain black rectangle with no
        /// indication it can be typed into — it reads as a rendering artifact
        /// sitting next to whatever button follows it. The hint is drawn over
        /// the field on the Repaint pass only, so it never interferes with
        /// input handling or the caret.</para>
        /// </summary>
        /// <param name="controlName">Focus id; must be unique on the page.</param>
        [HideFromIl2Cpp]
        string HintField(string controlName, string value, string hint,
                         params GUILayoutOption[] options)
        {
            GUI.SetNextControlName(controlName);
            string typed = GUILayout.TextField(value ?? string.Empty, Theme.Field, options);

            Rect field = GUILayoutUtility.GetLastRect();
            bool showHint = string.IsNullOrEmpty(typed)
                         && GUI.GetNameOfFocusedControl() != controlName
                         && Event.current.type == EventType.Repaint;

            if (showHint)
            {
                GUI.Label(new Rect(field.x, field.y, field.width, field.height),
                          hint, Theme.FieldHint);
            }

            return typed;
        }

        /// <summary>Numeric-argument commands: a field plus an Apply button.</summary>
        [HideFromIl2Cpp]
        void ValueRows(ValueCommand[] rows, string key)
        {
            for (int i = 0; i < rows.Length; i++)
            {
                string id = key + i;
                string cur;
                if (!_fieldValues.TryGetValue(id, out cur)) cur = rows[i].DefaultValue;

                GUILayout.BeginHorizontal(GUILayout.Height(24));
                GUILayout.Label(rows[i].Label, Theme.DialLabel, GUILayout.Width(190));
                cur = GUILayout.TextField(cur, Theme.Field, GUILayout.Width(64));
                GUILayout.Space(6);
                if (GUILayout.Button("APPLY", Theme.Btn, GUILayout.Width(76),
                                     GUILayout.Height(22)))
                    Features.RunCmd(rows[i].Command + " " + cur.Trim());
                GUILayout.EndHorizontal();
                _fieldValues[id] = cur;
                GUILayout.Space(2);
            }
        }

        /// <summary>setGameSetupSetting rows: label, setting path, value field.</summary>
        [HideFromIl2Cpp]
        void SetupRows((string Label, string Setting, string Def)[] rows, string key)
        {
            for (int i = 0; i < rows.Length; i++)
            {
                string id = key + i;
                string cur;
                if (!_fieldValues.TryGetValue(id, out cur)) cur = rows[i].Def;

                GUILayout.BeginHorizontal(GUILayout.Height(24));
                GUILayout.Label(rows[i].Label, Theme.DialLabel, GUILayout.Width(190));
                cur = GUILayout.TextField(cur, Theme.Field, GUILayout.Width(64));
                GUILayout.Space(6);
                if (GUILayout.Button("APPLY", Theme.Btn, GUILayout.Width(76),
                                     GUILayout.Height(22)))
                    Features.RunCmd("setGameSetupSetting " + rows[i].Setting
                                    + " " + cur.Trim());
                GUILayout.EndHorizontal();
                _fieldValues[id] = cur;
                GUILayout.Space(2);
            }
        }

        float Dial(string label, float value, float min, float max, string fmt = "0.00")
        {
            GUILayout.BeginHorizontal();
            GUILayout.Label(label, Theme.DialLabel, GUILayout.Width(200));
            GUILayout.FlexibleSpace();
            // readout colour follows the value: low = rust, mid = amber,
            // high = green. DialValue is only used here, so mutating its
            // colour per draw is safe.
            Theme.DialValue.normal.textColor =
                Theme.Ramp((value - min) / (max - min));
            GUILayout.Label(value.ToString(fmt), Theme.DialValue, GUILayout.Width(62));
            GUILayout.EndHorizontal();

            // Manual slider: the built-in HorizontalSlider can't colour its
            // track, so the filled portion is drawn with the same red → yellow
            // → green ramp as the readout. Hit-testing uses the scroll-content
            // local rect directly — Event.current.mousePosition is already in
            // the BeginArea/BeginScrollView local coordinate space, so no
            // hardcoded screen offsets are needed.
            var r = GUILayoutUtility.GetRect(0f, 16f, GUILayout.ExpandWidth(true));
            float t = Mathf.Clamp01((value - min) / (max - min));

            // The visible portion of the content rect in local (area) coords.
            var view = new Rect(r.x, r.y - _scroll.y, r.width, r.height);

            int id = GUIUtility.GetControlID(FocusType.Passive);
            var e = Event.current;
            if (e.type == EventType.MouseDown && view.Contains(e.mousePosition))
            {
                GUIUtility.hotControl = id;
                float p = Mathf.Clamp01((e.mousePosition.x - view.x) / view.width);
                value = Mathf.Lerp(min, max, p);
                e.Use();
            }
            if (e.type == EventType.MouseDrag && GUIUtility.hotControl == id)
            {
                float p = Mathf.Clamp01((e.mousePosition.x - view.x) / view.width);
                value = Mathf.Lerp(min, max, p);
                e.Use();
            }
            if (e.type == EventType.MouseUp && GUIUtility.hotControl == id)
            {
                GUIUtility.hotControl = -1;
                e.Use();
            }

            // dim base track, then the ramp-coloured fill up to the thumb
            const float trackH = 4f, trackY = 6f;
            Theme.Fill(new Rect(r.x, r.y + trackY, r.width, trackH), Theme.Line);
            Theme.Fill(new Rect(r.x, r.y + trackY, r.width * t, trackH),
                       Theme.Ramp(t));

            // thumb: light pill, rust while grabbed
            bool hot = GUIUtility.hotControl == id;
            Theme.Fill(new Rect(r.x + r.width * t - 5f, r.y + 1f, 10f, 14f),
                       hot ? Theme.RustBright : new Color(0.72f, 0.72f, 0.65f, 0.95f));

            GUILayout.Space(6);
            return value;
        }
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  DirectGameApi.cs · features with no debug-console equivalent
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using Sons.Ai.Vail;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Features the game's debug console cannot express, driven straight at the
/// API instead.
///
/// <para>Everything routed through <see cref="Game.Console"/> gets the game's
/// own validation for free, so that is always the first choice. What lands here
/// is the remainder: status effects, ghost mode, vehicle and gear tuning — all
/// of which live on scene components with no console verb behind them.</para>
///
/// <para>Every member below was arity-checked against
/// <c>global-metadata.dat</c> before it was written.</para>
/// </summary>
[Cyberfox1337x]
internal static class DirectGameApi
{
    /// <summary>Last operation's outcome, mirrored into the status bar.</summary>
    internal static string Result { get; private set; } = string.Empty;

    /// <summary>Records success on both the local and the shared status line.</summary>
    static void Ok(string what)
    {
        Result = what;
        Features.LastResult = what;
    }

    /// <summary>Records failure. The exception itself is already logged by Safe.</summary>
    static void Fail(string what)
    {
        Result = $"{what} failed";
        Features.LastResult = Result;
    }

    /// <summary>Runs <paramref name="work"/> and reports either way.</summary>
    static void Attempt(string site, string what, System.Action work)
    {
        if (Safe.Run(site, work, Noise.Warn)) Ok(what);
        else Fail(what);
    }

    // ── player status effects ───────────────────────────────────────────

    /// <summary>
    /// The <c>PlayerStats</c> status effects surfaced on the PLAYER tab, keyed
    /// by the identifier the UI passes.
    ///
    /// <para>A dispatch table rather than a switch so the UI's button list and
    /// the effects that actually exist cannot drift: the tab enumerates these
    /// keys directly.</para>
    /// </summary>
    static readonly System.Collections.Generic.Dictionary<string, System.Action<PlayerStats>>
        StatusEffects = new()
    {
        ["StopBurning"]     = stats => stats.StopBurning(),
        ["GotClean"]        = stats => stats.GotCleanReal(),
        ["GotMud"]          = stats => stats.GotMud(),
        ["GotBloody"]       = stats => stats.GotBloody(),
        ["HitPoison"]       = stats => stats.HitPoison(),
        ["AdrenalineRush"]  = stats => stats.AdrenalineRush(),
        ["ClearSkunkSmell"] = stats => stats.ClearSkunkSmell(),
    };

    /// <summary>Applies a named status effect to the local player.</summary>
    internal static void StatusEffect(string which)
    {
        PlayerStats stats = Game.Stats;
        if (stats == null)
        {
            Features.LastResult = "Needs a loaded world";
            return;
        }

        if (!StatusEffects.TryGetValue(which, out System.Action<PlayerStats> apply))
        {
            Diag.Warn($"unknown status effect requested: '{which}'");
            return;
        }

        if (Safe.Run($"status.{which}", stats, apply, Noise.Warn)) Ok(which);
        else Fail(which);
    }

    // ── enemies ─────────────────────────────────────────────────────────

    static bool _ghost;

    /// <summary>
    /// Ghost player — Vail actors stop perceiving you. Backed by a static on
    /// the manager, not an instance member.
    /// </summary>
    internal static bool Ghost
    {
        get => _ghost;
        set
        {
            _ghost = value;
            Attempt("enemies.ghost", $"Ghost player {(value ? "on" : "off")}",
                () => VailActorManager.SetGhostPlayer(value));
        }
    }

    /// <summary>
    /// Kills every living Vail actor currently loaded.
    ///
    /// <para>The inner guard is per-actor and deliberate: an actor despawning
    /// mid-loop must not abort the remaining kills, which is what a single
    /// guard around the whole loop would do.</para>
    /// </summary>
    internal static void KillAllActors()
    {
        VailActorManager manager = Safe.Get("enemies.actor-manager",
            () => VailActorManager._instance, noise: Noise.Warn);

        if (manager == null)
        {
            Features.LastResult = "No actor manager";
            return;
        }

        Il2CppSystem.Collections.Generic.List<VailActor> actors =
            Safe.Get("enemies.actor-list", manager, m => m._activeActors, noise: Noise.Warn);

        if (actors == null)
        {
            Features.LastResult = "No actors";
            return;
        }

        int killed = 0;
        int count = Safe.Get("enemies.actor-count", actors, list => list.Count, 0);

        for (int index = 0; index < count; index++)
        {
            bool died = Safe.Run("enemies.force-death", (actors, index), state =>
            {
                VailActor actor = state.actors[state.index];
                if (actor == null || actor._isDead) return;

                actor.ForceDeath();
            });

            if (died) killed++;
        }

        Ok($"Killed {killed} actor(s)");
    }

    // ── world ───────────────────────────────────────────────────────────

    /// <summary>
    /// Removes every player-built structure. Destructive and irreversible from
    /// the plugin's side — the game's own database performs the removal, so it
    /// is undone only by reloading a save.
    /// </summary>
    internal static void ClearAllStructures()
    {
        var database = Safe.Get("world.structure-database",
            () => Object.FindObjectOfType<Construction.RuntimeStructureDatabase>(),
            noise: Noise.Warn);

        if (database == null)
        {
            Features.LastResult = "No structure database";
            return;
        }

        Attempt("world.clear-structures", "All structures cleared",
            () => database.ClearAllStructures());
    }

    // ── vehicle and gear tuning ─────────────────────────────────────────
    //
    // Each of these edits a settings object hanging off a scene component, so
    // the component has to exist: the glider must be equipped, the Knight V
    // must be spawned. The "no X in world" results below are the normal answer
    // rather than an error, and are phrased for the status bar accordingly.

    internal static float GliderForward { get; set; } = 12f;
    internal static float GliderPitchUp { get; set; } = 5f;
    internal static float GliderDown { get; set; } = 3f;

    internal static void ApplyGlider()
    {
        var action = Safe.Get("gear.glider-action",
            () => Object.FindObjectOfType<Sons.Gameplay.PlayerHangGliderAction>());

        var settings = action == null
            ? null
            : Safe.Get("gear.glider-settings", action, a => a._hangGliderSettings);

        if (settings == null)
        {
            Features.LastResult = "No glider in world";
            return;
        }

        Attempt("gear.glider-apply", "Glider tuned", () =>
        {
            settings.ConstantForwardForce = GliderForward;
            settings.UpPitchDownForce = GliderPitchUp;
            settings.BaseDownPitchForce = GliderDown;
        });
    }

    internal static float KnightVSpeed { get; set; } = 18f;

    internal static void ApplyKnightV()
    {
        var action = Safe.Get("gear.knightv-action",
            () => Object.FindObjectOfType<Sons.Gameplay.PlayerKnightVAction>());

        var definition = action == null
            ? null
            : Safe.Get("gear.knightv-definition", action, a => a._controlDefinition);

        if (definition == null)
        {
            Features.LastResult = "No Knight V in world";
            return;
        }

        Attempt("gear.knightv-apply", "Knight V tuned",
            () => definition.MaxVelocity = KnightVSpeed);
    }

    internal static float FlashlightIntensity { get; set; } = 4f;
    internal static float FlashlightDrain { get; set; }

    internal static void ApplyFlashlight()
    {
        var flashlight = Safe.Get("gear.flashlight",
            () => Object.FindObjectOfType<Sons.Weapon.FlashlightController>());

        if (flashlight == null)
        {
            Features.LastResult = "No flashlight in world";
            return;
        }

        Attempt("gear.flashlight-apply", "Flashlight tuned", () =>
        {
            flashlight._maxLightIntensity = FlashlightIntensity;
            flashlight._powerDrainRate = FlashlightDrain;
        });
    }

    internal static float RebreatherAir { get; set; }
    internal static float RebreatherLight { get; set; } = 4f;

    internal static void ApplyRebreather()
    {
        var rebreather = Safe.Get("gear.rebreather",
            () => Object.FindObjectOfType<Sons.Gameplay.RebreatherController>());

        if (rebreather == null)
        {
            Features.LastResult = "No rebreather in world";
            return;
        }

        Attempt("gear.rebreather-apply", "Rebreather tuned", () =>
        {
            rebreather._airConsumptionRate = RebreatherAir;
            rebreather._maxLightIntensity = RebreatherLight;
        });
    }
}

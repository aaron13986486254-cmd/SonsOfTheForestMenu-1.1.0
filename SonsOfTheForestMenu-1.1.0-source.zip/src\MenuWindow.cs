// ═══════════════════════════════════════════════════════════════════════════
//  MenuWindow.cs · menu shell: lifecycle, layout, chrome
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// The overlay. Chrome is drawn with manual rects so the Vein layout holds
    /// exactly; the scrolling content uses GUILayout inside a clipped area.
    ///
    /// Split into three partials by responsibility:
    ///   MenuWindow.cs       — lifecycle, layout, navigation, chrome
    ///   MenuWindow.Tabs.cs  — the thirteen tab bodies + spawn lists
    ///   MenuWindow.Widgets.cs — reusable drawing primitives
    /// </summary>
    [Cyberfox1337x("menu shell",
                   Bound = "IL2CPP-injected MonoBehaviour; Unity matches Update/OnGUI by name")]
    public partial class MenuWindow : MonoBehaviour
    {
        public MenuWindow(IntPtr ptr) : base(ptr) { }

        // ── layout ───────────────────────────────────────────────────────
        // Sized from the screen rather than fixed: at 850x554 a hard-coded
        // 780x520 panel overflowed the window and clipped the header.
        const float RAIL = 150f, HEAD = 58f, FOOT = 24f;
        const float PAD = 16f, ROW = 26f, SCROLLW = 18f;

        /// <summary>
        /// Gap between controls sharing a horizontal run. Rounded buttons laid
        /// edge to edge lose their corners against each other and read as one
        /// continuous bar, so every side-by-side pair is separated by this.
        /// </summary>
        const float RowGap = 6f;

        /// <summary>Design row height for the rail, used whenever there is room.</summary>
        const float RAIL_ROW = 26f;

        /// <summary>
        /// Floor for <see cref="RailRowHeight"/>. Below this the label stops
        /// being comfortably clickable, so the panel minimum is the real limit.
        /// </summary>
        const float RAIL_ROW_MIN = 18f;

        /// <summary>Pixels between the header rule and the first rail row.</summary>
        const float RAIL_TOP_PAD = 8f;

        /// <summary>
        /// Left inset for a rail label, clearing the 3px selected-row accent bar
        /// with room to breathe. Was 28px to leave space for a row number; the
        /// numbers are gone, so the label starts where the eye expects it.
        /// </summary>
        const float RailLabelInset = 12f;

        /// <summary>
        /// Row height that always fits every category on screen.
        ///
        /// <para>26px at any normal panel size. At the 380px minimum the rail
        /// only has 298px against the 338px thirteen rows want, so it shrinks
        /// rather than clipping: a flat list exists so the whole menu is visible
        /// at once, and silently cutting off the last two categories would
        /// defeat the entire point of flattening it.</para>
        /// </summary>
        static float RailRowHeight
        {
            get
            {
                float available = H - HEAD - FOOT - RAIL_TOP_PAD;
                float perRow = available / Categories.Length;

                return Mathf.Clamp(Mathf.Floor(perRow), RAIL_ROW_MIN, RAIL_ROW);
            }
        }

        /// <summary>
        /// Gap above the first section now that the chip strip is gone. The old
        /// 40px was the strip plus its rule; content only needs breathing room.
        /// </summary>
        const float ContentTopPad = 10f;

        /// <summary>
        /// Fraction of the TELEPORT pane given to the map, capped to the pane
        /// width so it stays square rather than stretching on a wide panel.
        /// 0.45 rather than a half: the spot list and the 55-entry location
        /// picker share the remainder, and at 0.55 the picker had nowhere to go.
        /// </summary>
        const float TeleportMapShare = 0.45f;

        static float W => Mathf.Clamp(Screen.width * 0.66f, 560f, 940f);
        static float H => Mathf.Clamp(Screen.height * 0.78f, 380f, 680f);

        /// <summary>
        /// One entry in the rail.
        ///
        /// <para><b>Navigation is flat.</b> It used to be rail categories → chip
        /// strip → sections, three levels to reach a switch. Every destination is
        /// now one click from anywhere, and the chip strip is gone: with thirteen
        /// categories the whole map of the menu is on screen at all times, which
        /// is worth more than the grouping was.</para>
        ///
        /// <para><see cref="Hint"/> is the sections the page contains, shown in
        /// the header so the rail label does not have to carry everything.</para>
        /// </summary>
        readonly struct Category
        {
            internal string Name { get; }
            internal string Hint { get; }

            internal Category(string name, string hint)
            {
                Name = name;
                Hint = hint;
            }
        }

        /// <summary>
        /// The rail, in order. Index is the identity used by <c>_tab</c> and the
        /// dispatch in <see cref="DrawPane"/> — keep the two in step.
        /// </summary>
        static readonly Category[] Categories =
        {
            new("PLAYER",     "Survival · Needs · Status · Cheats"),      //  0
            new("MOVEMENT",   "On Foot · Speed · Flight"),                //  1
            new("TELEPORT",   "Map · Saved Spots · Named Locations"),     //  2
            new("COMBAT",     "Weapons · Tuning · Enemies · Area"),       //  3
            new("SPAWN",      "Items · Characters · Animals · Props"),    //  4
            new("GEAR",       "Glider · Knight V · Light · Rebreather"),  //  5
            new("WORLD",      "Build · Season · Time · Weather"),         //  6
            new("GAME SETUP", "World rules · Survival rules"),            //  7
            new("VISION",     "ESP · Item ESP · Radar · Overlays"),       //  8
            new("ONLINE",     "Roster · Session · Network"),              //  9
            new("CHEATS",     "Engine · Achievements · Armour"),          // 10
            new("CONSOLE",    "Search · Run · Recent"),                   // 11
            new("SETTINGS",   "Hotkey · Steam key · Appearance"),         // 12
        };

        /// <summary>TELEPORT owns the map, which draws itself rather than scrolling.</summary>
        const int TabTeleportIndex = 2;

        /// <summary>Categories whose contents depend on a fresh multiplayer roster.</summary>
        static bool NeedsRoster(int tab) => tab == TabTeleportIndex || tab == 9;

        // reused for chip labels — the strip redraws every event while the
        // menu is open, so a fresh GUIContent per chip would be garbage
        static readonly GUIContent _chipGc = new GUIContent();

        // ── state ────────────────────────────────────────────────────────
        int _tab;
        bool _open;
        Vector2 _scroll;
        Rect _panel;

        // drag state
        Vector2 _pos;
        bool _placed, _dragging, _nudged;
        Vector2 _grabOffset;

        bool _cursorWasLocked;

        // online tab — refresh once when the tab is opened, or on demand
        bool _rosterDirty = true;
        string _steamKey = "";

        // MOVEMENT tab — named-locations dropdown (replaces the old wall of
        // wiki teleport buttons).
        bool _locOpen;
        int _locSel = -1;
        Vector2 _locScroll;

        // SETTINGS tab — hotkey rebinding.
        /// <summary>True while waiting for the user to press their new hotkey.</summary>
        bool _rebindArmed;

        /// <summary>Result of the last rebind attempt, shown under the button.</summary>
        string _rebindStatus;

        /// <summary>True when that result was a success, for colouring.</summary>
        bool _rebindOk;

        /// <summary>
        /// Frames to ignore the toggle for after a rebind. Belt and braces: the
        /// key that was just captured must not also be read as "open the menu"
        /// on the way out of the capture.
        /// </summary>
        int _suppressToggleFrames;

        /// <summary>
        /// Height and top edge of the scrolling content viewport, published by
        /// DrawPane each frame. The named-locations dropdown sizes itself from
        /// these instead of assuming a fixed row count — on TELEPORT the map
        /// takes more than half the pane, so the space available varies a lot.
        /// </summary>
        float _contentViewportH, _contentViewportTop;

        /// <summary>
        /// Where the open dropdown sits, in pane coordinates. Lets the wheel go
        /// to the list only while the cursor is over it, and to the page
        /// otherwise. Empty when the dropdown is closed.
        /// </summary>
        Rect _locBoxInPane;

        // ── cached chrome styles ────────────────────────────────────────
        // IMGUI rebuilds the whole menu on every event, and `new GUIStyle`
        // allocates native style state — constructing them per tab / per row /
        // per event is real GC + native churn every frame while the menu is
        // open (and the world keeps simulating underneath). These are built
        // once on first use, after Theme.Build_ has run.
        static GUIStyle _statusInWorld, _statusNoWorld,
                        _statusLive, _tagAdmin, _tagBoss;


        static GUIStyle StatusStyle(bool inWorld)
        {
            if (_statusInWorld == null)
            {
                _statusInWorld = new GUIStyle(Theme.Build);
                _statusInWorld.normal.textColor = Theme.Live;
                _statusNoWorld = new GUIStyle(Theme.Build);
                _statusNoWorld.normal.textColor = Theme.Dead;
            }
            return inWorld ? _statusInWorld : _statusNoWorld;
        }

        static GUIStyle LiveStyle()
        {
            if (_statusLive == null)
            {
                _statusLive = new GUIStyle(Theme.StatusText);
                _statusLive.normal.textColor = Theme.Live;
            }
            return _statusLive;
        }

        static GUIStyle AdminTagStyle()
        {
            if (_tagAdmin == null)
            {
                _tagAdmin = new GUIStyle(Theme.RowTag);
                _tagAdmin.normal.textColor = Theme.RustBright;
            }
            return _tagAdmin;
        }

        static GUIStyle BossTagStyle()
        {
            if (_tagBoss == null)
            {
                _tagBoss = new GUIStyle(Theme.RowTag);
                _tagBoss.normal.textColor = Theme.RustBright;
            }
            return _tagBoss;
        }

        // ONLINE tab — Steam key save feedback (green ok / rust problem)
        static GUIStyle _keyOk, _keyBad;
        static GUIStyle KeyStatusStyle(bool ok)
        {
            if (_keyOk == null)
            {
                _keyOk = new GUIStyle(Theme.Lede);
                _keyOk.normal.textColor = Theme.Live;
                _keyBad = new GUIStyle(Theme.Lede);
                _keyBad.normal.textColor = Theme.RustBright;
            }
            return ok ? _keyOk : _keyBad;
        }

        void Update()
        {
            try
            {
                // While a rebind is armed the toggle is deaf. Otherwise pressing
                // the current hotkey in order to replace it would close the menu
                // out from under the capture.
                if (_rebindArmed)
                {
                    // OnGUI owns the keyboard until the capture resolves
                }
                else if (_suppressToggleFrames > 0)
                {
                    _suppressToggleFrames--;
                }
                else if (Input.GetKeyDown(Plugin.ToggleKey))
                {
                    _open = !_open;
                    if (_open) OnOpen(); else OnClose();
                }

                Features.MenuOpen = _open;
                if (_open) NudgeWithKeys();
                Avatars.Tick(); // avatar downloads -> textures on the main thread
                Features.Tick();
            }
            catch (Exception e)
            {
                Diag.Error("Update: " + e);
            }
        }

        void OnOpen()
        {
            _cursorWasLocked = Cursor.lockState == CursorLockMode.Locked;
            Cursor.lockState = CursorLockMode.None;
            Cursor.visible = true;
            SetPlayerFrozen(true);
            if (string.IsNullOrEmpty(_steamKey))
                _steamKey = Plugin.SteamApiKey;
        }

        void OnClose()
        {
            CancelRebind();
            SetPlayerFrozen(false);
            SavePos();
            if (_cursorWasLocked)
            {
                Cursor.lockState = CursorLockMode.Locked;
                Cursor.visible = false;
            }
        }

        /// <summary>
        /// Hands input to the game's own Menu state while the panel is up, so the
        /// character stops moving and looking around and clicks land on the menu
        /// instead of swinging an axe. Uses the game's input system rather than
        /// eating raw input, so it unwinds cleanly on close.
        /// </summary>
        static void SetPlayerFrozen(bool frozen)
        {
            try
            {
                Sons.Input.InputSystem.SetState(TheForest.Utils.InputState.Menu, frozen);
            }
            catch (Exception e)
            {
                Diag.Warn("input freeze failed: " + e.Message);
            }
        }

        void OnGUI()
        {
            try
            {
                Theme.Build_();

                // First, before anything can react to the keyboard: an armed
                // rebind claims the next key press for itself.
                HandleRebindCapture();

                // Live corner radius: rebuild the corner textures only when
                // the SETTINGS-tab value actually changed.
                int wantRadius = (int)Plugin.CornerRadius;
                if (Theme.RoundR != wantRadius)
                {
                    Theme.RoundR = wantRadius;
                    Theme.RebuildRoundTextures();
                }

                Esp.Draw();
                ItemEsp.Draw();
                if (!_open) { Watermark(); return; }

                // keep the cursor usable while the menu is up
                Cursor.lockState = CursorLockMode.None;
                Cursor.visible = true;

                float w = W, h = H;
                if (!_placed)
                {
                    // saved position, else centre
                    float sx = Plugin.PosX, sy = Plugin.PosY;
                    _pos = (float.IsNaN(sx) || float.IsNaN(sy))
                        ? new Vector2((Screen.width - w) * 0.5f, (Screen.height - h) * 0.5f)
                        : new Vector2(sx, sy);
                    _placed = true;
                }

                // Always keep a grabbable strip on screen, even if the window
                // moved or the resolution changed since the position was saved.
                _pos.x = Mathf.Clamp(_pos.x, -w + 140f, Screen.width - 140f);
                _pos.y = Mathf.Clamp(_pos.y, 0f, Mathf.Max(0f, Screen.height - HEAD));

                _panel = new Rect(_pos.x, _pos.y, w, h);
                HandleDrag(new Rect(_panel.x, _panel.y, _panel.width, HEAD));

                var panelColor = Theme.Panel;
                panelColor.a = Plugin.MenuOpacity;
                Theme.RoundedFill(_panel, panelColor);
                Theme.RoundedBox(_panel, Theme.Line);

                DrawHeader();
                DrawRail();
                DrawPane();
                DrawStatus();
            }
            catch (Exception e)
            {
                Diag.Error("OnGUI: " + e);
            }
        }

        void Watermark()
        {
            var r = new Rect(14, 10, 320, 26);
            GUI.Label(r, "SONS OF THE FOREST", Theme.Watermark);
            GUI.Label(new Rect(14, 32, 320, 16),
                "[" + Plugin.ToggleKey + "] menu", Theme.Build);
        }

        /// <summary>
        /// Shift + arrow keys move the panel. The game captures the mouse, so
        /// keyboard nudging is the reliable path; dragging still works when the
        /// cursor is free. Hold Ctrl as well for a coarse step.
        /// Movement is per-second via deltaTime, not per-frame, so it travels at
        /// the same rate regardless of framerate.
        /// </summary>
        void NudgeWithKeys()
        {
            if (!Input.GetKey(KeyCode.LeftShift) && !Input.GetKey(KeyCode.RightShift))
            {
                if (_nudged) { _nudged = false; SavePos(); }
                return;
            }

            float rate = (Input.GetKey(KeyCode.LeftControl) ||
                          Input.GetKey(KeyCode.RightControl)) ? 1400f : 450f;
            float step = rate * Time.deltaTime;
            var before = _pos;

            if (Input.GetKey(KeyCode.LeftArrow))  _pos.x -= step;
            if (Input.GetKey(KeyCode.RightArrow)) _pos.x += step;
            if (Input.GetKey(KeyCode.UpArrow))    _pos.y -= step;
            if (Input.GetKey(KeyCode.DownArrow))  _pos.y += step;

            if (_pos != before) _nudged = true;

            // Shift+Home recentres without reaching for the mouse
            if (Input.GetKeyDown(KeyCode.Home)) { ResetPosition(); _nudged = false; }
        }

        void SavePos()
        {
            Plugin.PosX = _pos.x;
            Plugin.PosY = _pos.y;
        }

        /// <summary>
        /// Drag by the header strip. The header holds only labels, no controls,
        /// so consuming the mouse there cannot swallow a button click.
        /// Position is written to config on mouse-up, not every drag frame.
        /// </summary>
        void HandleDrag(Rect grip)
        {
            var e = Event.current;
            if (e == null) return;

            if (e.type == EventType.MouseDown && e.button == 0 && grip.Contains(e.mousePosition))
            {
                if (e.clickCount >= 2) { ResetPosition(); e.Use(); return; }
                _dragging = true;
                _grabOffset = e.mousePosition - _pos;
                e.Use();
            }
            else if (e.type == EventType.MouseDrag && _dragging)
            {
                _pos = e.mousePosition - _grabOffset;
                e.Use();
            }
            else if (_dragging && (e.type == EventType.MouseUp || e.type == EventType.Ignore))
            {
                _dragging = false;
                Plugin.PosX = _pos.x;
                Plugin.PosY = _pos.y;
                if (e.type == EventType.MouseUp) e.Use();
            }
        }

        /// <summary>Disarms a pending rebind and clears its message.</summary>
        void CancelRebind()
        {
            if (!_rebindArmed) return;

            _rebindArmed = false;
            _rebindOk = false;
            _rebindStatus = null;
        }

        /// <summary>
        /// Consumes the next key press as the new menu hotkey.
        ///
        /// <para>Runs from OnGUI rather than Update because
        /// <c>Event.current.keyCode</c> names the key directly — polling
        /// <c>Input</c> would mean walking every KeyCode to find which one went
        /// down. The event is consumed either way, so a key pressed during a
        /// capture never reaches the rest of the panel.</para>
        /// </summary>
        void HandleRebindCapture()
        {
            if (!_rebindArmed) return;

            Event key = Event.current;
            if (key == null || key.type != EventType.KeyDown) return;

            KeyCode pressed = key.keyCode;
            key.Use();

            // Unity raises a KeyDown with no keyCode for character input; wait
            // for the real one rather than treating it as a failed bind.
            if (pressed == KeyCode.None) return;

            if (pressed == KeyCode.Escape)
            {
                _rebindArmed = false;
                _rebindOk = false;
                _rebindStatus = $"Cancelled — still {Plugin.ToggleKeyGlyph}.";
                return;
            }

            if (Plugin.TrySetToggleKey(pressed, out string reason))
            {
                _rebindArmed = false;
                _rebindOk = true;
                _rebindStatus = $"Menu now opens with {Plugin.ToggleKeyGlyph}.";
                _suppressToggleFrames = 2;
                return;
            }

            // Rejected: stay armed so the user can simply press another key.
            _rebindOk = false;
            _rebindStatus = reason;
        }

        /// <summary>Re-centres the panel and forgets the saved position.</summary>
        void ResetPosition()
        {
            _pos = new Vector2((Screen.width - W) * 0.5f, (Screen.height - H) * 0.5f);
            Plugin.PosX = _pos.x;
            Plugin.PosY = _pos.y;
        }

        // ── chrome ───────────────────────────────────────────────────────
        void DrawHeader()
        {
            var h = new Rect(_panel.x, _panel.y, _panel.width, HEAD);

            // drag affordance — three short rules centred at the top of the
            // header, lit in rust while a drag is in progress
            var gripCol = _dragging ? Theme.RustBright : Theme.Line;
            for (int i = 0; i < 3; i++)
                Theme.Fill(new Rect(h.center.x - 14f, h.y + 4f + i * 3f, 28f, 1f), gripCol);

            // Measured, not a fixed half-panel reservation: the breadcrumb is
            // centred on the panel's centre line (under the drag grip), so the
            // title block must claim only the width its text actually needs or
            // the gap it leaves would start right of centre.
            var markText = new GUIContent("SONS OF THE FOREST");
            var buildText = new GUIContent(
                "SOTF UTIL  ·  v" + Signature.Version + "  ·  GAME 0.11.3");
            float markW = Theme.Wordmark.CalcSize(markText).x;
            float buildW = Theme.Build.CalcSize(buildText).x;
            float titleW = Mathf.Max(markW, buildW);
            GUI.Label(new Rect(h.x + PAD, h.y + 10, markW, 30),
                markText, Theme.Wordmark);
            GUI.Label(new Rect(h.x + PAD, h.y + 38, buildW, 14),
                buildText, Theme.Build);

            // Right side is laid out right-to-left from the panel edge and every
            // width is measured, so nothing can run past the border.
            float cursor = h.xMax - PAD;

            var togText = new GUIContent("TOGGLE");
            float togW = Theme.Build.CalcSize(togText).x;
            cursor -= togW;
            GUI.Label(new Rect(cursor, h.y + 21, togW, 16), togText, Theme.Build);

            var keyText = new GUIContent(Plugin.ToggleKeyGlyph);
            float keyW = Mathf.Max(20f, Theme.Kbd.CalcSize(keyText).x + 10f);
            cursor -= keyW + 7f;
            GUI.Label(new Rect(cursor, h.y + 18, keyW, 20), keyText, Theme.Kbd);

            bool inWorld = Game.InWorld;
            var statusCol = inWorld ? Theme.Live : Theme.Dead;
            var st = StatusStyle(inWorld);
            var stText = new GUIContent(inWorld ? "IN WORLD" : "NO WORLD");
            float stW = st.CalcSize(stText).x;
            cursor -= stW + 20f;
            GUI.Label(new Rect(cursor, h.y + 21, stW, 16), stText, st);
            Theme.Fill(new Rect(cursor - 12f, h.y + 25, 7, 7), statusCol);

            // Current category, plus the sections it holds. With flat navigation
            // there is no parent to name, so the second half is the page's
            // contents instead — it tells you what is on this page without
            // scrolling it, which the old "GROUP / TAB" pair never did.
            Category current = Categories[Mathf.Clamp(_tab, 0, Categories.Length - 1)];
            _chipGc.text = $"{current.Name}  ·  {current.Hint}";
            // Centred on the panel's centre line so it sits directly under the
            // drag grip, which is drawn at the same x, then clamped into the
            // free gap between the title block and the right-side cluster so a
            // long line slides sideways instead of running into either.
            float crumbLeft = h.x + PAD + titleW + 12f;
            float crumbRight = cursor - 12f;
            float crumbMaxW = Mathf.Max(0f, crumbRight - crumbLeft);
            if (crumbMaxW > 30f)
            {
                var crumbStyle = Theme.GroupLabel;
                float crumbW = Mathf.Min(crumbStyle.CalcSize(_chipGc).x, crumbMaxW);
                float crumbX = Mathf.Clamp(h.center.x - crumbW * 0.5f,
                                           crumbLeft, crumbRight - crumbW);
                GUI.Label(new Rect(crumbX, h.y + 17, crumbW, 22), _chipGc,
                          crumbStyle);

                // Accent underline: a rust bar with a slow breathing glow,
                // centred under the breadcrumb so the readout reads as the
                // header's focus without shouting.
                float barW = Mathf.Min(crumbW, 160f);
                float barX = crumbX + (crumbW - barW) * 0.5f;
                float barY = h.y + 42;
                float pulse = 0.5f + 0.5f * Mathf.Sin(Time.time * 1.8f);
                var glow = Theme.RustBright;
                glow.a = 0.08f + 0.05f * pulse;
                Theme.Fill(new Rect(barX - 4, barY - 3, barW + 8, 8), glow);
                var bar = Theme.RustBright;
                bar.a = 0.40f + 0.40f * pulse;
                Theme.Fill(new Rect(barX, barY, barW, 2), bar);
            }

            Theme.Rule(new Rect(h.x, h.yMax, h.width, 1));
        }

        /// <summary>
        /// The whole navigation: thirteen categories, one click each.
        ///
        /// <para>Rows are numbered so a category can be referred to by position
        /// as well as name. The selected row takes the rail wash plus a rust
        /// edge bar — the same treatment a hovered button now uses, so
        /// "selected" and "under the cursor" read as one visual idea.</para>
        /// </summary>
        void DrawRail()
        {
            float y = _panel.y + HEAD + RAIL_TOP_PAD;
            float rowHeight = RailRowHeight;

            for (int index = 0; index < Categories.Length; index++)
            {
                var row = new Rect(_panel.x, y, RAIL, rowHeight);
                bool selected = index == _tab;

                if (selected)
                {
                    Theme.Fill(row, Theme.RailActive);
                    Theme.Fill(new Rect(row.x, row.y, 3, row.height), Theme.RustBright);
                }

                // The whole row is the hit target, inset past the accent bar.
                if (GUI.Button(new Rect(row.x + RailLabelInset, row.y,
                                        row.width - RailLabelInset, row.height),
                               Categories[index].Name,
                               selected ? Theme.TabOn : Theme.TabOff))
                {
                    Select(index);
                }

                y += rowHeight;
            }

            Theme.Rule(new Rect(_panel.x + RAIL, _panel.y + HEAD, 1,
                                _panel.height - HEAD - FOOT));
        }

        /// <summary>
        /// Switches category and resets the per-page state that must not leak
        /// across a navigation — scroll offset and the open location dropdown.
        /// </summary>
        void Select(int index)
        {
            if (index < 0 || index >= Categories.Length) return;

            _tab = index;
            _scroll = Vector2.zero;
            _locOpen = false;

            // An armed rebind makes the hotkey deaf, and its only indicator is
            // on the SETTINGS page. Navigating away must cancel it or the user
            // is left unable to close the menu with no sign of why.
            CancelRebind();

            if (NeedsRoster(index)) _rosterDirty = true;
        }

        void DrawPane()
        {
            var pane = new Rect(_panel.x + RAIL + 1, _panel.y + HEAD + 1,
                                _panel.width - RAIL - 2,
                                _panel.height - HEAD - FOOT - 2);
            GUI.BeginGroup(pane);

            // TELEPORT splits the pane: the map draws itself and handles its own
            // clicks, so it cannot live inside a scroll view. It takes a fixed
            // block at the top and the spot/location lists scroll beneath it.
            float mapH = 0f;
            if (_tab == TabTeleportIndex)
            {
                mapH = Mathf.Round(Mathf.Min(pane.height * TeleportMapShare,
                                             pane.width - PAD * 2));
                TabTeleportMap(new Rect(0, 0, pane.width, mapH));
                Theme.Rule(new Rect(PAD, mapH, pane.width - PAD * 2, 1));
            }

            // The chip strip is gone with the flat rail, so content starts just
            // below the pane edge (or below the map on TELEPORT).
            float top = mapH + ContentTopPad;
            var inner = new Rect(0, top, pane.width, pane.height - top);

            // Scroll sensitivity: IMGUI scroll views have no sensitivity knob,
            // so the wheel is handled here. Unity's built-in step is 10px per
            // delta unit (GUI.s_ScrollStepSize); scale it by the user's
            // setting, then consume the event so the internal handler doesn't
            // also scroll. mousePosition is screen-space, hence pane offsets.
            var scrollEvent = Event.current;
            if (scrollEvent.type == EventType.ScrollWheel)
            {
                // Hands off while the cursor is over the open location list:
                // that list consumes the wheel itself, where its rect and the
                // cursor share a coordinate space and the hit test is exact.
                // DrawPane only has to avoid eating the event first.
                if (_locOpen && _locBoxInPane.Contains(scrollEvent.mousePosition))
                {
                    // deliberately nothing — the dropdown will handle it
                }
                else
                {
                    var wheel = new Rect(PAD, top,
                                         inner.width - PAD * 2, inner.height);
                    if (wheel.Contains(scrollEvent.mousePosition))
                    {
                        _scroll.y += scrollEvent.delta.y * 10f
                                     * Plugin.ScrollSensitivity;
                        scrollEvent.Use();
                    }
                }
            }

            float areaH = inner.height;

            // Published for the tab bodies: the named-locations dropdown sizes
            // itself against the space that actually exists.
            _contentViewportH = areaH;
            _contentViewportTop = top;

            GUILayout.BeginArea(new Rect(PAD, top, inner.width - PAD * 2, areaH));
            // GUIStyle.none hides the scrollbar visuals entirely; the mouse
            // wheel still scrolls (scrolling is driven by the view rect, not
            // the bar styles).
            _scroll = GUILayout.BeginScrollView(_scroll, GUIStyle.none, GUIStyle.none);

            // Order matches Categories exactly. A category with no arm here
            // would draw an empty page, so the two tables move together.
            switch (_tab)
            {
                case 0:  TabPlayer();      break;
                case 1:  TabMovement();    break;
                case 2:  TabTeleport();    break;
                case 3:  TabCombat();      break;
                case 4:  TabSpawn();       break;
                case 5:  TabGear();        break;
                case 6:  TabWorld();       break;
                case 7:  TabGameSetup();   break;
                case 8:  TabVision();      break;
                case 9:  TabOnline();      break;
                case 10: TabCheats();      break;
                case 11: TabConsole();     break;
                case 12: TabSettings();    break;
            }

            // capture the content bottom before the trailing spacer — the
            // scroll indicator below needs the scroll range
            Rect last = GUILayoutUtility.GetLastRect();
            GUILayout.Space(80);
            GUILayout.EndScrollView();
            GUILayout.EndArea();

            // scroll-position indicator: the scrollbar visuals are hidden, so
            // a slim right-edge bar shows there's more content and where you
            // are in it — otherwise a slightly-overflowing tab just looks
            // cut off at the bottom.
            float contentH = last.yMax + 80;
            if (contentH > areaH + 1f)
            {
                float maxScroll = contentH - areaH;
                float frac = Mathf.Clamp01(_scroll.y / maxScroll);
                var track = new Rect(inner.width - 10, top + 4, 3, areaH - 8);
                Theme.Fill(track, Theme.Line);
                float thumbH = Mathf.Max(24f, areaH * areaH / contentH);
                Theme.Fill(new Rect(track.x,
                                    track.y + frac * (track.height - thumbH),
                                    track.width, thumbH),
                           new Color(0.878f, 0.275f, 0.184f, 0.85f));
            }
            GUI.EndGroup();
        }

        /// <summary>
        /// The island map, drawn into the top block of the TELEPORT page.
        ///
        /// <para>Kept outside the scroll view on purpose: <see cref="Map"/> reads
        /// raw mouse position to place its teleport clicks, and a scroll view
        /// offsets those coordinates. It also samples terrain across frames, so
        /// it wants a stable rect rather than one that moves as the page scrolls.</para>
        /// </summary>
        void TabTeleportMap(Rect pane)
        {
            // The map plots remote players, so it needs a current roster. Refresh
            // once when the page opens rather than every frame — Roster.Refresh
            // walks the scene.
            if (_rosterDirty)
            {
                Roster.Refresh();
                _rosterDirty = false;
            }

            Map.Draw(new Rect(0, 0, pane.width, pane.height));
        }

        void DrawStatus()
        {
            var f = new Rect(_panel.x, _panel.yMax - FOOT, _panel.width, FOOT);
            // Inset rule so it doesn't cut through the rounded bottom corners
            float s = Theme.RoundS;
            Theme.Rule(new Rect(f.x + s, f.y, f.width - 2 * s, 1));

            // measured left-to-right flow, so segments cannot overlap
            float x = f.x + PAD;
            x += Seg("ACTIVE", Theme.StatusText, f, x) + 8f;

            // The count carries the same red → yellow → green ramp as the
            // dials: nothing on reads rust, a handful amber, a full load
            // green — semantic colour instead of a static olive.
            var countStyle = LiveStyle();
            countStyle.normal.textColor = Theme.Ramp(Features.ActiveCount() / 10f);
            x += Seg(Features.ActiveCount().ToString(), countStyle, f, x) + 20f;

            if (Esp.Enabled)
                x += Seg("ESP TRACKING " + Esp.LastDrawn, Theme.StatusText, f, x) + 20f;

            if (!string.IsNullOrEmpty(Features.LastResult))
            {
                float room = f.xMax - PAD - x;
                if (room > 60f)
                    GUI.Label(new Rect(x, f.y + 4, room, 16),
                        Features.LastResult.ToUpper(), Theme.StatusText);
            }
        }

        static float Seg(string text, GUIStyle style, Rect f, float x)
        {
            float w = style.CalcSize(new GUIContent(text)).x;
            if (x + w > f.xMax - PAD) return 0f;
            GUI.Label(new Rect(x, f.y + 4, w, 16), text, style);
            return w;
        }
    }
}

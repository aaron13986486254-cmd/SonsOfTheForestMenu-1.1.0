// ═══════════════════════════════════════════════════════════════════════════
//  Plugin.cs · BepInEx entry point, configuration, and boot sequence
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Unity.IL2CPP;
using HarmonyLib;
using Il2CppInterop.Runtime.Injection;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// BepInEx entry point.
///
/// <para>Owns three things and nothing else: the config entries, the boot
/// sequence, and the single <see cref="GameObject"/> the menu lives on. All
/// behaviour lives in the types this constructs — keeping Load readable is
/// worth more than saving a file.</para>
///
/// <para><b>Boot is ordered deliberately.</b> Each stage is guarded so it
/// cannot take the next one down with it, and they are sequenced by blast
/// radius: config first (pure, cannot meaningfully fail), then the IL2CPP type
/// registration the menu cannot start without, then the Harmony patches, then
/// the optional log filters, then the component. A failure past the first
/// stage costs one feature rather than the whole panel.</para>
///
/// <para>Not marked with <c>[Cyberfox1337x]</c>: this type's shape is dictated
/// by <see cref="BasePlugin"/>, so its name and entry point are not ours to
/// change.</para>
/// </summary>
[BepInPlugin(Signature.Guid, Signature.Name, Signature.Version)]
[Cyberfox1337x("entry point", Bound = "BasePlugin.Load override; GUID names the config file")]
public sealed class Plugin : BasePlugin
{
    // ── config bounds ───────────────────────────────────────────────────
    // Named rather than inline so the clamp, the config comment and the
    // SETTINGS-tab dial cannot drift apart.

    const float OpacityMin = 0.3f, OpacityMax = 1.0f, OpacityDefault = 0.94f;
    const float RadiusMin = 4f, RadiusMax = 20f, RadiusDefault = 10f;
    const float ScrollMin = 0.25f, ScrollMax = 3f, ScrollDefault = 1f;

    /// <summary>
    /// Config file left behind by the previous plugin name. Read once at boot
    /// to carry settings forward; never written.
    /// </summary>
    const string LegacyConfigName = "com.stormfest.sonsofthedead.cfg";

    // ── runtime state ───────────────────────────────────────────────────

    internal static Harmony Harmony { get; private set; }

    /// <summary>Key that opens the panel. Bound from config at load.</summary>
    internal static KeyCode ToggleKey { get; private set; } = KeyCode.BackQuote;

    /// <summary>Short display form of <see cref="ToggleKey"/> for the header keycap.</summary>
    internal static string ToggleKeyGlyph { get; private set; } = "`";

    /// <summary>
    /// Rebinds the key that opens the menu, and writes it straight to disk.
    ///
    /// <para>Flushed immediately rather than on exit. A hotkey the user cannot
    /// reproduce is a hotkey they cannot get back into the menu to change, so
    /// losing this to an unclean shutdown is worse than losing an ordinary
    /// preference.</para>
    /// </summary>
    /// <param name="reason">Why the key was refused; null on success.</param>
    /// <returns>False if the key was rejected, leaving the binding untouched.</returns>
    internal static bool TrySetToggleKey(KeyCode key, out string reason)
    {
        if (_toggle is null)
        {
            reason = "Configuration is not loaded yet.";
            return false;
        }

        if (key == KeyCode.None)
        {
            reason = "That key could not be read — try another.";
            return false;
        }

        if (IsModifier(key))
        {
            reason = $"{key} is a modifier. Pick a key that can be pressed on its own.";
            return false;
        }

        _toggle.Value = key;
        ToggleKey = key;
        ToggleKeyGlyph = GlyphFor(key);
        SaveConfig();

        Diag.Info($"Menu hotkey rebound to {key}.");
        reason = null;
        return true;
    }

    /// <summary>
    /// Modifiers cannot be the toggle on their own: they are reported as held
    /// rather than pressed, and Shift is already the panel's nudge modifier.
    /// </summary>
    static bool IsModifier(KeyCode key) => key switch
    {
        KeyCode.LeftShift or KeyCode.RightShift => true,
        KeyCode.LeftControl or KeyCode.RightControl => true,
        KeyCode.LeftAlt or KeyCode.RightAlt or KeyCode.AltGr => true,
        KeyCode.LeftCommand or KeyCode.RightCommand => true,
        KeyCode.LeftWindows or KeyCode.RightWindows => true,
        _ => false,
    };

    static ConfigFile _config;
    static ConfigEntry<KeyCode> _toggle;
    static ConfigEntry<float> _posX, _posY;
    static ConfigEntry<string> _apiKey;
    static ConfigEntry<float> _opacity, _cornerRadius, _scrollSensitivity;

    // ── persisted preferences ───────────────────────────────────────────
    //
    // Each is a property over a ConfigEntry rather than the entry itself, so
    // callers never see BepInEx types, a read before Load returns a sane
    // default instead of throwing, and every bounded value is clamped on the
    // way out. The clamp lives on read because a user may hand-edit the cfg to
    // anything at all.

    /// <summary>Panel left edge in pixels. NaN means "centre me".</summary>
    internal static float PosX
    {
        get => _posX?.Value ?? float.NaN;
        set { if (_posX != null) _posX.Value = value; }
    }

    /// <summary>Panel top edge in pixels. NaN means "centre me".</summary>
    internal static float PosY
    {
        get => _posY?.Value ?? float.NaN;
        set { if (_posY != null) _posY.Value = value; }
    }

    /// <summary>
    /// The user's own Steam Web API key, used only to fetch roster avatars.
    /// Never logged in full — see <see cref="Diag.Redact"/>.
    /// </summary>
    internal static string SteamApiKey
    {
        get => _apiKey?.Value ?? string.Empty;
        set { if (_apiKey != null) _apiKey.Value = value ?? string.Empty; }
    }

    /// <summary>Panel background opacity.</summary>
    internal static float MenuOpacity
    {
        get => _opacity is null
            ? OpacityDefault
            : Mathf.Clamp(_opacity.Value, OpacityMin, OpacityMax);
        set { if (_opacity != null) _opacity.Value = value; }
    }

    /// <summary>Panel corner radius in pixels.</summary>
    internal static float CornerRadius
    {
        get => _cornerRadius is null
            ? RadiusDefault
            : Mathf.Clamp(_cornerRadius.Value, RadiusMin, RadiusMax);
        set { if (_cornerRadius != null) _cornerRadius.Value = value; }
    }

    /// <summary>Mouse-wheel speed multiplier for the scrolling panes.</summary>
    internal static float ScrollSensitivity
    {
        get => _scrollSensitivity is null
            ? ScrollDefault
            : Mathf.Clamp(_scrollSensitivity.Value, ScrollMin, ScrollMax);
        set { if (_scrollSensitivity != null) _scrollSensitivity.Value = value; }
    }

    /// <summary>
    /// Flushes config to disk immediately.
    ///
    /// <para>BepInEx only writes on a clean exit. The SETTINGS tab calls this
    /// after SAVE KEY so a freshly pasted Steam key survives an unclean close —
    /// which, for a game people alt-F4 out of, is the common case.</para>
    /// </summary>
    internal static void SaveConfig() =>
        Safe.Run("config.save", () => _config?.Save(), Noise.Warn);

    // ── boot ────────────────────────────────────────────────────────────

    public override void Load()
    {
        Diag.Bind(base.Log);

        BindConfiguration();
        MigrateLegacyConfig();
        StartServices();

        if (!RegisterMenuType()) return;   // hard requirement; nothing works without it

        ApplyHarmonyPatches();
        ApplyLogFilters();
        SpawnMenuHost();

        Diag.Info(Signature.BootLine(ToggleKey.ToString()));
    }

    /// <summary>
    /// Declares every config entry.
    ///
    /// <para>Section and key names are frozen. They are the on-disk contract
    /// with the user's existing cfg — <c>Hotkeys/Toggle</c> in particular dates
    /// back to the original mod, so an old bind still carries over.</para>
    /// </summary>
    void BindConfiguration()
    {
        _config = Config;

        _toggle = Config.Bind("Hotkeys", "Toggle", KeyCode.BackQuote,
            "Toggles menu visibility");

        ToggleKey = _toggle.Value;
        ToggleKeyGlyph = GlyphFor(ToggleKey);

        _posX = Config.Bind("Window", "PosX", float.NaN,
            "Panel X. NaN centres it. Saved when you drag.");
        _posY = Config.Bind("Window", "PosY", float.NaN,
            "Panel Y. NaN centres it. Saved when you drag.");

        // Default is deliberately empty. The shipped DLL must never embed a
        // personal API key; an existing cfg keeps whatever the user saved.
        _apiKey = Config.Bind("Steam", "ApiKey", string.Empty,
            "Steam Web API key used to fetch player avatars for the roster. " +
            "Get one at https://steamcommunity.com/dev/apikey");

        _opacity = Config.Bind("Menu", "Opacity", OpacityDefault,
            $"Panel background opacity ({OpacityMin} - {OpacityMax}).");
        _cornerRadius = Config.Bind("Menu", "CornerRadius", RadiusDefault,
            $"Panel corner radius in pixels ({RadiusMin} - {RadiusMax}).");
        _scrollSensitivity = Config.Bind("Menu", "ScrollSensitivity", ScrollDefault,
            $"Scroll wheel speed multiplier ({ScrollMin} - {ScrollMax}).");
    }

    /// <summary>Brings up the subsystems that need state before the first frame.</summary>
    void StartServices()
    {
        string key = SteamApiKey;

        if (string.IsNullOrWhiteSpace(key))
        {
            Diag.Warn("Steam.ApiKey is empty — roster avatars will not fetch " +
                     "until you set a key (SETTINGS tab, or the config file).");
        }
        else
        {
            Diag.Info($"Steam.ApiKey loaded {Diag.Redact(key)}.");
        }

        Avatars.Init(key);
        Teleport.Load();
    }

    /// <summary>
    /// Registers the menu component with IL2CPP.
    ///
    /// <para>The only genuinely fatal step in Load. A MonoBehaviour that is not
    /// registered cannot be added to a GameObject, so there is no degraded mode
    /// to fall back to — stop, and say so plainly.</para>
    /// </summary>
    /// <returns>False if registration failed and boot should stop.</returns>
    bool RegisterMenuType()
    {
        bool registered = Safe.Run("boot.register-menu-type",
            () => ClassInjector.RegisterTypeInIl2Cpp<MenuWindow>(), Noise.Fatal);

        if (!registered)
        {
            Diag.Error("Menu type could not be registered with IL2CPP; the panel " +
                      "will not load and everything else is inert.");
        }

        return registered;
    }

    /// <summary>
    /// Applies the attribute-driven patches: god mode, damage scaling, ammo.
    /// A failure costs those features but leaves the menu usable, so it is
    /// reported and stepped over rather than aborting boot.
    /// </summary>
    void ApplyHarmonyPatches()
    {
        bool patched = Safe.Run("boot.harmony-patchall", () =>
        {
            Harmony = new Harmony(Signature.Guid);
            Harmony.PatchAll(Assembly.GetExecutingAssembly());
        }, Noise.Fatal);

        if (patched)
        {
            Diag.Info("Harmony patches applied (god mode, damage scale, infinite ammo).");
        }
        else
        {
            Diag.Error("Harmony patching failed — god mode falls back to health-" +
                      "pegging, which can still lose the race on a one-shot kill.");
        }
    }

    /// <summary>
    /// Applies the boot-noise log filters.
    ///
    /// <para>Deliberately separate from <see cref="ApplyHarmonyPatches"/>. These
    /// bind by reflection against <see cref="Debug"/> overloads that interop
    /// could rename, and they are pure cosmetics — a failure here must never
    /// cost the god-mode patch, which is exactly what would happen if the two
    /// shared a guard.</para>
    /// </summary>
    void ApplyLogFilters()
    {
        if (Harmony is null) return;   // PatchAll failed; nothing to attach to

        bool filtered = Safe.Run("boot.log-filters", () =>
        {
            PatchDebugOverload(nameof(Debug.LogError), typeof(Patch_Debug_LogError));
            PatchDebugOverload(nameof(Debug.LogWarning), typeof(Patch_Debug_LogWarning));
        }, Noise.Warn);

        if (filtered) Diag.Info("Boot-noise filters applied (console-clean boot).");
    }

    /// <summary>
    /// Patches one <see cref="Debug"/> overload with the given prefix holder.
    ///
    /// <para>The interop surface types the parameter as
    /// <c>Il2CppSystem.Object</c>; <c>System.Object</c> does not resolve, and
    /// selecting the wrong overload silently patches nothing — hence the
    /// explicit signature and the hard failure when it cannot be found.</para>
    /// </summary>
    static void PatchDebugOverload(string methodName, Type prefixHolder)
    {
        MethodBase target = AccessTools.Method(
            typeof(Debug), methodName, new[] { typeof(Il2CppSystem.Object) });

        if (target is null)
        {
            throw new InvalidOperationException(
                $"{methodName}(Il2CppSystem.Object) not found on UnityEngine.Debug");
        }

        Harmony.Patch(target, prefix: new HarmonyMethod(prefixHolder, "Prefix"));
    }

    /// <summary>
    /// Creates the persistent host the menu component rides on. Hidden from the
    /// hierarchy and flagged DontDestroyOnLoad so it survives every scene change
    /// between the title screen and a loaded save.
    /// </summary>
    void SpawnMenuHost()
    {
        Safe.Run("boot.spawn-menu-host", () =>
        {
            var host = new GameObject("Cyberfox1337x.SonsOfTheForest.Menu")
            {
                hideFlags = HideFlags.HideAndDontSave,
            };

            UnityEngine.Object.DontDestroyOnLoad(host);
            host.AddComponent<MenuWindow>();
        }, Noise.Fatal);
    }

    // ── legacy config migration ─────────────────────────────────────────

    /// <summary>
    /// Carries the Steam key and window position over from the config written
    /// under the plugin's previous GUID.
    ///
    /// <para>Only fills values still at their defaults, so migration can never
    /// clobber something the user set deliberately. A no-op on fresh installs:
    /// the old file simply does not exist.</para>
    /// </summary>
    static void MigrateLegacyConfig()
    {
        string legacyPath = Path.Combine(Paths.ConfigPath, LegacyConfigName);
        if (!File.Exists(legacyPath)) return;

        Dictionary<string, string> legacy = Safe.Get("config.read-legacy",
            legacyPath, ReadIniFlat, fallback: null, noise: Noise.Warn);

        if (legacy is null) return;

        if (_apiKey.Value.Length == 0 &&
            legacy.TryGetValue("Steam.ApiKey", out string key) && key.Length > 0)
        {
            _apiKey.Value = key;
            Diag.Info($"Migrated Steam API key from {LegacyConfigName} {Diag.Redact(key)}.");
        }

        if (float.IsNaN(_posX.Value) && TryReadFloat(legacy, "Window.PosX", out float x))
            _posX.Value = x;

        if (float.IsNaN(_posY.Value) && TryReadFloat(legacy, "Window.PosY", out float y))
            _posY.Value = y;
    }

    /// <summary>
    /// Flattens a BepInEx cfg into "Section.Key" → value.
    ///
    /// <para>A deliberately small INI reader rather than a general parser: the
    /// only file it will ever see is one BepInEx wrote, and it is read for two
    /// known keys. Unparseable lines are skipped rather than rejected, because a
    /// partially readable legacy file should still surrender the key.</para>
    /// </summary>
    static Dictionary<string, string> ReadIniFlat(string path)
    {
        var values = new Dictionary<string, string>(StringComparer.Ordinal);
        string section = string.Empty;

        foreach (string rawLine in File.ReadAllLines(path))
        {
            string line = rawLine.Trim();
            if (line.Length == 0 || line[0] == '#') continue;

            if (line[0] == '[' && line[line.Length - 1] == ']')
            {
                section = line.Substring(1, line.Length - 2);
                continue;
            }

            int separator = line.IndexOf('=');
            if (separator <= 0) continue;

            string key = line.Substring(0, separator).Trim();
            string value = line.Substring(separator + 1).Trim();
            values[$"{section}.{key}"] = value;
        }

        return values;
    }

    /// <summary>
    /// Invariant-culture float read. Explicitly invariant because BepInEx writes
    /// with a dot; on a comma-locale machine a culture-sensitive parse would
    /// silently fail to restore the window position.
    /// </summary>
    static bool TryReadFloat(Dictionary<string, string> values, string key, out float result)
    {
        result = 0f;
        return values.TryGetValue(key, out string raw)
            && float.TryParse(raw, NumberStyles.Float, CultureInfo.InvariantCulture, out result);
    }

    // ── display helpers ─────────────────────────────────────────────────

    /// <summary>
    /// Short label for a key, for the header's keycap. Only the keys whose enum
    /// name reads badly at a glance are special-cased; the rest are clear as-is.
    /// </summary>
    static string GlyphFor(KeyCode key) => key switch
    {
        KeyCode.BackQuote => "`",
        KeyCode.Tab       => "TAB",
        KeyCode.Insert    => "INS",
        KeyCode.Delete    => "DEL",
        KeyCode.Home      => "HOME",
        _                 => key.ToString(),
    };
}

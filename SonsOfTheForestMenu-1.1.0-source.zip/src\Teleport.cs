// ═══════════════════════════════════════════════════════════════════════════
//  Teleport.cs · saved teleport spots and their JSON persistence
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System.Collections.Generic;
using System.IO;
using System.Text.Json;
using BepInEx;
using TheForest.Utils;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// User-saved teleport spots, persisted beside the plugin config.
///
/// <para>Travel always routes through <c>LocalPlayer.Goto</c> — the same helper
/// the game's own <c>goto</c> command uses — rather than writing the transform
/// directly. Goto places the player on the ground; a raw position write drops
/// them inside terrain or leaves them falling.</para>
/// </summary>
[Cyberfox1337x("saved spots")]
internal static class Teleport
{
    /// <summary>
    /// On-disk file name. Frozen: renaming it orphans every spot the user has
    /// already saved, and this file predates the plugin's rename.
    /// </summary>
    const string StoreFileName = "sonsofthedead_spots.json";

    /// <summary>A named world position the user can return to.</summary>
    internal struct Spot
    {
        internal string Name;
        internal Vector3 Pos;
        internal float R, G, B;
    }

    /// <summary>Live spot list. Index order is the UI's order.</summary>
    internal static readonly List<Spot> Spots = new();

    static string _path;

    /// <summary>Resolved lazily: BepInEx paths are not valid before Load.</summary>
    static string StorePath =>
        _path ??= Path.Combine(Paths.ConfigPath, StoreFileName);

    // ── persistence ─────────────────────────────────────────────────────

    /// <summary>
    /// Loads saved spots. A missing file is the normal first-run case and is
    /// not an error; a corrupt one is reported and leaves the list empty rather
    /// than taking the plugin down at boot.
    /// </summary>
    internal static void Load()
    {
        if (!File.Exists(StorePath)) return;

        List<SpotRecord> records = Safe.Get("spots.load", StorePath,
            path => JsonSerializer.Deserialize<List<SpotRecord>>(File.ReadAllText(path)),
            fallback: null, noise: Noise.Warn);

        if (records is null) return;

        Spots.Clear();
        foreach (SpotRecord record in records)
        {
            Spots.Add(new Spot
            {
                Name = record.Name,
                Pos = new Vector3(record.X, record.Y, record.Z),
                R = record.R,
                G = record.G,
                B = record.B,
            });
        }

        Diag.Info($"Loaded {Spots.Count} teleport spot(s).");
    }

    /// <summary>
    /// Writes the spot list out. Called after every mutation rather than at
    /// shutdown, because the game is frequently closed without one.
    /// </summary>
    internal static void Save()
    {
        var records = new List<SpotRecord>(Spots.Count);
        foreach (Spot spot in Spots)
        {
            records.Add(new SpotRecord
            {
                Name = spot.Name,
                X = spot.Pos.x,
                Y = spot.Pos.y,
                Z = spot.Pos.z,
                R = spot.R,
                G = spot.G,
                B = spot.B,
            });
        }

        Safe.Run("spots.save", () =>
            File.WriteAllText(StorePath, JsonSerializer.Serialize(records)), Noise.Warn);
    }

    // ── commands ────────────────────────────────────────────────────────

    /// <summary>Records the player's current position under the given name.</summary>
    internal static void SaveCurrent(string name)
    {
        Transform player = Game.PlayerTransform;
        if (player == null)
        {
            Features.LastResult = "Needs a loaded world";
            return;
        }

        if (string.IsNullOrWhiteSpace(name))
            name = $"Spot {Spots.Count + 1}";

        Spots.Add(new Spot
        {
            Name = name,
            Pos = player.position,
            R = 1f,
            G = 1f,
            B = 1f,
        });

        Save();
        Features.LastResult = $"Saved spot \"{name}\"";
    }

    /// <summary>Moves the player to the spot at <paramref name="index"/>.</summary>
    internal static void TeleportTo(int index)
    {
        if (!TryGet(index, out Spot spot)) return;

        bool moved = Safe.Run("spots.goto", spot.Pos,
            position => LocalPlayer._instance.Goto(position), Noise.Warn);

        Features.LastResult = moved
            ? $"Teleported to \"{spot.Name}\""
            : "Teleport failed";
    }

    /// <summary>Deletes a spot and persists the change immediately.</summary>
    internal static void RemoveAt(int index)
    {
        if (!TryGet(index, out _)) return;

        Spots.RemoveAt(index);
        Save();
    }

    /// <summary>
    /// Bounds-checked read. The UI can hand us a stale index when a row is
    /// removed during the same frame it is drawn, so every entry point
    /// validates rather than trusting the caller.
    /// </summary>
    static bool TryGet(int index, out Spot spot)
    {
        if (index >= 0 && index < Spots.Count)
        {
            spot = Spots[index];
            return true;
        }

        spot = default;
        return false;
    }

    // ── serialised form ─────────────────────────────────────────────────

    /// <summary>
    /// On-disk shape of a <see cref="Spot"/>.
    ///
    /// <para>These property names are the JSON keys in a file users already
    /// have on disk — a serialisation contract, not our naming, so none of them
    /// may be renamed. Public settable properties because System.Text.Json
    /// requires both.</para>
    /// </summary>
    [Cyberfox1337x("spot DTO",
                   Bound = "property names are JSON keys in sonsofthedead_spots.json")]
    sealed class SpotRecord
    {
        public string Name { get; set; }
        public float X { get; set; }
        public float Y { get; set; }
        public float Z { get; set; }
        public float R { get; set; }
        public float G { get; set; }
        public float B { get; set; }
    }
}

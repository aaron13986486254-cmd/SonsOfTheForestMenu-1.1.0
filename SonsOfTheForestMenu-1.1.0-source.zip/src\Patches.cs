// ═══════════════════════════════════════════════════════════════════════════
//  Patches.cs · Harmony patches on the game's own damage and log paths
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using HarmonyLib;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// God mode, enforced at the source rather than by healing after the fact.
///
/// <para>Topping health up each frame loses the race whenever a single hit
/// exceeds max health, or when death triggers before the next tick — which is
/// why it remained possible to die with the toggle on. Blocking
/// <c>TriggerDeath</c> outright cannot lose that race.</para>
///
/// <para>A prefix returning false skips the original method.</para>
/// </summary>
[HarmonyPatch(typeof(Vitals), nameof(Vitals.TriggerDeath))]
[Cyberfox1337x("god mode", Bound = "Harmony target Vitals.TriggerDeath; Prefix matched by name")]
internal static class Patch_Vitals_TriggerDeath
{
    static bool Prefix()
    {
        if (!Features.GodMode) return true;

        Diag.Once("godmode.death-suppressed", "god mode: death suppressed");
        return false;
    }
}

/// <summary>
/// Stops damage landing at all while god mode is on, and otherwise applies the
/// Damage Taken multiplier.
///
/// <para>The multiplier scales the value <i>before</i> the original runs, so
/// the HUD and every downstream system see one consistent number rather than
/// the raw hit followed by a correction.</para>
/// </summary>
[HarmonyPatch(typeof(Vitals), nameof(Vitals.ApplyDamage))]
[Cyberfox1337x("damage scaling", Bound = "Harmony target Vitals.ApplyDamage; Prefix matched by name")]
internal static class Patch_Vitals_ApplyDamage
{
    /// <summary>Below this, the multiplier is 1.0 and not worth touching.</summary>
    const float MultiplierEpsilon = 0.0005f;

    static bool Prefix(ref float value)
    {
        if (Features.GodMode) return false;

        float multiplier = Features.DamageTakenMult;
        if (Mathf.Abs(multiplier - 1f) > MultiplierEpsilon)
            value *= multiplier;

        return true;
    }
}

/// <summary>
/// Infinite Ammo, stopping the weapon spending its magazine at all rather than
/// topping it back up every frame. The controller raises this each time a round
/// is consumed, so suppressing it is the earliest correct point to intervene.
/// </summary>
[HarmonyPatch(typeof(Sons.Weapon.RangedWeaponController),
              nameof(Sons.Weapon.RangedWeaponController.OnAmmoSpent))]
[Cyberfox1337x("infinite ammo", Bound = "Harmony target RangedWeaponController.OnAmmoSpent")]
internal static class Patch_AmmoSpent
{
    static bool Prefix() => !Features.InfAmmo;
}

/// <summary>
/// Boot-noise filters for <see cref="Debug"/>.
///
/// <para>Both messages below are stock game noise, verified against
/// <c>Player.log</c> call stacks with no mod frames anywhere. They are dropped
/// so the BepInEx console stays readable at startup — a log that cries wolf
/// twice every boot is a log nobody reads.</para>
///
/// <para>These are applied separately from <c>PatchAll</c> (see
/// <see cref="Plugin.Load"/>) so a binding failure here can never abort the
/// god-mode and ammo patches above.</para>
///
/// <para>Both parameters are typed <c>Il2CppSystem.Object</c> because that is
/// what the interop surface exposes; <c>System.Object</c> does not resolve.</para>
/// </summary>
[Cyberfox1337x("boot-noise filter", Bound = "Harmony prefix bound by reflection in Plugin")]
internal static class Patch_Debug_LogError
{
    /// <summary>
    /// Matched by prefix rather than exact string: both messages carry
    /// run-varying suffixes (instance ids, requested mode names).
    ///
    ///  • "Missing GameSettingsManager Instance!" — FpsLimiter and LoadScene
    ///    query the singleton before its Awake has run at boot, then fall back
    ///    to default FPS caps.
    ///  • "Invalid fullscreen mode …" — the game briefly requests Exclusive
    ///    FullScreen during startup and Unity's display path rewrites it; the
    ///    message is emitted before the resolution is corrected.
    /// </summary>
    static bool Prefix(Il2CppSystem.Object message)
    {
        if (message == null) return true;

        string text = message.ToString();
        return !(text.Contains("Missing GameSettingsManager Instance!")
              || text.StartsWith("Invalid fullscreen mode"));
    }
}

/// <summary>
/// Same treatment for the harmless-but-noisy warnings: a duplicate FpsLimiter
/// on the title scene (the scene is rebuilt with two, the game keeps the
/// latest) and an FMOD voice count that is already set to the requested value.
/// </summary>
[Cyberfox1337x("boot-noise filter", Bound = "Harmony prefix bound by reflection in Plugin")]
internal static class Patch_Debug_LogWarning
{
    static bool Prefix(Il2CppSystem.Object message)
    {
        if (message == null) return true;

        string text = message.ToString();
        return !(text.StartsWith("Duplicate FpsLimiter")
              || text.StartsWith("Already set to the same number of voices"));
    }
}

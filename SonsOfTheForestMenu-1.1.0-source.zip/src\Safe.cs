// ═══════════════════════════════════════════════════════════════════════════
//  Safe.cs · the single guarded seam between this plugin and the game
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// How loudly a guarded site reports when it throws.
/// </summary>
[Cyberfox1337x]
internal enum Noise
{
    /// <summary>
    /// Expected. The object was torn down between frames, or the menu is being
    /// drawn on the title screen where no world exists yet. Reported once per
    /// site, then suppressed; the next tick simply retries.
    /// </summary>
    Transient,

    /// <summary>
    /// Not expected, but the plugin carries on with a fallback. Warned every
    /// time, because a repeat here is genuine signal.
    /// </summary>
    Warn,

    /// <summary>
    /// The feature cannot work at all. Logged as an error every time.
    /// </summary>
    Fatal,
}

/// <summary>
/// Every call into the game's IL2CPP surface goes through here.
///
/// <para><b>Why this exists.</b> Reaching into a live Unity/IL2CPP object is
/// unsafe in a way ordinary managed code is not: the menu draws on the title
/// screen where <c>LocalPlayer</c> does not exist, the per-frame tick can catch
/// a component midway through teardown, and an interop wrapper whose native
/// object has been freed throws rather than returning null. The honest options
/// are to guard every one of those touches or to crash the game.</para>
///
/// <para>Guarding them inline produced 117 hand-written try/catch blocks, 17 of
/// them completely bare — which is to say 17 places where a real failure
/// vanished without a trace. This type replaces all of them with one seam that
/// decides, in a single auditable place, what gets logged, what gets swallowed,
/// and what is genuinely fatal.</para>
///
/// <para><b>Every guarded call is named.</b> The <c>site</c> parameter comes
/// first so each line self-labels, and it doubles as the suppression key for
/// <see cref="Noise.Transient"/>. Sites are dotted lowercase — <c>player.vitals</c>,
/// <c>esp.actor-list</c>, <c>roster.steam-id</c> — so a log line points straight
/// at the code that produced it and the whole set greps cleanly.</para>
///
/// <para><b>Allocation.</b> The overloads taking a <c>state</c> argument exist
/// because this runs every frame. A lambda that captures a local allocates a
/// closure on each call; a lambda that captures nothing is cached once by the
/// compiler into a static field. Passing the operand through <c>state</c> keeps
/// the lambda non-capturing, so the per-frame paths allocate nothing at all.
/// Prefer the <c>state</c> overloads inside any tick or draw path.</para>
/// </summary>
[Cyberfox1337x("guarded interop seam")]
internal static class Safe
{
    // ── void work ───────────────────────────────────────────────────────

    /// <summary>Runs <paramref name="work"/>, absorbing anything it throws.</summary>
    /// <returns>True when it completed without throwing.</returns>
    internal static bool Run(string site, Action work, Noise noise = Noise.Transient)
    {
        if (work is null) return false;

        try
        {
            work();
            return true;
        }
        catch (Exception error)
        {
            Report(site, error, noise);
            return false;
        }
    }

    /// <summary>
    /// Non-allocating form of <see cref="Run(string, Action, Noise)"/>: the
    /// operand travels through <paramref name="state"/> so the lambda stays
    /// non-capturing. Use this on per-frame paths.
    /// </summary>
    internal static bool Run<TState>(string site, TState state, Action<TState> work,
                                     Noise noise = Noise.Transient)
    {
        if (work is null) return false;

        try
        {
            work(state);
            return true;
        }
        catch (Exception error)
        {
            Report(site, error, noise);
            return false;
        }
    }

    // ── value reads ─────────────────────────────────────────────────────

    /// <summary>
    /// Reads a value, returning <paramref name="fallback"/> if the read throws.
    /// </summary>
    internal static TResult Get<TResult>(string site, Func<TResult> read,
                                         TResult fallback = default,
                                         Noise noise = Noise.Transient)
    {
        if (read is null) return fallback;

        try
        {
            return read();
        }
        catch (Exception error)
        {
            Report(site, error, noise);
            return fallback;
        }
    }

    /// <summary>
    /// Non-allocating form of <see cref="Get{TResult}(string, Func{TResult}, TResult, Noise)"/>.
    /// Use this on per-frame paths.
    /// </summary>
    internal static TResult Get<TState, TResult>(string site, TState state,
                                                 Func<TState, TResult> read,
                                                 TResult fallback = default,
                                                 Noise noise = Noise.Transient)
    {
        if (read is null) return fallback;

        try
        {
            return read(state);
        }
        catch (Exception error)
        {
            Report(site, error, noise);
            return fallback;
        }
    }

    // ── reporting ───────────────────────────────────────────────────────

    /// <summary>
    /// The one place that turns a caught exception into output. Kept private so
    /// the <see cref="Noise"/> contract cannot be bypassed from outside.
    /// </summary>
    static void Report(string site, Exception error, Noise noise)
    {
        string detail = Diag.Describe(error);

        switch (noise)
        {
            case Noise.Fatal:
                Diag.Error($"[{site}] {detail}");
                break;

            case Noise.Warn:
                Diag.Warn($"[{site}] {detail}");
                break;

            default:
                // Transient: teardown races and title-screen reads. One line so
                // the failure is discoverable, then silence so a per-frame site
                // cannot flood the log.
                Diag.Once(site, $"[{site}] {detail}");
                break;
        }
    }
}

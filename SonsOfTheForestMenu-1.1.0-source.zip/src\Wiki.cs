// ═══════════════════════════════════════════════════════════════════════════
//  Wiki.cs · community command descriptions and locations
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System.Collections.Generic;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// Community-documented console surface, extracted from the wiki
    /// (sonsoftheforest.wiki.gg/wiki/Console_commands): plain-English
    /// descriptions for the commands in Commands.All, the setGameSetupSetting
    /// game-start settings, and named goto locations.
    ///
    /// Everything here is data the game's own debug console accepts —
    /// descriptions are human-readable text only, no game API calls.
    /// </summary>
    [Cyberfox1337x]
    internal static class Wiki
    {
        /// <summary>
        /// command name (lowercased, matches Commands.All) -&gt; what it does.
        /// Only commands that exist in Commands.All get an entry, so a lookup
        /// that succeeds is guaranteed to be runnable.
        /// </summary>
        public static readonly Dictionary<string, string> Desc =
            new Dictionary<string, string>
            {
                // ── common ───────────────────────────────────────────────
                { "addallitems", "Adds every item in the game to the player's inventory." },
                { "setinventorypercent", "Scales every stackable item in the inventory to a percentage (50 = half of each stack)." },
                { "addcharacter", "Spawns a character by key, e.g. 'addcharacter robby 5'. See the SPAWN tab for the full roster." },
                { "cavelight", "Attaches a bright light to the player — very useful in caves." },
                { "season", "Switches the season: summer, autumn, winter or spring." },
                { "invisible", "Makes the player invisible to enemies." },
                { "creepyvillage", "Spawns mutants in cannibal villages and lets them fight each other." },
                { "killradius", "Kills everything (including Kelvin and Virginia) within a radius around the player." },
                { "goto", "Teleports to a named place, or to X Y Z coordinates: 'goto 1461.84 88.52 749.52'." },
                { "gotocoords", "Teleports to a set of coordinates (comma-separated)." },
                { "gotoforce", "Teleports to a named place even if it is not normally reachable." },
                { "gototag", "Teleports to a tagged object." },
                { "togglego", "Turns a named game object on/off — e.g. 'togglego CrestOcean' to remove the ocean." },
                { "disablego", "Disables a named game object, e.g. 'disablego CaveHEntranceCover'." },
                { "enablego", "Enables a named game object." },
                { "destroy", "Destroys a named structure or object. Use with toggleStructureResistanceDebug to see names." },
                { "destroywildcard", "Destroys every object whose name contains the given text." },
                { "disablegowildcard", "Disables every object whose name contains the given text." },

                // ── AI ───────────────────────────────────────────────────
                { "aiangerlevel", "Changes the anger level for all cannibals on the island." },
                { "aianimspeed", "Scales AI animation speed — 0.1 is slow motion, 5 is super fast." },
                { "aiarmorlevel", "Changes the armor level cannibals can spawn with." },
                { "aiarmortier", "Sets the cannibal armor tier: 0 none, 1 leaf, 2 bone, 3 creepy, 4 solafite." },
                { "aidisable", "Disables and removes every AI — including Kelvin and Virginia." },
                { "aidummy", "Makes AI ignore the player entirely." },
                { "aighostplayer", "Makes the player invisible to AI." },
                { "aigodmode", "Makes all AI enemies invincible." },
                { "aiknockdowndisable", "Disables AI knockdowns." },
                { "aipoolstats", "Shows how many AI are active and how many are pooled." },
                { "airadar", "Shows how far AI are from the player." },
                { "aishowanims", "Shows the current animation each AI is performing." },
                { "aishoweventmemory", "Shows events registered by each AI." },
                { "aishowhealth", "Shows a health box below each AI." },
                { "aishownavgraph", "Shows the navmesh AI use to navigate — useful for tracking Kelvin and Virginia." },
                { "aishowpaths", "Shows the paths AI take." },
                { "aishowplayerinfluences", "Shows player-influence values on each AI." },
                { "aishowstats", "Shows general stats for each AI." },
                { "aishowsurvivalstats", "Shows survival stats (fullness, hydration, energy) for each AI." },
                { "aishowthoughts", "Shows thoughts in a box below each AI." },
                { "aitestsleep", "Puts every AI into a state that prompts them to sleep." },
                { "aithought", "Allows AI to think a thought." },
                { "aivailstats", "Shows AI Vail stats." },
                { "aivillageclosest", "Shows how close cannibals are to their nearest village." },
                { "aiworldeventstats", "Shows world-event stats for AI — how angry they could get." },
                { "aiworldstats", "Lists all AI in the world." },
                { "aizonestats", "Shows how many AI are in each area." },
                { "animalsenabled", "Turns animals on and off." },
                { "astar", "Toggles A* pathfinding — with it off AI walk into walls." },

                // ── time ─────────────────────────────────────────────────
                { "timescale", "Scales game speed — 0 pauses, 1 normal, 2 doubles, 3 triples. Avoid over 10." },
                { "settimeofday", "Sets the time of day in 24-hour time, e.g. 'setTimeOfDay 15' = 3pm." },
                { "setgametimespeed", "Speeds up how fast the day/night cycle progresses." },
                { "setcurrentday", "Jumps to a specific day number — may unlock achievements and change spawns." },
                { "jumptimeofday", "Jumps ahead by the given number of days." },
                { "locktimeofday", "Freezes the time of day where it is." },
                { "physicsupdatetime", "Adjusts when physics updates. Do not touch unless you know what you are doing — can break loading." },

                // ── player ───────────────────────────────────────────────
                { "godmode", "Makes the player immune to all damage." },
                { "energyhack", "Prevents energy, rest and stamina from draining." },
                { "speedyrun", "Makes the player run extremely fast — pair with godmode to avoid fall damage." },
                { "superjump", "Makes the player jump much higher." },
                { "setstat", "Sets a player stat, e.g. 'setstat health 100', 'setstat hydration 100'." },
                { "setplayerrace", "Changes the player's appearance/race (White, Black, Latin, Asian, …)." },
                { "blockplayerfinaldeath", "Prevents the final-death state." },
                { "camerafov", "Changes the camera FOV based on the number you pass." },
                { "deathcount", "Reports the player's death count." },
                { "forceplayerexpression", "Sets the player's facial expression (angry, scared, …)." },
                { "freecamera", "Detaches the camera from the player." },
                { "heallocalplayer", "Fully heals the local player." },
                { "revivelocalplayer", "Revives the local player." },
                { "killlocalplayer", "Kills the local player." },
                { "knockdownlocalplayer", "Knocks the player to the ground without damage." },
                { "hitlocalplayer", "Deals damage to the local player." },
                { "playeranimparams", "Shows the player's animation parameters." },
                { "playerinterruptkeys", "Toggles player interrupt keys." },
                { "playervisibility", "Toggles the player's visibility." },
                { "playgameover", "Plays the game-over sequence." },

                // ── building ─────────────────────────────────────────────
                { "buildermode", "Adds max amounts of almost every item to the inventory." },
                { "loghack", "Gives infinite logs; log variants can be switched." },
                { "stonehack", "Gives infinite stones, like loghack." },

                // ── environment ──────────────────────────────────────────
                { "breakobjects", "Breaks cannibal tents and other structures within a radius. Also clears trees — keep it under 50." },
                { "clearbushradius", "Clears bushes around the player. Start at 10; huge numbers crash or lag the game." },
                { "cloudfactor", "Adds or removes clouds based on the number." },
                { "cloudshadowsenable", "Turns cloud shadows on/off — useful if they look too dark." },
                { "createlight", "Creates a static light source (does not follow the player)." },
                { "forcerain", "Turns rain on/off — 0 is sunny, 5 is heavy rain." },
                { "forceremovetrees", "Removes N trees around the player. Use increments; do not go over 1000." },
                { "gravity", "Changes gravity — use 'gravity off' to reset." },
                { "gibradius", "Gibs corpses within a radius — like dismemberRadius but more fun." },
                { "removeliving", "Removes all living AI." },
                { "removedead", "Removes all dead AI." },
                { "treescutall", "Cuts all trees within about a 100-metre radius. Causes lag for ~10 seconds." },
                { "slapchop", "Chops down trees with one hit." },
                { "regrowalltrees", "Regrows all trees on the island." },
                { "diggingclear", "Clears dug-up holes." },

                // ── display / misc ───────────────────────────────────────
                { "demomode", "Adds all items, god mode, and disables all HUD except the minimap." },
                { "diagrenderers", "Writes a file in the game directory listing all active objects." },
                { "showui", "Shows or hides all in-game info." },
                { "showfps", "Shows a small FPS counter in the top right." },
                { "showhud", "Shows/hides the HUD — useful for screenshots." },
                { "showinworldui", "Toggles in-world UIs such as log-count labels above storage." },
                { "toggleoverlay", "Toggles the F2 info overlay, including player coordinates." },
                { "toggleplayerstats", "Toggles the F3 player-stats overlay." },
                { "invertlook", "Flips the vertical look input." },
                { "areashadow", "Changes the shadow area — 0 is normal, 1 is massive." },
                { "dismemberradius", "Dismembers random parts of corpses within a radius." },
                { "igniteradius", "Sets AI on fire within a radius." },
                { "openmacrosfolder", "Opens the folder for console-command macros." },

                // ── debugging ────────────────────────────────────────────
                { "aishowdebug", "Shows debug info per AI (camera not locked to the NPC)." },
                { "aishowdebugcamera", "Locks a debug camera to a character — [ ] to cycle, Shift to cycle groups." },
                { "aimemoryadjust", "Adjusts AI memory — 'aimemoryadjust Sentiment 50' (only tested on Kelvin)." },
                { "aijumpdebug", "AI jump debug (requires testing)." },
                { "timeofdaydebug", "Shows a time/day debug menu on the left side of the screen." },
                { "logging", "Creates a command-log section in the F2 overlay; also shows proper command usage." },
                { "logshowerrors", "Shows hidden game error messages." },
                { "logshowinfo", "Continuously spams the log with information." },
                { "logshownone", "Turns log output off." },
                { "logshowwarnings", "Shows hidden game warning messages." },
                { "showstimuli", "Shows AI stimuli debug." },
                { "showprojectiletrails", "Shows projectile trails." },
                { "showcollisionobjectnames", "Shows collision object names." },
                { "showmeshobjectnames", "Shows mesh object names." },
                { "showmeshtrianglecounts", "Shows mesh triangle counts." },
                { "showmeshmaterialnames", "Shows mesh material names." },
                { "showtriggercollision", "Shows trigger collision volumes." },
                { "showobjectlocation", "Shows object locations." },
                { "showworldobjects", "Shows world objects." },
                { "showworldposfor", "Shows world position for the targeted object." },
                { "hideworldposfor", "Hides world position for the targeted object." },
                { "spawnfallingtree", "Spawns a falling tree." },
                { "targetframerate", "Sets the target frame rate." },
                { "navgraphforceupdate", "Forces the navgraph to update." },
                { "postprocessingcomponent", "Post-processing component debug." },
                { "qualitytexture", "Sets texture quality level." },
                { "refreshentities", "Refreshes entities." },
                { "regenhealth", "Regenerates player health over time." },
                { "renderspheres", "Renders debug spheres." },
                { "rumbletest", "Tests controller rumble." },
                { "save", "Saves the game." },
                { "saveplayer", "Saves the player state." },
                { "setdifficultymode", "Sets the difficulty mode (e.g. Normal, Hard, Hard Survival)." },
                { "setgamemode", "Sets the game mode (e.g. Normal, Creative, Peaceful)." },
                { "setlookrotation", "Sets the camera look rotation." },
                { "setproperty", "Sets a property on the current object." },
                { "setsetting", "Sets a settings key to a value." },
                { "setwindintensity", "Sets wind intensity." },
                { "setworldobjectstaterange", "Sets the world-object state range." },
                { "spawnrenderspheres", "Spawns render spheres." },
            };

        /// <summary>
        /// setGameSetupSetting rows — the custom-game options you normally
        /// pick at world creation, applied live. Label, full setting path,
        /// default value.
        /// </summary>
        public static readonly (string Label, string Setting, string Def)[] GameSetupWorld =
        {
            ("Enemy Spawn",        "GameSetting.Vail.EnemySpawn", "on"),
            ("Enemy Health",       "GameSetting.Vail.EnemyHealth", "normal"),
            ("Enemy Damage",       "GameSetting.Vail.EnemyDamage", "normal"),
            ("Enemy Armour",       "GameSetting.Vail.EnemyArmour", "normal"),
            ("Enemy Aggression",   "GameSetting.Vail.EnemyAggression", "normal"),
            ("Enemy Search Parties","GameSetting.Vail.EnemySearchParties", "normal"),
            ("Animal Spawn Rate",  "GameSetting.Vail.AnimalSpawnRate", "normal"),
            ("Starting Season",    "GameSetting.Environment.StartingSeason", "summer"),
            ("Season Length",      "GameSetting.Environment.SeasonLength", "default"),
            ("Day Length",         "GameSetting.Environment.DayLength", "default"),
            ("Precipitation",      "GameSetting.Environment.PrecipitationFrequency", "default"),
        };

        public static readonly (string Label, string Setting, string Def)[] GameSetupSurvival =
        {
            ("Survival Damage",        "GameSetting.Survival.PlayerStatsDamage", "normal"),
            ("Consumable Effects",     "GameSetting.Survival.ConsumableEffects", "normal"),
            ("Cold Penalty Regen Cut", "GameSetting.Survival.ColdPenaltiesStatReduction", "normal"),
            ("Cold Penalties",         "GameSetting.Survival.ColdPenalties", "normal"),
            ("Reduced Food In Crates", "GameSetting.Survival.ReducedFoodInContainers", "false"),
            ("Reduced Ammo In Crates", "GameSetting.Survival.ReducedAmmoInContainers", "false"),
            ("Containers Don't Refill","GameSetting.Survival.SingleUseContainers", "false"),
            ("Pause In Inventory",     "GameSetting.Survival.PausedInInventory", "false"),
            ("Players Trigger Traps",  "GameSetting.Survival.PlayersTriggerTraps", "false"),
            ("Building Resistance",    "GameSetting.Survival.BuildingResistance", "false"),
            ("Creative Mode",          "GameSetting.Survival.CreativeMode", "false"),
            ("Player Immortal Mode",   "GameSetting.Survival.PlayersImmortalMode", "false"),
            ("One-Hit Tree Cutting",   "GameSetting.Survival.OneHitToCutTrees", "false"),
            ("Group Placement",        "GameSetting.FreeForm.ForcePlaceFullLoad", "false"),
            ("No Cuttings Spawn",      "GameSetting.Construction.NoCuttingsSpawn", "false"),
            ("PvP Damage",             "GameSetting.Multiplayer.PvpDamage", "on"),
            ("Multiplayer Cheats",     "GameSetting.Multiplayer.Cheats", "true"),
        };

        /// <summary>
        /// Named goto targets from the wiki's Locations section — bunkers,
        /// caves, crash sites and community-found loot spots. The game's own
        /// named places plus coordinates the community verified.
        /// </summary>
        public static readonly (string Label, string Target)[] Locations =
        {
            // bunkers
            ("Bunker A", "BunkerA"),
            ("Bunker B", "BunkerB"),
            ("Bunker C", "BunkerC"),
            ("Food Bunker", "BunkerFood"),
            ("Entertainment Bunker", "BunkerEntertainment"),
            ("Luxury Bunker", "BunkerLuxury"),
            ("Residential Bunker", "BunkerResidential"),
            // caves
            ("Cave A Entrance", "CaveAEntrance"),
            ("Cave B Entrance", "CaveBEntrance"),
            ("Cave C Epic View", "CaveCEpicView"),
            ("Cave D Big Room", "CaveDBigRoom"),
            ("Cave E", "CaveE"),
            ("Hell Cave", "HellCave"),
            ("Hell Cave Door", "HellCaveDoor"),
            ("Hell Cave End", "HellCaveEnd"),
            ("Lava Stream", "LavaStream"),
            ("Demon Boss Arena", "DemonBoss"),
            // crash sites & landmarks
            ("Ocean Crash", "OceanCrash"),
            ("Snow Crash", "SnowCrash"),
            ("Tree Crash", "TreeCrash"),
            ("Old Boat", "OldBoat"),
            ("Old Chopper", "OldChopper"),
            ("Red Boat", "RedBoat"),
            ("Spaceship", "Spaceship"),
            ("Snow Camp", "SnowCamp"),
            ("Mountain Lake", "MountainLake"),
            ("Virginia Falls", "VirginiaFalls"),
            ("Waterfall", "Waterfall"),
            ("Mass Grave", "MassGrave"),
            ("Gold Mask Shrine", "GoldMaskShrine"),
            ("Hanged Man", "HangedMan"),
            ("Airstrip", "Airstrip"),
            ("Beach East", "BeachEast"),
            ("Peninsula", "Peninsula"),
            ("Shark Beach", "SharkBeach"),
            ("Tactical Camp", "TactiCamp"),
            ("Coffin Falls", "CoffinFalls"),
            ("Pilot (NPC)", "Pilot"),
            ("Get Down Son", "GetDownSon"),
            ("Security Room", "SecurityRoom"),
            ("Vine Chopper", "VineChopper"),
            ("Virginia (NPC)", "Virginia"),
            // community-found loot
            ("Katana (bunker)", "1161 211 -653"),
            ("Crossbow", "-1023 64 987"),
            ("Shotgun (dig spot)", "-1340 97 1413"),
            ("Ropegun (Cave B)", "-1203 129 -276"),
            ("Shovel (Cave C)", "-428 136 -101"),
            ("Rebreather (Cave A)", "-433 12 1457"),
            ("Glider", "-502 325 -309"),
            ("Handgun on Boat", "-1796.8 15.5 578"),
            ("Helipad", "1935 16 454"),
            ("Morgue", "1143 193 -613"),
            ("Timmy & Eric Cutscene", "1217 218 -624"),
            ("Endgame Door", "1600 23 485"),
            ("End Entrance", "706 -200 306"),
        };
    }
}

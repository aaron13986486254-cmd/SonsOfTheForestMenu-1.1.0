// ═══════════════════════════════════════════════════════════════════════════
//  Signature.cs · authorship, build identity, and the strings that carry it
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Single source of truth for who built this and which build is running.
///
/// Every other file reads its identity strings from here rather than repeating
/// literals: the BepInEx plugin attribute, the boot log line, the in-game
/// watermark and the panel header all resolve to these constants, so a version
/// bump is one edit and can never leave two surfaces disagreeing.
/// </summary>
[Cyberfox1337x]
internal static class Signature
{
    /// <summary>Author handle. Surfaced in the boot log and the panel header.</summary>
    internal const string Author = "cyberfox1337x";

    /// <summary>
    /// BepInEx plugin GUID. Deliberately unchanged across rewrites — it names
    /// the config file, which holds the user's Steam Web API key and window
    /// position. Renaming it silently orphans both.
    /// </summary>
    internal const string Guid = "com.stormfest.sonsoftheforestmenu";

    /// <summary>Display name, shown by BepInEx in the chainloader log.</summary>
    internal const string Name = "Sons of the Forest Menu";

    /// <summary>Plugin version. Must stay a valid System.Version string.</summary>
    internal const string Version = "1.1.0";

    /// <summary>
    /// Game build this release was verified against. Shown in the panel header
    /// so a user reporting a bug states the pairing without being asked.
    /// </summary>
    internal const string VerifiedGameBuild = "0.11.3";

    /// <summary>Header sub-line, e.g. "SOTF UTIL · v1.1.0 · GAME 0.11.3".</summary>
    internal static string HeaderLine =>
        $"SOTF UTIL  ·  v{Version}  ·  GAME {VerifiedGameBuild}";

    /// <summary>Single line written to the BepInEx log once, at load.</summary>
    internal static string BootLine(string toggleKey) =>
        $"{Name} v{Version} by {Author} — press {toggleKey} to open.";
}

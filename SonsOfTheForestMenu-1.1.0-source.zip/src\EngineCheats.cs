// ═══════════════════════════════════════════════════════════════════════════
//  EngineCheats.cs · the game's own Sons.Settings.Cheats surface
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System.Collections.Generic;
using Sons.Settings;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// The game's own cheat flags, achievements, armour state and world simulation.
///
/// <para><c>Sons.Settings.Cheats</c> turned out to be the real cheat surface
/// the game ships with, and it is a better target than driving the console for
/// the same effects: the values can be <i>read back</i>, so the CHEATS tab can
/// show true state instead of a toggle that only remembers what we last sent.
/// That matters when the game changes a flag on its own — loading a save,
/// starting a creative world — and a write-only mirror would quietly lie.</para>
///
/// <para>The flags are instance members reached through <c>Cheats.Setup</c>;
/// <c>Reset</c> is static. That asymmetry is the game's, not ours.</para>
/// </summary>
[Cyberfox1337x]
internal static class EngineCheats
{
    static void Ok(string what) => Features.LastResult = what;

    /// <summary>The game's cheat settings object, or null outside a world.</summary>
    static Cheats Setup => Safe.Get("cheats.setup", () => Cheats.Setup);

    // ── cheat flags ─────────────────────────────────────────────────────
    //
    // Each is a read-through property: the getter reports what the game
    // currently believes, the setter writes and confirms. Reads are Transient
    // because the CHEATS tab polls them every draw while no world is loaded.

    /// <summary>Reads one bool off the cheats object, false when unavailable.</summary>
    static bool Read(string site, System.Func<Cheats, bool> get)
    {
        Cheats cheats = Setup;
        return cheats != null && Safe.Get(site, cheats, get, false);
    }

    /// <summary>Writes one bool and reports it on the status line.</summary>
    static void Write(string site, string label, System.Action<Cheats> set)
    {
        Cheats cheats = Setup;
        if (cheats == null)
        {
            Features.LastResult = "Needs a loaded world";
            return;
        }

        if (Safe.Run(site, cheats, set, Noise.Warn)) Ok(label);
    }

    internal static bool CheatGod
    {
        get => Read("cheats.god.read", c => c.GodMode);
        set => Write("cheats.god.write", $"Cheats.GodMode {value}", c => c.GodMode = value);
    }

    internal static bool CheatEnergy
    {
        get => Read("cheats.energy.read", c => c.InfiniteEnergy);
        set => Write("cheats.energy.write", $"Infinite Energy {value}",
                     c => c.InfiniteEnergy = value);
    }

    internal static bool CheatNoSurvival
    {
        get => Read("cheats.nosurvival.read", c => c.NoSurvival);
        set => Write("cheats.nosurvival.write", $"No Survival {value}",
                     c => c.NoSurvival = value);
    }

    internal static bool CheatOneHitTrees
    {
        get => Read("cheats.onehittrees.read", c => c.OneHitTreeCutting);
        set => Write("cheats.onehittrees.write", $"One-Hit Trees {value}",
                     c => c.OneHitTreeCutting = value);
    }

    /// <summary>Returns every cheat flag to its default. Static on the game's side.</summary>
    internal static void ResetCheats()
    {
        if (Safe.Run("cheats.reset", Cheats.Reset, Noise.Warn)) Ok("Cheats reset");
    }

    // ── achievements ────────────────────────────────────────────────────

    /// <summary>Display list, "[x] ApiName", rebuilt by <see cref="RefreshAchievements"/>.</summary>
    internal static readonly List<string> AchievementNames = new();

    internal static int AchievementTotal { get; private set; }
    internal static int AchievementUnlocked { get; private set; }

    /// <summary>
    /// The achievement manager, or null outside a world. Looked up per call
    /// rather than cached: it is scene-scoped, and the three achievement
    /// operations are all user-initiated, so the scan cost is irrelevant.
    /// </summary>
    static Sons.Gameplay.Achievements.AchievementManager AchievementManager =>
        Safe.Get("achievements.manager",
            () => Object.FindObjectOfType<Sons.Gameplay.Achievements.AchievementManager>(),
            noise: Noise.Warn);

    /// <summary>
    /// Walks the achievement list once, applying <paramref name="visit"/> to
    /// each entry.
    ///
    /// <para>Shared by refresh, unlock-all and reset-all so the null checks and
    /// the per-entry guard exist once. The guard is per-entry on purpose: one
    /// torn-down achievement must not abort the walk.</para>
    /// </summary>
    /// <returns>Number of entries successfully visited, or -1 if unavailable.</returns>
    static int ForEachAchievement(string site,
        System.Action<Sons.Gameplay.Achievements.Achievement> visit)
    {
        var manager = AchievementManager;
        if (manager == null) return -1;

        var list = Safe.Get("achievements.list", manager, m => m._achievements,
                            noise: Noise.Warn);
        if (list == null) return -1;

        int visited = 0;
        int count = Safe.Get("achievements.count", list, l => l.Count, 0);

        for (int index = 0; index < count; index++)
        {
            bool ok = Safe.Run(site, (list, index, visit), state =>
            {
                var achievement = state.list[state.index];
                if (achievement == null) return;

                state.visit(achievement);
            });

            if (ok) visited++;
        }

        return visited;
    }

    /// <summary>Rebuilds the display list and the unlocked/total counters.</summary>
    internal static void RefreshAchievements()
    {
        AchievementNames.Clear();
        AchievementTotal = 0;
        AchievementUnlocked = 0;

        int visited = ForEachAchievement("achievements.read", achievement =>
        {
            bool unlocked = achievement.IsUnlocked();

            AchievementNames.Add($"{(unlocked ? "[x]" : "[ ]")} {achievement.ApiName}");
            AchievementTotal++;

            if (unlocked) AchievementUnlocked++;
        });

        Ok(visited < 0
            ? "No achievement manager"
            : $"{AchievementUnlocked} / {AchievementTotal} unlocked");
    }

    /// <summary>Unlocks every achievement not already unlocked.</summary>
    internal static void UnlockAllAchievements()
    {
        int unlocked = 0;

        int visited = ForEachAchievement("achievements.unlock", achievement =>
        {
            if (achievement.IsUnlocked()) return;

            achievement.Unlock();
            unlocked++;
        });

        if (visited < 0)
        {
            Ok("No achievement manager");
            return;
        }

        Ok($"Unlocked {unlocked} achievement(s)");
        RefreshAchievements();
    }

    /// <summary>Clears every achievement back to locked.</summary>
    internal static void ResetAllAchievements()
    {
        int reset = 0;

        int visited = ForEachAchievement("achievements.reset", achievement =>
        {
            achievement.Reset();
            reset++;
        });

        if (visited < 0)
        {
            Ok("No achievement manager");
            return;
        }

        Ok($"Reset {reset} achievement(s)");
        RefreshAchievements();
    }

    // ── armour ──────────────────────────────────────────────────────────

    /// <summary>Human-readable armour state, refreshed on demand.</summary>
    internal static string ArmourStatus { get; private set; } = "unknown";

    internal static void RefreshArmour()
    {
        PlayerStats stats = Game.Stats;

        var armour = stats == null
            ? null
            : Safe.Get("armour.system", stats, s => s.ArmourSystem);

        if (armour == null)
        {
            ArmourStatus = "no armour system";
            return;
        }

        ArmourStatus = Safe.Get("armour.status", armour, system =>
        {
            if (!system.IsWearingAnyArmour()) return "no armour equipped";

            return system.IsWearingGoldenArmour()
                ? "wearing golden armour"
                : "wearing armour";
        }, fallback: "unknown", noise: Noise.Warn);
    }

    // ── water ───────────────────────────────────────────────────────────

    /// <summary>Freezes or thaws the loaded water body.</summary>
    internal static void ToggleFreezeWater()
    {
        var water = Safe.Get("water.freeze-component",
            () => Object.FindObjectOfType<Sons.Atmosphere.FreezeWater>(), noise: Noise.Warn);

        if (water == null)
        {
            Ok("No water body loaded");
            return;
        }

        if (Safe.Run("water.toggle-freeze", water, w => w.ToggleFreeze(), Noise.Warn))
            Ok("Water freeze toggled");
    }

    // ── world simulation ────────────────────────────────────────────────

    /// <summary>
    /// Live Vail actor count, or -1 when the simulation is not running. The
    /// CHEATS tab reads this every draw, hence the quiet default noise level.
    /// </summary>
    internal static int SimActorCount()
    {
        var simulation = Safe.Get("sim.instance",
            () => Sons.Ai.Vail.VailWorldSimulation._instance);

        return simulation == null
            ? -1
            : Safe.Get("sim.actor-count", simulation, s => s.ActorCount, -1);
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  Esp.cs · screen-space actor overlay
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using UnityEngine;
using Sons.Ai.Vail;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// Screen-space overlay drawn in OnGUI. Reads the Vail actor list, projects
    /// each world position through the player camera, and draws a box + health
    /// bar + label. Design matches a tactical ESP: thick coloured outline,
    /// subtle dark fill, a prominent health bar at the top edge, distance and
    /// type label above in white with a dark drop-shadow, and raw HP numbers.
    /// </summary>
    [Cyberfox1337x("actor ESP")]
    internal static class Esp
    {
        public static bool Enabled;
        public static bool Enemies = true;
        public static bool Animals;
        public static bool Friendly;
        public static bool ShowDead;
        public static float MaxDistance = 300f;

        enum EspCategory { Enemy, Animal, Friendly }

        public static int ActiveCount()
        {
            if (!Enabled) return 0;
            int n = 1;
            if (Enemies) n++;
            if (Animals) n++;
            if (Friendly) n++;
            return n;
        }

        public static int LastDrawn { get; private set; }

        static EspCategory Classify(VailActor a)
        {
            try
            {
                switch (a.ClassId)
                {
                    case VailActorClassId.Animal: return EspCategory.Animal;
                    case VailActorClassId.Cannibal:
                    case VailActorClassId.Creepy: return EspCategory.Enemy;
                }
            }
            catch { }
            try
            {
                switch (a.TypeId)
                {
                    case VailActorTypeId.Robby:
                    case VailActorTypeId.Virginia:
                    case VailActorTypeId.Timmy:
                    case VailActorTypeId.Helicopter:
                    case VailActorTypeId.PlayerRobby:
                        return EspCategory.Friendly;
                    default:
                        return EspCategory.Enemy;
                }
            }
            catch { return EspCategory.Enemy; }
        }

        static bool Want(EspCategory c)
        {
            switch (c)
            {
                case EspCategory.Animal: return Animals;
                case EspCategory.Friendly: return Friendly;
                default: return Enemies;
            }
        }

        static string CategoryLabel(EspCategory c)
        {
            switch (c)
            {
                case EspCategory.Animal: return "ANIMAL";
                case EspCategory.Friendly: return "FRIENDLY";
                default: return "ENEMY";
            }
        }

        static readonly GUIContent _gc = new GUIContent();

        // built once — dark drop-shadow for the distance / type labels
        static GUIStyle _espLabel, _espShadow, _hpLabel, _hpShadow, _catLabel, _catShadow;
        static Texture2D _skullIcon, _pawIcon, _figureIcon;

        public static void Draw()
        {
            LastDrawn = 0;
            if (!Enabled || !Game.InWorld) return;

            if (Event.current != null && Event.current.type != EventType.Repaint) return;

            var cam = Game.Cam;
            if (cam == null) return;

            var self = Game.PlayerTransform;
            Vector3 origin = self != null ? self.position : cam.transform.position;

            VailActorManager mgr;
            try { mgr = VailActorManager._instance; } catch { return; }
            if (mgr == null) return;

            Il2CppSystem.Collections.Generic.List<VailActor> actors;
            try { actors = mgr._activeActors; } catch { return; }
            if (actors == null) return;

            int count;
            try { count = actors.Count; } catch { return; }

            for (int i = 0; i < count; i++)
            {
                VailActor a;
                try { a = actors[i]; } catch { continue; }
                if (a == null) continue;

                try
                {
                    if (a._isDead && !ShowDead) continue;
                    EspCategory category = Classify(a);
                    if (!Want(category)) continue;
                    var tr = a.transform;
                    if (tr == null) continue;

                    var pos = tr.position;
                    float dist = Vector3.Distance(origin, pos);
                    if (dist > MaxDistance) continue;

                    var top = cam.WorldToScreenPoint(pos + Vector3.up * 2.0f);
                    var bottom = cam.WorldToScreenPoint(pos);
                    if (top.z <= 0f || bottom.z <= 0f) continue;

                    float h = Mathf.Abs(top.y - bottom.y);
                    if (h < 4f) continue;
                    float w = h * 0.55f;

                    float sx = bottom.x - w * 0.5f;
                    float sy = Screen.height - top.y;

                    var box = new Rect(sx, sy, w, h);
                    var col = a._isDead ? Theme.Dead : ColorFor(category);

                    // subtle dark fill so the box reads as a solid element
                    Theme.Fill(box, new Color(0f, 0f, 0f, 0.18f));

                    // thicker outline
                    Theme.Box(box, col, 2f);

                    // ── health bar ────────────────────────────────────────
                    float hpFrac = -1f;
                    float hpCur = 0f, hpMax = 0f;
                    if (!a._isDead)
                    {
                        hpFrac = HealthOf(a, out hpCur, out hpMax);
                    }

                    float barShift = 0f;
                    if (hpFrac >= 0f)
                    {
                        const float barH = 6f;
                        const float barYpad = 2f;
                        // dark track above the box
                        var barBg = new Rect(box.x, box.y - barH - barYpad,
                                             box.width, barH);
                        Theme.Fill(barBg, new Color(0f, 0f, 0f, 0.65f));
                        // filled portion — green-yellow gradient
                        if (hpFrac > 0f)
                        {
                            var fill = new Rect(barBg.x + 1f, barBg.y + 1f,
                                                (barBg.width - 2f) * hpFrac, barH - 2f);
                            Theme.Fill(fill, HpColor(hpFrac));
                        }
                        // outline the bar in the actor colour
                        Theme.Box(barBg, col, 1f);
                        barShift = barH + barYpad;
                    }

                    // ── labels ────────────────────────────────────────────
                    // Build styles once — white text, dark drop-shadow
                    if (_espLabel == null)
                    {
                        _espLabel = new GUIStyle(Theme.EspLabel);
                        _espLabel.alignment = TextAnchor.MiddleCenter;
                        _espShadow = new GUIStyle(_espLabel);
                        _espShadow.normal.textColor = new Color(0f, 0f, 0f, 0.85f);
                        _hpLabel = new GUIStyle(_espLabel);
                        _hpLabel.fontSize = 11;
                        _hpLabel.alignment = TextAnchor.MiddleRight;
                        _hpShadow = new GUIStyle(_hpLabel);
                        _hpShadow.normal.textColor = new Color(0f, 0f, 0f, 0.85f);
                        _catLabel = new GUIStyle(Theme.EspLabel);
                        _catLabel.fontSize = 9;
                        _catLabel.alignment = TextAnchor.MiddleCenter;
                        _catShadow = new GUIStyle(_catLabel);
                        _catShadow.normal.textColor = new Color(0f, 0f, 0f, 0.85f);
                        _skullIcon   = MakeSkullIcon();
                        _pawIcon     = MakePawIcon();
                        _figureIcon  = MakeFigureIcon();
                    }

                    float labelY = box.y - barShift;

                    // Category label (ENEMY / ANIMAL / FRIENDLY) — small, coloured, with icon
                    string catText = CategoryLabel(category);
                    _gc.text = catText;
                    var catSize = _catLabel.CalcSize(_gc);
                    catSize.x += 6f; catSize.y += 2f;
                    float catH = catSize.y;
                    const float iconW = 12f;
                    float catFullW = iconW + 3f + catSize.x; // icon + gap + text
                    var catRect = new Rect(box.x + box.width * 0.5f - catFullW * 0.5f,
                                           labelY - catH + 2f,
                                           catFullW, catSize.y);
                    // Icon tinted in category colour
                    Texture2D icon = category == EspCategory.Animal ? _pawIcon
                                   : category == EspCategory.Friendly ? _figureIcon
                                   : _skullIcon;
                    var iconRect = new Rect(catRect.x, catRect.y + 1f, iconW, iconW);
                    GUI.DrawTexture(new Rect(iconRect.x + 1, iconRect.y + 1, iconW, iconW),
                                    icon, ScaleMode.StretchToFill, true, 0f,
                                    new Color(0f, 0f, 0f, 0.85f), 0f, 0f);
                    var prevCol = GUI.color;
                    GUI.color = col;
                    GUI.DrawTexture(iconRect, icon);
                    GUI.color = prevCol;
                    // Text to the right of the icon
                    var textRect = new Rect(catRect.x + iconW + 3f, catRect.y,
                                            catSize.x, catSize.y);
                    GUI.Label(new Rect(textRect.x + 1, textRect.y + 1,
                                       textRect.width, textRect.height),
                              _gc, _catShadow);
                    var prevCatColor = _catLabel.normal.textColor;
                    _catLabel.normal.textColor = col;
                    GUI.Label(textRect, _gc, _catLabel);
                    _catLabel.normal.textColor = prevCatColor;

                    // Distance above the box, centred
                    string labelText = dist.ToString("0") + "m";
                    _gc.text = labelText;
                    var labelSize = _espLabel.CalcSize(_gc);
                    labelSize.x += 8f; labelSize.y += 4f;
                    var labelRect = new Rect(box.x + box.width * 0.5f - labelSize.x * 0.5f,
                                             labelY - labelSize.y - catH + 4f,
                                             labelSize.x, labelSize.y);
                    GUI.Label(new Rect(labelRect.x + 1, labelRect.y + 1,
                                       labelRect.width, labelRect.height),
                              _gc, _espShadow);
                    var prevColor = _espLabel.normal.textColor;
                    _espLabel.normal.textColor = Color.white;
                    GUI.Label(labelRect, _gc, _espLabel);
                    _espLabel.normal.textColor = prevColor;

                    // HP numbers on the right side of the bar
                    if (hpFrac >= 0f && hpMax > 0f)
                    {
                        _gc.text = hpCur.ToString("0") + "/" + hpMax.ToString("0");
                        var hpSize = _hpLabel.CalcSize(_gc);
                        hpSize.x += 6f; hpSize.y += 2f;
                        var hpRect = new Rect(box.xMax - hpSize.x,
                                              box.y - hpSize.y - barShift + 1f,
                                              hpSize.x, hpSize.y);
                        GUI.Label(new Rect(hpRect.x + 1, hpRect.y + 1,
                                           hpRect.width, hpRect.height),
                                  _gc, _hpShadow);
                        GUI.Label(hpRect, _gc, _hpLabel);
                    }

                    LastDrawn++;
                }
                catch { }
            }
        }

        static Color ColorFor(EspCategory c)
        {
            switch (c)
            {
                case EspCategory.Animal: return Theme.Live;
                case EspCategory.Friendly: return Theme.Bone;
                default: return Theme.RustBright;
            }
        }

        /// <summary>
        /// Aggregates damage nodes into a 0..1 health fraction and also
        /// returns the raw current/max HP values for display.
        /// </summary>
        static float HealthOf(VailActor a, out float cur, out float max)
        {
            cur = 0f; max = 0f;
            try
            {
                var dc = a._damageController;
                if (dc == null) return -1f;
                var nodes = dc._damageNodes;
                if (nodes == null) return -1f;
                int n = nodes.Count;
                if (n == 0) return -1f;

                float totalMax = 0f, totalDmg = 0f;
                for (int i = 0; i < n; i++)
                {
                    var node = nodes[i];
                    if (node == null || !node._useBreak) continue;
                    float m = node._breakAmount;
                    if (m <= 0f) continue;
                    totalMax += m;
                    totalDmg += Mathf.Clamp(node._currentAppliedNodeDamage, 0f, m);
                }
                if (totalMax <= 0f) return -1f;
                max = totalMax;
                cur = totalMax - totalDmg;
                return Mathf.Clamp01(1f - totalDmg / totalMax);
            }
            catch { return -1f; }
        }

        /// <summary>Health bar colour — red → amber → green as health rises.</summary>
        static Color HpColor(float hp)
        {
            var amber = new Color(0.88f, 0.75f, 0.18f);
            if (hp < 0.5f) return Color.Lerp(Theme.RustBright, amber, hp * 2f);
            return Color.Lerp(amber, Theme.Live, (hp - 0.5f) * 2f);
        }

        // ── Procedural ESP icons (14×14, white-on-clear, tinted at draw) ──

        const int IconN = 14;

        /// <summary>
        /// Skull with crossed bones behind — classic pirate-skull silhouette.
        /// Cranium dome, cheekbones, nasal cavity, teeth, and two long bones
        /// crossing diagonally behind the skull for instant recognition.
        /// </summary>
        static Texture2D MakeSkullIcon()
        {
            const int N = IconN;
            var t = new Texture2D(N, N, TextureFormat.RGBA32, false);
            for (int y = 0; y < N; y++)
            {
                for (int x = 0; x < N; x++)
                {
                    float fx = x + 0.5f, fy = y + 0.5f;
                    float a = 0f;

                    // Crossed bones: two thick lines behind the skull
                    // Bone 1: diagonal top-left → bottom-right, 1.5px thick
                    float dist1 = Mathf.Abs(fy - fx) / 1.414f;
                    bool bone1 = (fx + fy > 4f && fx + fy < 24f) && dist1 < 1.6f;
                    // Bone 2: diagonal top-right → bottom-left
                    float dist2 = Mathf.Abs(fy - (N - fx)) / 1.414f;
                    bool bone2 = (fx - fy > -10f && fx - fy < 10f) && dist2 < 1.6f;
                    // Bone end knobs: circles at the tips
                    bool tip(float tx, float ty) { float d = Mathf.Sqrt((fx - tx) * (fx - tx) + (fy - ty) * (fy - ty)); return d < 2.0f; }
                    bool knobs = tip(2.5f, 2.5f) || tip(11.5f, 11.5f) || tip(11.5f, 2.5f) || tip(2.5f, 11.5f);
                    bool bones = bone1 || bone2 || knobs;

                    // Cranium dome: top half of skull, ellipse cx=7 cy=4.5 rx=5 ry=4.2
                    float cx = (fx - 7f) / 5f;
                    float cy = (fy - 4.5f) / 4.2f;
                    bool cranium = (cx * cx + cy * cy) < 1f && fy < 9f;

                    // Cheekbones: widen at rows 7-9
                    bool cheek = (fy >= 6.5f && fy <= 9.5f && fx >= 1.5f && fx <= 12.5f);

                    // Jaw: tapered rect from y=8.5 down to y=12
                    if (fy >= 8.5f && fy <= 12.5f)
                    {
                        float jawLerp = (fy - 8.5f) / 4f;
                        float jawL = 3f + jawLerp * 1.2f;
                        float jawR = 11f - jawLerp * 1.2f;
                        if (fx >= jawL && fx <= jawR) cheek = true;
                    }

                    if (cranium || cheek)
                    {
                        // Eye sockets: two larger holes at y=3-5
                        bool leftEye  = (x >= 3 && x <= 5 && y >= 3 && y <= 5);
                        bool rightEye = (x >= 8 && x <= 10 && y >= 3 && y <= 5);
                        // Nasal cavity: triangle at y=6-7
                        bool nose = (y == 6 && (x == 6 || x == 7)) || (y == 7 && x == 6);
                        // Teeth: gaps on bottom 3 rows
                        bool tooth = (y >= 9 && y <= 11 && x % 2 == 1);
                        if (!leftEye && !rightEye && !nose && !tooth)
                            a = 1f;
                    }

                    if (bones) a = Mathf.Max(a, 0.45f); // bones slightly dimmer behind skull
                    if (knobs && a > 0.45f) a = 0.55f; // bone tips slightly brighter

                    t.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            t.filterMode = FilterMode.Bilinear; t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.HideAndDontSave; t.Apply();
            return t;
        }

        /// <summary>
        /// Animal paw: central pad with three toes, claw marks above each toe,
        /// and two small rear dewclaw pads. Reads instantly as an animal track.
        /// </summary>
        static Texture2D MakePawIcon()
        {
            const int N = IconN;
            var t = new Texture2D(N, N, TextureFormat.RGBA32, false);
            for (int y = 0; y < N; y++)
            {
                for (int x = 0; x < N; x++)
                {
                    float fx = x + 0.5f, fy = y + 0.5f;
                    float a = 0f;

                    // Central main pad: large rounded triangle at bottom, cy=9.5
                    // Use a wide ellipse
                    float pdx = (fx - 7f) / 3.8f;
                    float pdy = (fy - 9.5f) / 3.2f;
                    bool mainPad = (pdx * pdx + pdy * pdy) < 1f;

                    // Three toe beans — each is a small ellipse with a tiny claw mark above
                    bool Toe(float tx, float ty, float r)
                    {
                        float dx = (fx - tx) / r;
                        float dy = (fy - ty) / r;
                        return (dx * dx + dy * dy) < 1f;
                    }
                    // Toe positions: left(4,5.5) middle(7,3.5) right(10,5.5)
                    bool toes = Toe(4f, 5.8f, 2.2f) || Toe(7f, 4f, 2.2f) || Toe(10f, 5.8f, 2.2f);

                    // Claw marks: tiny upward streaks above each toe
                    bool Claw(float cx, float topY)
                    {
                        return (fx >= cx - 0.5f && fx <= cx + 0.5f && fy >= topY && fy <= topY + 2.5f);
                    }
                    bool claws = Claw(4f, 1.5f) || Claw(7f, 0.5f) || Claw(10f, 1.5f);

                    // Dewclaw pads: two tiny dots at bottom corners
                    float d1 = Mathf.Sqrt((fx - 2f) * (fx - 2f) + (fy - 11.5f) * (fy - 11.5f));
                    float d2 = Mathf.Sqrt((fx - 12f) * (fx - 12f) + (fy - 11.5f) * (fy - 11.5f));
                    bool dewclaws = d1 < 1.5f || d2 < 1.5f;

                    if (mainPad || toes || claws || dewclaws)
                        a = 1f;

                    t.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            t.filterMode = FilterMode.Bilinear; t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.HideAndDontSave; t.Apply();
            return t;
        }

        /// <summary>
        /// Human figure: round head, shoulders with arms angled down, tapered
        /// torso, and two legs with feet — a clean stick-figure silhouette.
        /// </summary>
        static Texture2D MakeFigureIcon()
        {
            const int N = IconN;
            var t = new Texture2D(N, N, TextureFormat.RGBA32, false);
            for (int y = 0; y < N; y++)
            {
                for (int x = 0; x < N; x++)
                {
                    float fx = x + 0.5f, fy = y + 0.5f;
                    float a = 0f;

                    // Head: circle at top-center, r=2.8
                    float hd = Mathf.Sqrt((fx - 7f) * (fx - 7f) + (fy - 2f) * (fy - 2f));
                    bool head = hd < 2.8f;

                    // Neck: thin vertical line
                    bool neck = (fx >= 6f && fx <= 8f && fy >= 4.5f && fy <= 5.5f);

                    // Shoulders + arms: horizontal bar at y~5.5-6.5, then arms angling down
                    bool shoulders = (fy >= 5.5f && fy <= 6.5f && fx >= 2f && fx <= 12f);
                    // Arms: diagonal from shoulders down to waist
                    if (fy >= 6.5f && fy <= 10f)
                    {
                        float armLerp = (fy - 6.5f) / 3.5f;
                        float armOut = 3f + armLerp * 2.5f; // arms widen as they go down
                        float armIn  = 1.5f + armLerp * 2f;
                        bool leftArm  = (fx >= 7f - armOut && fx <= 7f - armIn);
                        bool rightArm = (fx >= 7f + armIn  && fx <= 7f + armOut);
                        if (leftArm || rightArm) a = 1f;
                    }

                    // Torso: vertical column
                    if (fy >= 6f && fy <= 10.5f)
                    {
                        if (fx >= 5.5f && fx <= 8.5f)
                            a = 1f;
                    }

                    // Legs: two columns from waist down, feet at bottom
                    if (fy > 10.5f && fy <= 13.5f)
                    {
                        bool leftLeg  = (fx >= 4.5f && fx <= 6f);
                        bool rightLeg = (fx >= 8f   && fx <= 9.5f);
                        if (leftLeg || rightLeg) a = 1f;
                    }
                    // Feet: small horizontal bars
                    if (fy > 12.5f && fy <= 13.5f)
                    {
                        if ((fx >= 3.5f && fx <= 7f) || (fx >= 7f && fx <= 10.5f))
                            a = 1f;
                    }

                    if (head || neck || shoulders) a = 1f;

                    t.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            t.filterMode = FilterMode.Bilinear; t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.HideAndDontSave; t.Apply();
            return t;
        }
    }
}
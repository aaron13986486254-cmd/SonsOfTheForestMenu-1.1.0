// ═══════════════════════════════════════════════════════════════════════════
//  Actions.cs · curated console-command tables
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>A console command surfaced as a switch (fires "cmd on" / "cmd off").</summary>
    [Cyberfox1337x("command switch")]
    internal struct ToggleCommand
    {
        public string Label, Command;
        public bool Danger;
        public ToggleCommand(string label, string command, bool danger = false)
        { Label = label; Command = command; Danger = danger; }
    }

    /// <summary>A console command surfaced as a one-shot button.</summary>
    [Cyberfox1337x("command action")]
    internal struct ActionCommand
    {
        public string Label, Command;

        /// <summary>
        /// True for destructive or self-harming actions (kill, hit, knockdown).
        ///
        /// <para><b>Currently not rendered.</b> ActionRows once painted these
        /// rust, but a grid with half its rows permanently red read as an error
        /// state rather than a list of available actions, so every action button
        /// is now uniform grey with a green hover. The flag is kept because it
        /// still describes the command truthfully and is the hook any future
        /// treatment would use — a confirm step, a subtle edge marker, or an
        /// ordering rule that keeps destructive rows out of the top row.</para>
        /// </summary>
        public bool Danger;

        public ActionCommand(string label, string command, bool danger = false)
        { Label = label; Command = command; Danger = danger; }
    }

    /// <summary>A console command that takes one argument.</summary>
    [Cyberfox1337x("command with argument")]
    internal struct ValueCommand
    {
        public string Label, Command, DefaultValue;
        public ValueCommand(string label, string command, string defaultValue)
        { Label = label; Command = command; DefaultValue = defaultValue; }
    }

    /// <summary>
    /// Curated groupings over the game's own debug console. Generated from the
    /// command table extracted out of global-metadata.dat, so every entry here
    /// is a command the shipped game actually implements.
    /// </summary>
    [Cyberfox1337x("curated command tables")]
    internal static class Actions
    {
        public static readonly ToggleCommand[] PlayerSwitches =
        {
            new ToggleCommand("Invisible", "invisible"),
            new ToggleCommand("Regenhealth", "regenhealth"),
            new ToggleCommand("Fake Drown", "fakeDrown", true),
            new ToggleCommand("Capsule Mode", "capsulemode"),
            new ToggleCommand("Block Player Final Death", "blockPlayerFinalDeath"),
            new ToggleCommand("Player Visibility", "playerVisibility"),
            new ToggleCommand("Crouch Toggle", "crouchToggle"),
            new ToggleCommand("Invert Look", "invertLook"),
            new ToggleCommand("First Look Force", "firstLookForce"),
            new ToggleCommand("Player Interrupt Keys", "playerInterruptKeys"),
        };

        public static readonly ActionCommand[] PlayerActions =
        {
            new ActionCommand("Heal Local Player", "heallocalplayer"),
            new ActionCommand("Revive Local Player", "revivelocalplayer"),
            new ActionCommand("Kill Local Player", "killlocalplayer", true),
            new ActionCommand("Knockdown Local Player", "knockdownLocalPlayer", true),
            new ActionCommand("Hit Local Player", "hitlocalplayer", true),
            new ActionCommand("Instant Respawn Here", "instantRespawnHere"),
            new ActionCommand("Reset Held Anim", "resetHeldAnim"),
            new ActionCommand("Clear Mid-Action Flag", "clearmidactionflag"),
        };

        public static readonly ValueCommand[] PlayerValues =
        {
            new ValueCommand("Set Inventory %", "setinventorypercent", "100"),
            new ValueCommand("Set Player Race", "setPlayerRace", "0"),
            new ValueCommand("Death Count", "deathCount", "0"),
        };

        public static readonly ToggleCommand[] CombatSwitches =
        {
            new ToggleCommand("AI Disable", "aiDisable"),
            new ToggleCommand("AI God Mode", "aiGodMode", true),
            new ToggleCommand("AI Knockdown Disable", "aiKnockdownDisable"),
            new ToggleCommand("AI Force Strafe", "aiForceStrafe"),
            new ToggleCommand("AI Radar", "aiRadar"),
            new ToggleCommand("AI Show Health", "aiShowHealth"),
            new ToggleCommand("AI Show Paths", "aiShowPaths"),
            new ToggleCommand("AI Show Debug", "aiShowDebug"),
            new ToggleCommand("AI Show Stats", "aiShowStats"),
            new ToggleCommand("AI Show Thoughts", "aiShowThoughts"),
            new ToggleCommand("AI Vision Debug", "aiVisionDebug"),
            new ToggleCommand("AI Show Anims", "aiShowAnims"),
            new ToggleCommand("Creepy Attack Party", "creepyAttackParty", true),
            new ToggleCommand("Animals Enabled", "animalsEnabled"),
        };

        public static readonly ActionCommand[] CombatActions =
        {
            new ActionCommand("Remove Dead", "removeDead"),
            new ActionCommand("Remove Living", "removeLiving", true),
            new ActionCommand("Destroy Ragdoll", "destroyRagdoll"),
            new ActionCommand("Creepy Village", "creepyVillage"),
            new ActionCommand("AI Run World Event", "aiRunWorldEvent"),
            new ActionCommand("AI Pool Stats", "aiPoolStats"),
        };

        public static readonly ValueCommand[] RadiusValues =
        {
            new ValueCommand("Kill Radius", "killRadius", "30"),
            new ValueCommand("Damage Radius", "damageRadius", "30"),
            new ValueCommand("Ignite Radius", "igniteRadius", "20"),
            new ValueCommand("Shock Radius", "shockRadius", "20"),
            new ValueCommand("Dismember Radius", "dismemberRadius", "20"),
            new ValueCommand("Gib Radius", "gibRadius", "20"),
            new ValueCommand("Burn Body Radius", "burnBodyRadius", "20"),
            new ValueCommand("Clear Bush Radius", "clearBushRadius", "30"),
        };

        public static readonly ValueCommand[] AiValues =
        {
            new ValueCommand("AI Anger Level", "aiAngerLevel", "1"),
            new ValueCommand("AI Armor Level", "aiArmorLevel", "0"),
            new ValueCommand("AI Armor Tier", "aiArmorTier", "0"),
            new ValueCommand("AI Anim Speed", "aiAnimSpeed", "1"),
            new ValueCommand("Animal Limit Mult", "animalLimitMult", "1"),
        };

        public static readonly ToggleCommand[] WorldSwitches =
        {
            new ToggleCommand("Builder Mode", "buildermode"),
            new ToggleCommand("Trees Cut All", "treesCutAll"),
            new ToggleCommand("Lock Time Of Day", "lockTimeOfDay"),
            new ToggleCommand("Enable Structure Ghosts", "enableStructureGhosts"),
            new ToggleCommand("Greebles", "greebles"),
            new ToggleCommand("Cloud Enable", "cloudEnable"),
            new ToggleCommand("Cloud Shadows Enable", "cloudShadowsEnable"),
            new ToggleCommand("Force Rain", "forcerain"),
            new ToggleCommand("Demo Mode", "demoMode"),
            new ToggleCommand("Auto Drive Raft", "autoDriveRaft"),
        };

        public static readonly ActionCommand[] WorldActions =
        {
            new ActionCommand("Regrow All Trees", "regrowAllTrees"),
            new ActionCommand("Force Remove Trees", "forceRemoveTrees", true),
            new ActionCommand("Refill Containers", "refillContainers"),
            new ActionCommand("Restore All World Locators", "restoreAllWorldLocators"),
            new ActionCommand("Digging Clear", "diggingClear"),
            new ActionCommand("Door Open", "doorOpen"),
            new ActionCommand("Door Close", "doorClose"),
            new ActionCommand("Save", "save"),
            new ActionCommand("Save Player", "saveplayer"),
            new ActionCommand("Load Player", "loadplayer"),
            new ActionCommand("GC Collect", "gccollect"),
            new ActionCommand("Refresh Entities", "refreshEntities"),
        };

        public static readonly ValueCommand[] WorldValues =
        {
            new ValueCommand("Set Time Of Day", "setTimeOfDay", "12"),
            new ValueCommand("Set Current Day", "setCurrentDay", "1"),
            new ValueCommand("Jump Time Of Day", "jumpTimeOfDay", "1"),
            new ValueCommand("Set Game Time Speed", "setGameTimeSpeed", "1"),
            new ValueCommand("Set Wind Intensity", "setWindIntensity", "1"),
            new ValueCommand("Cloud Factor", "cloudFactor", "1"),
            new ValueCommand("Set Difficulty Mode", "setDifficultyMode", "Normal"),
            new ValueCommand("Set Game Mode", "setGameMode", "Normal"),
            new ValueCommand("Season", "season", "summer"),
        };

        public static readonly ToggleCommand[] MovementSwitches =
        {
            new ToggleCommand("Super Jump", "superJump"),
            new ToggleCommand("Gravity", "gravity"),
            new ToggleCommand("Free Camera", "freecamera"),
        };

        public static readonly ActionCommand[] MovementActions =
        {
            new ActionCommand("Follow Stop", "followStop"),
            new ActionCommand("Get Game Mode", "getGameMode"),
        };

        public static readonly ValueCommand[] MovementValues =
        {
            new ValueCommand("Goto", "goto", ""),
            new ValueCommand("Goto Tag", "gototag", ""),
            new ValueCommand("Goto Force", "gotoforce", ""),
            new ValueCommand("Follow", "follow", ""),
            new ValueCommand("Camera FOV", "cameraFov", "70"),
        };

        public static readonly ToggleCommand[] DisplaySwitches =
        {
            new ToggleCommand("Show HUD", "showHud"),
            new ToggleCommand("Show FPS", "showFps"),
            new ToggleCommand("Show In World UI", "showInWorldUi"),
            new ToggleCommand("Show Stimuli", "showStimuli"),
            new ToggleCommand("Show Projectile Trails", "showProjectileTrails"),
            new ToggleCommand("Show Active Lights", "showActiveLights"),
            new ToggleCommand("Show Collision Object Names", "showCollisionObjectNames"),
            new ToggleCommand("Show Mesh Object Names", "showMeshObjectNames"),
            new ToggleCommand("Show Mesh Triangle Counts", "showMeshTriangleCounts"),
            new ToggleCommand("Show Mesh Material Names", "showMeshMaterialNames"),
            new ToggleCommand("Show Trigger Collision", "showTriggerCollision"),
            new ToggleCommand("Show Object Location", "showObjectLocation"),
            new ToggleCommand("Render Spheres", "renderSpheres"),
            new ToggleCommand("Aniso Enabled", "anisoEnabled"),
            new ToggleCommand("Billboard Enabled", "billboardEnabled"),
            new ToggleCommand("New Fog Rendering", "newFogRendering"),
            new ToggleCommand("Logging", "logging"),
            new ToggleCommand("Log Hack", "loghack"),
            new ToggleCommand("Log Show Errors", "logShowErrors"),
            new ToggleCommand("Log Show Warnings", "logShowWarnings"),
            new ToggleCommand("Log Show Info", "logShowInfo"),
            new ToggleCommand("Diag Renderers", "diagRenderers"),
            new ToggleCommand("LOD Debug Ranges", "lodDebugRanges"),
            new ToggleCommand("LOD Debug Materials", "lodDebugMaterials"),
            new ToggleCommand("LOD Debug Billboards", "lodDebugBillboards"),
            new ToggleCommand("Damage Debug", "damageDebug"),
            new ToggleCommand("Audio Debug", "audioDebug"),
            new ToggleCommand("Footstep Debug", "footstepDebug"),
            new ToggleCommand("Radio Debug", "radioDebug"),
            new ToggleCommand("DAG Debug", "dagDebug"),
        };

        public static readonly ActionCommand[] DisplayActions =
        {
            new ActionCommand("Clear", "clear"),
            new ActionCommand("Help", "help"),
            new ActionCommand("Player Kill Stats", "playerKillStats"),
            new ActionCommand("List Objects", "listObjects"),
            new ActionCommand("List Active Entities", "listActiveEntities"),
            new ActionCommand("Profiler Snapshot", "profilersnapshot"),
            new ActionCommand("Log Show None", "logShowNone"),
            new ActionCommand("Material Snapshot", "materialSnapshot"),
            new ActionCommand("Show FPS", "showFps"),
        };

        public static readonly ValueCommand[] DisplayValues =
        {
            new ValueCommand("Quality Texture", "qualityTexture", "2"),
            new ValueCommand("Physics Update Time", "physicsUpdateTime", "0.02"),
            new ValueCommand("Set Setting", "setSetting", ""),
            new ValueCommand("Count", "count", ""),
            new ValueCommand("Count Tag", "counttag", ""),
        };

        public static readonly ActionCommand[] MultiplayerActions =
        {
            new ActionCommand("Kick Players", "kickPlayers", true),
            new ActionCommand("Disconnect Players", "disconnectPlayers", true),
            new ActionCommand("Dump Lobby Info", "dumplobbyinfo"),
            new ActionCommand("Net Spawn Player", "netSpawnPlayer"),
        };

        public static readonly ValueCommand[] MultiplayerValues =
        {
            new ValueCommand("Disconnect Player", "disconnectPlayer", ""),
            new ValueCommand("Send Message To", "sendMessageTo", ""),
            new ValueCommand("Join Steam Lobby", "joinSteamLobby", ""),
        };

        public static readonly ToggleCommand[] MultiplayerSwitches =
        {
            new ToggleCommand("Local Voice Debugging", "localVoiceDebugging"),
            new ToggleCommand("Net Animator", "netAnimator"),
            new ToggleCommand("Player Net Animator", "playernetanimator"),
            new ToggleCommand("Net Skinned Bones", "netSkinnedBones"),
            new ToggleCommand("Golf Cart Network Debug", "golfCartNetworkDebug"),
            new ToggleCommand("Players Trigger Traps", "playersTriggerTraps"),
        };

        public static readonly ActionCommand[] ItemActions =
        {
            new ActionCommand("Add All Items", "addAllItems"),
            new ActionCommand("Remove All Items", "removeAllItems", true),
        };

        public static readonly ValueCommand[] ItemValues =
        {
            new ValueCommand("Add Item", "additem", ""),
            new ValueCommand("Remove Item", "removeitem", ""),
            new ValueCommand("Equip Item", "equipitem", ""),
            new ValueCommand("Add Itemswithtag", "additemswithtag", ""),
            new ValueCommand("Set Stat", "setstat", ""),
        };

    }
}

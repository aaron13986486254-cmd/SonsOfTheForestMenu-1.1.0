// ═══════════════════════════════════════════════════════════════════════════
//  Game.cs · guarded accessors over the game's IL2CPP surface
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using Sons.Items.Core;
using Sons.StatSystem;
using TheForest.Utils;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// The plugin's read/write view of the running game.
///
/// <para>Every accessor here yields null, zero or false rather than throwing.
/// That is not defensive habit, it is a hard requirement: the panel is drawn on
/// the title screen too, where <c>LocalPlayer</c> and everything hanging off it
/// does not exist yet, and the per-frame tick can catch a component midway
/// through scene teardown. Callers treat an absent value as "not this frame"
/// and retry, so a failed read must never propagate.</para>
///
/// <para>Member names were verified against <c>BepInEx/interop</c> with a
/// metadata dump, not guessed. The game assemblies keep their original
/// namespaces (<c>TheForest.*</c>, <c>Sons.*</c>); only corlib types carry the
/// <c>Il2Cpp</c> prefix. Because the project references those interop
/// assemblies directly, a member that no longer exists breaks the build rather
/// than failing silently at runtime — after a game patch, re-run the metadata
/// check and the compiler does the rest.</para>
/// </summary>
[Cyberfox1337x]
internal static class Game
{
    // ── world state ─────────────────────────────────────────────────────

    /// <summary>
    /// True once a save is loaded and the local player exists. Every feature
    /// gates on this; nothing below is meaningful while it is false.
    /// </summary>
    internal static bool InWorld => Safe.Get("game.in-world",
        () => LocalPlayer._instance != null && LocalPlayer.IsInWorld);

    // ── local player components ─────────────────────────────────────────

    /// <summary>Health, stamina, hunger, thirst, rest and lung air.</summary>
    internal static Vitals Vitals => Safe.Get("player.vitals", () => LocalPlayer.Vitals);

    /// <summary>Movement controller — run and swim speed, jump, gravity.</summary>
    internal static FirstPersonCharacter Fp => Safe.Get("player.fp", () => LocalPlayer.FpCharacter);

    /// <summary>Warmth, armour and status effects.</summary>
    internal static PlayerStats Stats => Safe.Get("player.stats", () => LocalPlayer.Stats);

    /// <summary>The camera ESP and the map project world positions through.</summary>
    internal static Camera Cam => Safe.Get("player.camera", () => LocalPlayer.MainCam);

    /// <summary>Player transform. The teleport and fly paths write to this.</summary>
    internal static Transform PlayerTransform => Safe.Get("player.transform", () => LocalPlayer.Transform);

    /// <summary>Player rigidbody. Fly zeroes its velocity each frame.</summary>
    internal static Rigidbody Body => Safe.Get("player.rigidbody", () => LocalPlayer.Rigidbody);

    // ── stat helpers ────────────────────────────────────────────────────
    //
    // These run for several stats every frame from Features.Tick, so they use
    // the state-passing Safe overloads: the lambdas capture nothing, the
    // compiler caches them, and the hot path allocates no closures.

    /// <summary>
    /// Holds a stat at its ceiling. This is how every "infinite X" toggle
    /// works: the game's own drain still runs, and the value is pushed back up
    /// before the next frame reads it.
    /// </summary>
    internal static void Peg(Stat stat)
    {
        if (stat == null) return;
        Safe.Run("stat.peg", stat, s => s._currentValue = s._max);
    }

    internal static float Max(Stat stat) =>
        stat == null ? 0f : Safe.Get("stat.max", stat, s => s._max, 0f);

    internal static float Current(Stat stat) =>
        stat == null ? 0f : Safe.Get("stat.current", stat, s => s._currentValue, 0f);

    internal static void SetCurrent(Stat stat, float value)
    {
        if (stat == null) return;
        Safe.Run("stat.set-current", (stat, value), t => t.stat._currentValue = t.value);
    }

    internal static void SetMax(Stat stat, float value)
    {
        if (stat == null) return;
        Safe.Run("stat.set-max", (stat, value), t => t.stat._max = t.value);
    }

    // ── debug console ───────────────────────────────────────────────────

    /// <summary>
    /// Sends one command to the game's own debug console.
    ///
    /// <para>Spawning, season changes and most world switches route through
    /// here rather than reimplementing the effect. That is deliberate: the
    /// console applies the game's own validation, so an out-of-range id or a
    /// command issued at the wrong moment is rejected by the game instead of
    /// corrupting state behind its back.</para>
    /// </summary>
    /// <returns>False when no world is loaded, or the console refused it.</returns>
    internal static bool Console(string command)
    {
        if (string.IsNullOrWhiteSpace(command)) return false;

        // Site is keyed on the verb alone, so suppression groups by command
        // rather than by every distinct argument.
        string verb = command.Split(' ')[0];

        return Safe.Get($"console.{verb}", command, cmd =>
        {
            TheForest.DebugConsole console = TheForest.DebugConsole.Instance;
            if (console == null) return false;

            console.SendCommand(cmd);
            return true;
        }, fallback: false, noise: Noise.Warn);
    }

    // ── item database ───────────────────────────────────────────────────

    /// <summary>
    /// Every item the game knows about. Backs the spawner's search and the
    /// item-ESP labels. Null until a world is loaded.
    /// </summary>
    internal static Il2CppSystem.Collections.Generic.List<ItemData> Items =>
        Safe.Get("items.database", () => ItemDatabaseManager.Items);
}

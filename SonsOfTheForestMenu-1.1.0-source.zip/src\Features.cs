// ═══════════════════════════════════════════════════════════════════════════
//  Features.cs · toggle state and the per-frame enforcement tick
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System.Collections.Generic;
using Sons.Ai.Vail;
using Sons.Crafting.Structures;
using Sons.Weapon;
using TheForest.Utils;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Every toggle's state, and the tick that enforces it.
///
/// <para><b>How "infinite X" works.</b> The game's own drain keeps running; the
/// value is pushed back to its ceiling before the next frame reads it. That is
/// what the original mod did and what the game expects — suppressing the drain
/// outright desynchronises systems that watch the stat change.</para>
///
/// <para><b>What this type is not.</b> It holds state and enforces it. It does
/// not draw, and it does not know the menu exists. The UI reads and writes
/// these fields; nothing here calls back into it.</para>
/// </summary>
[Cyberfox1337x("feature state and tick")]
internal static class Features
{
    // ── player ──────────────────────────────────────────────────────────

    internal static bool GodMode, InfStamina, InfLung, MaxStrength, NoFallDamage;
    internal static bool NoHunger, NoThirst, NoCold, AlwaysRested;

    // ── combat ──────────────────────────────────────────────────────────

    internal static bool InfAmmo;
    internal static bool RapidFire;
    internal static bool AiPause;
    internal static float FireDelay = 0.06f;
    internal static float DamageTakenMult = 1f;

    // ── world ───────────────────────────────────────────────────────────

    internal static bool InstantBuild, InfiniteBuild, InfiniteLogs, InfRope;
    internal static float RopeLength = 300f;

    // ── movement ────────────────────────────────────────────────────────

    internal static bool Fly;
    internal static float RunSpeed = 1f, JumpMult = 1f, SwimSpeed = 1f;
    internal static float FlySpeed = 12f;

    /// <summary>Set by the menu. Suppresses fly input while the panel is up.</summary>
    internal static bool MenuOpen;

    /// <summary>Outcome of the last user action, shown in the status bar.</summary>
    internal static string LastResult = string.Empty;

    // ── tuning constants ────────────────────────────────────────────────

    /// <summary>Below this, a float dial is at its default and not worth writing.</summary>
    const float DialEpsilon = 0.001f;

    /// <summary>
    /// Seconds between weapon and rope-gun rescans. <c>FindObjectsOfType</c> is
    /// a full scene walk, so it cannot run per frame; four seconds still picks
    /// up a newly equipped weapon well within the time it takes to aim it.
    /// </summary>
    const float RescanSeconds = 4f;

    /// <summary>Fly speed multiplier while sprint is held.</summary>
    const float FlyBoostMultiplier = 3f;

    /// <summary>Seconds between avatar prefetch scans after a world loads.</summary>
    const float AvatarScanInterval = 12f;

    /// <summary>
    /// How long after a world load to keep prefetching avatars. Long enough to
    /// catch players who join during the loading screen, short enough that the
    /// scene walk is not a permanent cost.
    /// </summary>
    const float AvatarScanWindow = 36f;

    // ── console-command switches ────────────────────────────────────────
    //
    // State for every game command surfaced as an on/off switch. Held here
    // rather than in the UI so it survives tab changes and can be counted for
    // the status bar's ACTIVE readout.

    static readonly Dictionary<string, bool> _commandState = new();

    internal static bool GetCmd(string command) =>
        _commandState.TryGetValue(command, out bool on) && on;

    /// <summary>Flips a command switch and sends the matching on/off verb.</summary>
    internal static void SetCmd(string command, bool on)
    {
        _commandState[command] = on;

        string full = $"{command} {(on ? "on" : "off")}";
        LastResult = Game.Console(full) ? full : $"{command} needs a loaded world";
    }

    /// <summary>Fires a one-shot command.</summary>
    internal static void RunCmd(string command) =>
        LastResult = Game.Console(command) ? command : $"{command} failed";

    static int CmdActiveCount()
    {
        int active = 0;
        foreach (KeyValuePair<string, bool> entry in _commandState)
            if (entry.Value) active++;

        return active;
    }

    /// <summary>
    /// How many toggles are on, for the status bar. Counts the console
    /// switches and the ESP layers too, so the number matches what the user
    /// can see is enabled.
    /// </summary>
    internal static int ActiveCount()
    {
        int active = 0;

        if (GodMode) active++;
        if (InfStamina) active++;
        if (InfLung) active++;
        if (MaxStrength) active++;
        if (NoFallDamage) active++;
        if (NoHunger) active++;
        if (NoThirst) active++;
        if (NoCold) active++;
        if (AlwaysRested) active++;
        if (InfAmmo) active++;
        if (RapidFire) active++;
        if (AiPause) active++;
        if (Mathf.Abs(DamageTakenMult - 1f) > DialEpsilon) active++;
        if (InstantBuild) active++;
        if (InfiniteBuild) active++;
        if (InfiniteLogs) active++;
        if (InfRope) active++;
        if (Fly) active++;

        active += Esp.ActiveCount();

        if (ItemEsp.Enabled) active++;
        if (ItemEsp.ShowItems) active++;
        if (ItemEsp.ShowContainers) active++;
        if (ItemEsp.ShowCollectibles) active++;
        if (ItemEsp.ShowWaypoints) active++;
        if (ItemEsp.Radar) active++;

        return active + CmdActiveCount();
    }

    // ── baseline capture ────────────────────────────────────────────────

    static bool _baselineTaken;
    static float _baseRun = 1f, _baseJump = 1f, _baseSwim = 1f;
    static bool _baseFallDamage = true;

    /// <summary>
    /// Records the movement values the save loaded with, so Undo All can put
    /// them back. Captured once per world; cleared when the world unloads.
    /// </summary>
    internal static void CaptureBaseline()
    {
        if (_baselineTaken) return;

        FirstPersonCharacter fp = Game.Fp;
        if (fp == null) return;

        bool captured = Safe.Run("movement.capture-baseline", fp, character =>
        {
            _baseRun = character._runSpeed;
            _baseSwim = character._swimSpeed;
            _baseJump = character.JumpMultiplier;
            _baseFallDamage = character._allowFallDamage;
        }, Noise.Warn);

        if (!captured) return;

        RunSpeed = _baseRun;
        SwimSpeed = _baseSwim;
        JumpMult = _baseJump;
        _baselineTaken = true;

        Diag.Info($"baseline captured  run={_baseRun:0.##} " +
                  $"swim={_baseSwim:0.##} jump={_baseJump:0.##}");
    }

    /// <summary>Restores the captured baseline and clears the dials.</summary>
    internal static void RestoreBaseline()
    {
        FirstPersonCharacter fp = Game.Fp;
        if (fp == null) return;

        Safe.Run("movement.restore-baseline", fp, character =>
        {
            character._runSpeed = _baseRun;
            character._swimSpeed = _baseSwim;
            character.JumpMultiplier = _baseJump;
            character._allowFallDamage = _baseFallDamage;
        });

        RunSpeed = _baseRun;
        SwimSpeed = _baseSwim;
        JumpMult = _baseJump;
        NoFallDamage = false;
    }

    // ── the tick ────────────────────────────────────────────────────────

    static bool _wasInWorld;
    static float _nextAvatarScan, _avatarScanDeadline;

    /// <summary>
    /// Called once per frame from the menu behaviour.
    ///
    /// <para>Ordering matters: world state is checked first and everything
    /// short-circuits when no save is loaded, then the one-shot-on-transition
    /// work, then the per-frame enforcement. Each block is independently
    /// guarded so one failing subsystem does not stop the rest.</para>
    /// </summary>
    internal static void Tick()
    {
        if (!Game.InWorld)
        {
            ResetWorldState();
            return;
        }

        PrefetchAvatarsAfterLoad();
        CaptureBaseline();
        SyncConsoleToggles();

        EnforceVitals();
        EnforceWarmth();
        EnforceMovement();
        EnforceAiPause();
        EnforceFly();
    }

    /// <summary>Clears per-world state so the next load re-captures cleanly.</summary>
    static void ResetWorldState()
    {
        _baselineTaken = false;
        _wasInWorld = false;
        _nextAvatarScan = 0f;
        _avatarScanDeadline = 0f;
    }

    /// <summary>
    /// Warms the avatar cache shortly after a world loads, so the ONLINE and
    /// MAP tabs show pictures the first time they are opened rather than
    /// placeholders.
    ///
    /// <para>Each scan runs <c>FindObjectsOfType&lt;PlayerName&gt;</c> — a
    /// scene walk — so it is deliberately rare and stops entirely after the
    /// window closes. Late joiners after that are picked up by the ordinary
    /// tab-opened refresh.</para>
    /// </summary>
    static void PrefetchAvatarsAfterLoad()
    {
        if (!_wasInWorld)
        {
            _wasInWorld = true;
            _nextAvatarScan = 0f;
            _avatarScanDeadline = Time.unscaledTime + AvatarScanWindow;
        }

        bool due = Time.unscaledTime >= _nextAvatarScan
                && Time.unscaledTime <= _avatarScanDeadline;

        if (!due) return;

        _nextAvatarScan = Time.unscaledTime + AvatarScanInterval;

        // Roster.Prefetch guards itself; this only shields the tick from a
        // scene teardown racing the scan.
        Safe.Run("avatars.prefetch", Roster.Prefetch);
    }

    /// <summary>Holds the vitals-backed toggles at their ceilings.</summary>
    static void EnforceVitals()
    {
        Vitals vitals = Game.Vitals;
        if (vitals == null) return;

        if (GodMode)
        {
            Sons.StatSystem.Stat health = Safe.Get("vitals.health", vitals, v => v._health);
            float max = Game.Max(health);

            Game.SetCurrent(health, max);
            Safe.Run("vitals.target-health", (vitals, max), t => t.vitals._targetHealth = t.max);
        }

        if (InfLung)
        {
            Safe.Run("vitals.lung", vitals, v =>
            {
                var breathing = v.LungBreathing;
                if (breathing == null) return;

                breathing.CurrentLungAir = breathing.MaxLungAirCapacity;
            });
        }

        if (InstantBuild) SetInstantBuild(true);
        if (InfiniteBuild) SetInfiniteItems(true);
        if (InfiniteLogs) SetInfiniteHeld(true);
        if (InfAmmo) TopUpAmmo();
        if (RapidFire) SetRapidFire();
        if (InfRope) ExtendRope();

        if (InfStamina) Game.Peg(Safe.Get("vitals.stamina", vitals, v => v._stamina));
        if (MaxStrength) Game.Peg(Safe.Get("vitals.strength", vitals, v => v._strength));
        if (NoHunger) Game.Peg(Safe.Get("vitals.fullness", vitals, v => v._fullness));
        if (NoThirst) Game.Peg(Safe.Get("vitals.hydration", vitals, v => v._hydration));
        if (AlwaysRested) Game.Peg(Safe.Get("vitals.rested", vitals, v => v._rested));
    }

    /// <summary>
    /// Cold immunity. <c>InteriorSpaceWarmth</c> is a bool flag meaning "the
    /// player counts as indoors", not a temperature — there is no numeric
    /// warmth to raise.
    /// </summary>
    static void EnforceWarmth()
    {
        if (!NoCold) return;

        PlayerStats stats = Game.Stats;
        if (stats == null) return;

        Safe.Run("player.interior-warmth", stats, s => s.InteriorSpaceWarmth = true);
    }

    /// <summary>Applies the movement dials, writing only what actually differs.</summary>
    static void EnforceMovement()
    {
        FirstPersonCharacter fp = Game.Fp;
        if (fp == null) return;

        Safe.Run("movement.enforce", fp, character =>
        {
            character._allowFallDamage = !NoFallDamage;

            if (Mathf.Abs(character._runSpeed - RunSpeed) > DialEpsilon)
                character._runSpeed = RunSpeed;

            if (Mathf.Abs(character._swimSpeed - SwimSpeed) > DialEpsilon)
                character._swimSpeed = SwimSpeed;

            if (Mathf.Abs(character.JumpMultiplier - JumpMult) > DialEpsilon)
                character.JumpMultiplier = JumpMult;
        });
    }

    // ── AI simulation ───────────────────────────────────────────────────

    static bool _aiPaused;

    static void EnforceAiPause()
    {
        if (AiPause == _aiPaused) return;

        if (Safe.Run("ai.set-paused", AiPause, VailWorldSimulation.SetPaused, Noise.Warn))
            _aiPaused = AiPause;
    }

    // ── console-driven cheats ───────────────────────────────────────────

    static bool _consoleGod, _consoleEnergy, _consoleInstantBuild;
    static bool _consoleInitialised;

    /// <summary>
    /// Drives the game's own cheat commands.
    ///
    /// <para>These are switches the game ships with, so they are more reliable
    /// than emulating the same effect from outside and they keep working
    /// through systems this plugin does not patch. Fired only on transition:
    /// re-sending <c>godmode on</c> every frame would flood the console.</para>
    /// </summary>
    static void SyncConsoleToggles()
    {
        if (!_consoleInitialised)
        {
            _consoleGod = _consoleEnergy = _consoleInstantBuild = false;
            _consoleInitialised = true;
        }

        if (GodMode != _consoleGod)
        {
            Game.Console($"godmode {(GodMode ? "on" : "off")}");
            _consoleGod = GodMode;
        }

        if (InfStamina != _consoleEnergy)
        {
            Game.Console($"energyhack {(InfStamina ? "on" : "off")}");
            _consoleEnergy = InfStamina;
        }

        if (!InstantBuild && _consoleInstantBuild) SetInstantBuild(false);
        _consoleInstantBuild = InstantBuild;
    }

    // ── building ────────────────────────────────────────────────────────
    //
    // StructureCraftingSystem is a scene singleton with no static accessor, so
    // it is found once and cached rather than searched every frame.

    static StructureCraftingSystem _crafting;

    static StructureCraftingSystem Crafting
    {
        get
        {
            if (_crafting == null)
                _crafting = Safe.Get("build.crafting-system",
                    () => Object.FindObjectOfType<StructureCraftingSystem>());

            return _crafting;
        }
    }

    static void SetInstantBuild(bool on)
    {
        StructureCraftingSystem crafting = Crafting;
        if (crafting == null) return;

        Safe.Run("build.instant", (crafting, on), t => t.crafting.InstantBuild = t.on);
    }

    /// <summary>Infinite Build — structures stop consuming ingredients.</summary>
    static void SetInfiniteItems(bool on)
    {
        StructureCraftingSystem crafting = Crafting;
        if (crafting == null) return;

        Safe.Run("build.infinite-items", (crafting, on),
            t => t.crafting.InfiniteItemHack = t.on);
    }

    /// <summary>Infinite Logs — the carried-log stack stops depleting.</summary>
    static void SetInfiniteHeld(bool on)
    {
        Safe.Run("build.infinite-held", on, enabled =>
        {
            var inventory = LocalPlayer.Inventory;
            if (inventory == null) return;

            var held = inventory.HeldOnlyItemController;
            if (held == null) return;

            held.InfiniteHack = enabled;
        });
    }

    // ── weapons ─────────────────────────────────────────────────────────

    static float _nextScan;
    static RangedWeaponController[] _weapons;
    static RopeGunController _ropeGun;

    /// <summary>Refreshes the cached weapon and rope-gun handles, on a wide interval.</summary>
    static void Rescan()
    {
        if (Time.time < _nextScan) return;
        _nextScan = Time.time + RescanSeconds;

        Safe.Run("weapons.rescan", () =>
        {
            _weapons = Object.FindObjectsOfType<RangedWeaponController>();
            _ropeGun = Object.FindObjectOfType<RopeGunController>();
        });
    }

    /// <summary>
    /// Refills every magazine to its own capacity.
    ///
    /// <para><c>_ammo</c> is an Ammo object rather than a count, so the refill
    /// targets the magazine's real <c>_maxCount</c> instead of an invented
    /// number — otherwise the HUD shows a figure the weapon disagrees with.</para>
    /// </summary>
    static void TopUpAmmo()
    {
        Rescan();
        if (_weapons == null) return;

        foreach (RangedWeaponController controller in _weapons)
        {
            if (controller == null) continue;

            Safe.Run("weapons.top-up-ammo", controller, weapon =>
            {
                var ranged = weapon._rangedWeapon;
                if (ranged == null) return;

                var ammo = ranged._ammo;
                if (ammo == null) return;

                if (ammo._currentCount < ammo._maxCount)
                    ammo._currentCount = ammo._maxCount;
            });
        }
    }

    /// <summary>
    /// Collapses each weapon's fire delay.
    ///
    /// <para><c>_fireDelay</c> is the weapon's design value and
    /// <c>_nextFireDelay</c> the live countdown; dropping both makes the next
    /// shot come out immediately. Note this does not restore the original —
    /// see the known limits in the README.</para>
    /// </summary>
    static void SetRapidFire()
    {
        Rescan();
        if (_weapons == null) return;

        foreach (RangedWeaponController controller in _weapons)
        {
            if (controller == null) continue;

            Safe.Run("weapons.rapid-fire", controller, weapon =>
            {
                if (Mathf.Abs(weapon._fireDelay - FireDelay) > 0.0005f)
                    weapon._fireDelay = FireDelay;

                if (weapon._nextFireDelay > FireDelay)
                    weapon._nextFireDelay = FireDelay;
            });
        }
    }

    static void ExtendRope()
    {
        Rescan();
        if (_ropeGun == null) return;

        Safe.Run("weapons.rope-length", _ropeGun, gun =>
        {
            gun._maxRopeLength = RopeLength;
            gun._maxFiringRange = RopeLength;
            gun._currentRopeLength = RopeLength;
        });
    }

    // ── flight ──────────────────────────────────────────────────────────

    static bool _wasFlying;

    static void EnforceFly()
    {
        if (Fly)
        {
            DoFly();
            _wasFlying = true;
            return;
        }

        if (!_wasFlying) return;

        StopFly();
        _wasFlying = false;
    }

    /// <summary>
    /// Free flight.
    ///
    /// <para>Writing the transform alone does not work: gravity and the
    /// rigidbody pull the player straight back down within the same frame. Fly
    /// has to disable the character's gravity <i>and</i> keep the rigidbody's
    /// velocity zeroed, or momentum accumulates and you sink.</para>
    /// </summary>
    static void DoFly()
    {
        FirstPersonCharacter fp = Game.Fp;
        Transform player = Game.PlayerTransform;
        Camera camera = Game.Cam;

        if (fp == null || player == null || camera == null) return;

        Safe.Run("movement.fly", fp, character => character._disableGravity = true);

        Rigidbody body = Game.Body;
        if (body != null)
        {
            Safe.Run("movement.fly-zero-velocity", body, rigidbody =>
            {
                rigidbody.velocity = Vector3.zero;
                rigidbody.angularVelocity = Vector3.zero;
            });
        }

        // Hover in place while the menu is up: gravity stays off so the player
        // does not drop out of the sky mid-click, but WASD belongs to the UI.
        if (MenuOpen) return;

        Vector3 direction = ReadFlyInput(camera.transform);
        if (direction == Vector3.zero) return;

        float speed = FlySpeed * (Input.GetKey(KeyCode.LeftShift) ? FlyBoostMultiplier : 1f);

        Safe.Run("movement.fly-move", (player, direction, speed),
            t => t.player.position += t.direction.normalized * t.speed * Time.deltaTime);
    }

    /// <summary>Camera-relative movement vector from the fly keys.</summary>
    static Vector3 ReadFlyInput(Transform camera)
    {
        Vector3 direction = Vector3.zero;

        if (Input.GetKey(KeyCode.W)) direction += camera.forward;
        if (Input.GetKey(KeyCode.S)) direction -= camera.forward;
        if (Input.GetKey(KeyCode.D)) direction += camera.right;
        if (Input.GetKey(KeyCode.A)) direction -= camera.right;
        if (Input.GetKey(KeyCode.Space)) direction += Vector3.up;

        if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.C))
            direction -= Vector3.up;

        return direction;
    }

    /// <summary>Hands gravity back so the player falls normally again.</summary>
    static void StopFly()
    {
        FirstPersonCharacter fp = Game.Fp;
        if (fp == null) return;

        Safe.Run("movement.fly-stop", fp, character => character._disableGravity = false);
    }

    // ── one-shot actions ────────────────────────────────────────────────

    /// <summary>Maximum items a single spawn request will place.</summary>
    const int MaxSpawnBatch = 100;

    internal static void SetSeason(string season)
    {
        LastResult = Game.Console($"season {season.ToLowerInvariant()}")
            ? $"Season set to {season}"
            : "Season change needs a loaded world";
    }

    /// <summary>
    /// Spawns an item, repeating the console command per unit. Capped so a
    /// mistyped quantity cannot lock the game up issuing thousands of spawns.
    /// </summary>
    internal static void SpawnItem(int id, int amount)
    {
        int requested = Mathf.Clamp(amount, 1, MaxSpawnBatch);
        int spawned = 0;

        for (int i = 0; i < requested; i++)
            if (Game.Console($"spawnitem {id}")) spawned++;

        LastResult = spawned > 0
            ? $"Spawned {spawned}× item {id}"
            : $"Could not spawn item {id}";
    }

    /// <summary>Spawns characters; the game's own command takes the count.</summary>
    internal static void SpawnCharacter(string key, int amount)
    {
        int requested = Mathf.Max(1, amount);

        LastResult = Game.Console($"addcharacter {key} {requested}")
            ? $"Spawned {requested}× {key}"
            : "Spawn needs a loaded world";
    }
}

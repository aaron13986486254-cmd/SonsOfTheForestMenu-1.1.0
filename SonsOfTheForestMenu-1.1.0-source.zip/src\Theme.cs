// ═══════════════════════════════════════════════════════════════════════════
//  Theme.cs · design tokens, palettes, IMGUI styles
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// The Vein panel's design tokens, ported to Unity IMGUI.
    /// Hex values are copied verbatim from public/assets/site.css so the two
    /// surfaces stay in sync; --live/--dead are additions IMGUI needs for
    /// on/off state, kept in the olive family so they never fight --rust.
    /// </summary>
    [Cyberfox1337x]
    internal static class Theme
    {
        // ── palette ──────────────────────────────────────────────────────
        public static readonly Color Ink        = Hex(0x0A, 0x0A, 0x08);
        public static readonly Color Paper      = Hex(0xD8, 0xD1, 0xBD);
        public static readonly Color Bone       = Hex(0xEE, 0xE8, 0xD8);
        public static readonly Color Ash        = Hex(0xAA, 0xA4, 0x93);
        public static readonly Color Rust       = Hex(0xB5, 0x34, 0x23);
        public static readonly Color RustBright = Hex(0xE0, 0x46, 0x2F);
        public static readonly Color Olive      = Hex(0x81, 0x83, 0x6A);
        public static readonly Color Live       = Hex(0x8E, 0xA2, 0x56);
        public static readonly Color Dead       = Hex(0x5C, 0x59, 0x50);

        public static readonly Color Panel      = new Color(0.047f, 0.047f, 0.039f, 0.94f);
        public static readonly Color Line       = new Color(0.882f, 0.847f, 0.745f, 0.20f);
        public static readonly Color RailActive = new Color(0.71f, 0.20f, 0.14f, 0.22f);

        /// <summary>
        /// <see cref="RailActive"/> at higher alpha, for a pressed button. Same
        /// hue deliberately: a press should read as more of the hover, not as a
        /// different colour appearing.
        /// </summary>
        public static readonly Color RailPressed = new Color(0.71f, 0.20f, 0.14f, 0.38f);
        public static readonly Color RowHover   = new Color(0.847f, 0.820f, 0.741f, 0.06f);
        public static readonly Color LiveWash   = new Color(0.557f, 0.635f, 0.337f, 0.07f);
        public static readonly Color RustWash   = new Color(0.71f, 0.20f, 0.14f, 0.12f);
        public static readonly Color FieldBg    = new Color(0f, 0f, 0f, 0.45f);

        // ── icon palette ─────────────────────────────────────────────────
        // Section-header icons bake their colours into the texture instead of
        // being tinted at draw time, so one icon can carry two or three tones.
        // These are the only hues they may use: six families extended from the
        // panel palette above, each with a light and a dark member so a shape
        // can be shaded without inventing a new colour. Keeping the set closed
        // is what stops fifty hand-drawn icons turning into colour soup.
        public static readonly Color IconBone   = Hex(0xEE, 0xE8, 0xD8); // neutral, bone, paper
        public static readonly Color IconAsh    = Hex(0xAA, 0xA4, 0x93); // muted secondary
        public static readonly Color IconSlate  = Hex(0x6E, 0x6A, 0x60); // casings, shadow
        public static readonly Color IconRust   = Hex(0xE0, 0x46, 0x2F); // danger, damage, fire
        public static readonly Color IconEmber  = Hex(0x9E, 0x2C, 0x1C); // rust shadow
        public static readonly Color IconOlive  = Hex(0x8E, 0xA2, 0x56); // nature, life, go
        public static readonly Color IconMoss   = Hex(0x5A, 0x6B, 0x35); // olive shadow
        public static readonly Color IconGold   = Hex(0xE0, 0xB0, 0x2F); // reward, energy, keys
        public static readonly Color IconAmber  = Hex(0xA8, 0x7A, 0x1C); // gold shadow
        public static readonly Color IconSteel  = Hex(0x6C, 0x93, 0xA8); // water, tech, network
        public static readonly Color IconSky    = Hex(0xA6, 0xC9, 0xDA); // steel highlight
        public static readonly Color IconBlood  = Hex(0xA0, 0x3A, 0x46); // mutants, biohazard

        static Color Hex(int r, int g, int b) => new Color(r / 255f, g / 255f, b / 255f, 1f);

        // ── value ramp (dials) ───────────────────────────────────────────
        // Dial readouts are colour-coded by how far the value sits between the
        // dial's min and max: low = rust, mid = amber, high = green.
        static readonly Color RampRed    = Hex(0xE0, 0x46, 0x2F);
        static readonly Color RampYellow = Hex(0xE0, 0xC0, 0x2F);
        static readonly Color RampGreen  = Hex(0x6F, 0xBF, 0x4A);

        /// <summary>Maps 0..1 onto the red → yellow → green ramp.</summary>
        public static Color Ramp(float t)
        {
            t = Mathf.Clamp01(t);
            return t < 0.5f
                ? Color.Lerp(RampRed, RampYellow, t * 2f)
                : Color.Lerp(RampYellow, RampGreen, (t - 0.5f) * 2f);
        }

        // ── textures ─────────────────────────────────────────────────────
        // Every texture here is allocated once in Build_ and lives for the
        // process. Anything not actually drawn is pure boot cost and dead
        // weight, so the set is kept honest: if a style stops using one, it
        // comes out. TexRust/TexRustBright and TexBtnRust/TexBtnRustBright were
        // dropped when the buttons moved off a permanent rust fill.
        public static Texture2D TexPanel, TexLine, TexRail, TexRailPressed,
                                TexHover, TexLiveWash,
                                TexRustWash, TexField,
                                TexLive, TexDead, TexTransparent, TexWhite, TexInk,
                                TexRoundFill, TexRoundStroke,
                                TexRoundFillMirror, TexRoundStrokeMirror,
                                TexRoundFillBot, TexRoundStrokeBot,
                                TexRoundFillMirrorBot, TexRoundStrokeMirrorBot,
                                TexBtn, TexBtnHover,
                                TexBtnRustWash, TexBtnInk,
                                TexBtnRail, TexBtnRailPressed;

        // ── styles ───────────────────────────────────────────────────────
        public static GUIStyle Wordmark, Build, GroupLabel, Lede, TabOff, TabOn,
                               SwitchOff, SwitchOn, SwitchDanger, StateOff, StateOn,
                               Btn, BtnPrimary, ChipOff, ChipOn, RowStyle, RowId,
                               RowTag, DialLabel, DialValue, Field, FieldHint, StatusText,
                               Kbd, Watermark, EspLabel, DropdownRow;

        static bool _built;
        static Font _display, _body, _mono;

        public static void Build_()
        {
            if (_built) return;

            TexPanel       = Solid(Panel);
            TexLine        = Solid(Line);
            TexRail        = Solid(RailActive);
            TexRailPressed = Solid(RailPressed);
            TexHover       = Solid(RowHover);
            TexLiveWash    = Solid(LiveWash);
            TexRustWash    = Solid(RustWash);
            TexField       = Solid(FieldBg);
            TexLive        = Solid(Live);
            TexDead        = Solid(Dead);
            TexInk         = Solid(Ink);
            TexWhite       = Solid(Color.white);
            TexTransparent = Solid(new Color(0, 0, 0, 0));
            RebuildRoundTextures();
            TexBtn          = RoundedButton(Line);
            TexBtnHover     = RoundedButton(RowHover);
            TexBtnRustWash  = RoundedButton(RustWash);
            TexBtnInk       = RoundedButton(Ink);
            // Button hover/press, matched to the rail's selected-category wash.
            // Pressed is the same hue at higher alpha so the press reads as
            // "more of the same" rather than as a second, unrelated colour.
            TexBtnRail        = RoundedButton(RailActive);
            TexBtnRailPressed = RoundedButton(RailPressed);

            // Vein uses Haettenschweiler for display and Georgia for body.
            // CreateDynamicFontFromOSFont pulls the real faces when installed;
            // Unity falls back to its built-in font when they are not.
            _display = OsFont(new[] { "Haettenschweiler", "Arial Narrow", "Impact" }, 22);
            _body    = OsFont(new[] { "Georgia", "Times New Roman" }, 14);
            _mono    = OsFont(new[] { "Consolas", "Courier New" }, 12);

            Wordmark = new GUIStyle
            {
                font = _display, fontSize = 30, alignment = TextAnchor.MiddleLeft,
                richText = true, wordWrap = false
            };
            Wordmark.normal.textColor = Paper;

            Build = Label(_mono, 11, Ash);
            Watermark = Label(_display, 18, Paper);
            Lede = Label(_body, 13, Ash);
            Lede.wordWrap = true;
            Lede.padding = new RectOffset(0, 0, 0, 8);

            GroupLabel = Label(_display, 15, Olive);
            GroupLabel.padding = new RectOffset(0, 0, 8, 4);

            // Rail category buttons: the row number sits at the left and the
            // label is centred in the remaining rail width, so the navigation
            // column reads balanced.
            TabOff = new GUIStyle
            {
                font = _display, fontSize = 18, alignment = TextAnchor.MiddleCenter,
                padding = new RectOffset(0, 0, 6, 6), wordWrap = false
            };
            TabOff.normal.textColor = Ash;
            TabOff.hover.textColor = Bone;
            TabOff.hover.background = TexHover;

            TabOn = new GUIStyle(TabOff);
            TabOn.normal.textColor = Paper;
            TabOn.normal.background = TexRail;
            TabOn.hover.textColor = Paper;
            TabOn.hover.background = TexRail;

            SwitchOff = new GUIStyle
            {
                font = _body, fontSize = 13, alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(10, 8, 6, 6), wordWrap = false
            };
            SwitchOff.normal.textColor = Ash;
            SwitchOff.normal.background = TexTransparent;
            SwitchOff.hover.textColor = Bone;
            SwitchOff.hover.background = TexHover;

            SwitchOn = new GUIStyle(SwitchOff);
            SwitchOn.normal.textColor = Bone;
            SwitchOn.normal.background = TexLiveWash;
            SwitchOn.hover.textColor = Bone;
            SwitchOn.hover.background = TexLiveWash;

            SwitchDanger = new GUIStyle(SwitchOn);
            SwitchDanger.normal.background = TexRustWash;
            SwitchDanger.hover.background = TexRustWash;

            StateOff = Label(_mono, 9, Dead);
            StateOff.alignment = TextAnchor.MiddleRight;
            StateOn = Label(_mono, 9, Live);
            StateOn.alignment = TextAnchor.MiddleRight;

            // Buttons and chips use rounded fills: the 16x16 corner texture is
            // nine-sliced via the style border, so the 6px radius survives any
            // button size (down to ~16px tall).
            Btn = new GUIStyle
            {
                font = _display, fontSize = 16, alignment = TextAnchor.MiddleCenter,
                padding = new RectOffset(12, 12, 5, 5),
                border = new RectOffset(BtnBorder, BtnBorder, BtnBorder, BtnBorder)
            };
            // Grey at rest, rail-active wash under the cursor.
            //
            // The hover fill is RailActive — the exact token the left rail uses
            // to mark the selected category — so "the thing under my cursor" and
            // "the thing I have selected" are the same colour throughout the
            // panel. Reusing the token rather than a matched hex means the two
            // cannot drift apart later.
            //
            // Nothing is rust-*filled* at rest any more. A screen where a third
            // of the controls sit permanently red spends its loudest colour on
            // ordinary actions and has nothing left to say when something is
            // genuinely wrong; as a transient hover it costs nothing.
            Btn.normal.textColor = Bone;
            Btn.normal.background = TexBtn;
            Btn.hover.textColor = Paper;
            Btn.hover.background = TexBtnRail;
            Btn.active.textColor = Bone;
            Btn.active.background = TexBtnRailPressed;

            // Primary confirm actions (SAVE KEY, RUN, APPLY …) share Btn exactly.
            // Kept as its own style rather than collapsed into Btn so the 15 call
            // sites keep stating which control is the primary one in its section,
            // and so re-differentiating later (weight, border, spacing — anything
            // but a permanent fill) is a one-line change here instead of a hunt
            // through the tabs.
            BtnPrimary = new GUIStyle(Btn);

            ChipOff = new GUIStyle(Btn) { fontSize = 15 };
            ChipOff.normal.background = TexBtnInk;
            ChipOff.normal.textColor = Ash;
            ChipOff.hover.background = TexBtnHover;
            ChipOff.hover.textColor = Bone;
            ChipOn = new GUIStyle(ChipOff);
            ChipOn.normal.background = TexBtnRustWash;
            ChipOn.normal.textColor = Paper;

            RowStyle = new GUIStyle
            {
                font = _body, fontSize = 13, alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(10, 8, 4, 4), wordWrap = false
            };
            // Rows share the buttons' hover wash, so "under the cursor" looks
            // the same whatever kind of control it is.
            //
            // The three states are one ladder of the same hue, deepening with
            // commitment: nothing at rest, RailActive hovered, RailPressed
            // selected. Selected used to be RustWash at 0.12 against a 0.22
            // hover, so merely pointing at a row made it louder than the row you
            // had actually chosen.
            RowStyle.normal.textColor = Bone;
            RowStyle.hover.background = TexRail;
            RowStyle.hover.textColor = Paper;
            RowStyle.onNormal.background = TexRailPressed;
            RowStyle.onNormal.textColor = Paper;
            RowStyle.onHover.background = TexRailPressed;
            RowStyle.onHover.textColor = Paper;

            // White text on the solid-ink dropdown — no background so the
            // Ink fill and RustWash pick stripe show through.
            DropdownRow = new GUIStyle
            {
                font = _body, fontSize = 13, alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(10, 8, 3, 3), wordWrap = false
            };
            DropdownRow.normal.textColor = Paper;
            DropdownRow.hover.textColor = Paper;
            DropdownRow.hover.background = TexRail;

            RowId = Label(_mono, 11, Ash);
            RowTag = Label(_mono, 9, Dead);
            RowTag.alignment = TextAnchor.MiddleRight;

            DialLabel = Label(_body, 13, Bone);
            DialValue = Label(_mono, 12, Paper);
            DialValue.alignment = TextAnchor.MiddleRight;

            Field = new GUIStyle
            {
                font = _mono, fontSize = 12, alignment = TextAnchor.MiddleLeft,
                padding = new RectOffset(7, 7, 4, 4)
            };
            Field.normal.textColor = Paper;
            Field.normal.background = TexField;
            Field.focused.textColor = Paper;
            Field.focused.background = TexField;

            // Placeholder text for an empty field. Same metrics as Field so the
            // hint sits exactly where the caret will, and no background of its
            // own — it is drawn over the field, not instead of it. Without this
            // an empty field is an unlabelled black rectangle that reads as a
            // rendering artifact rather than somewhere to type.
            FieldHint = new GUIStyle(Field);
            FieldHint.normal.background = null;
            FieldHint.focused.background = null;
            FieldHint.normal.textColor = Dead;
            FieldHint.focused.textColor = Dead;

            StatusText = Label(_mono, 10, Dead);
            Kbd = Label(_mono, 12, Paper);
            Kbd.alignment = TextAnchor.MiddleCenter;
            Kbd.normal.background = TexLine;
            Kbd.padding = new RectOffset(5, 5, 2, 2);

            EspLabel = Label(_mono, 11, Bone);
            EspLabel.alignment = TextAnchor.MiddleCenter;

            _built = true;
        }

        static GUIStyle Label(Font f, int size, Color c)
        {
            var s = new GUIStyle
            {
                font = f, fontSize = size,
                alignment = TextAnchor.MiddleLeft, wordWrap = false
            };
            s.normal.textColor = c;
            return s;
        }

        static Font OsFont(string[] names, int size)
        {
            for (int i = 0; i < names.Length; i++)
            {
                try
                {
                    var f = Font.CreateDynamicFontFromOSFont(names[i], size);
                    if (f != null) return f;
                }
                catch { /* face not installed on this machine */ }
            }
            return null; // Unity substitutes its built-in font
        }

        // ── rounded button fills ─────────────────────────────────────────
        const int BtnTex = 16, BtnRadius = 6, BtnBorder = 8;

        /// <summary>
        /// A solid rounded fill for button backgrounds. All four corners get
        /// the same cutout — nine-slicing maps each texture corner region to
        /// the matching button corner, so a single-cutout texture would leave
        /// three corners square. The color (including alpha) is baked in and
        /// corners are anti-aliased over 1px. The y axis is flipped for the
        /// same reason as RoundTexture (row 0 renders at the rect's bottom).
        /// </summary>
        static Texture2D RoundedButton(Color c)
        {
            var tex = new Texture2D(BtnTex, BtnTex, TextureFormat.RGBA32, false);
            float r = BtnRadius;
            for (int y = 0; y < BtnTex; y++)
            {
                for (int x = 0; x < BtnTex; x++)
                {
                    float px = x + 0.5f;
                    float py = BtnTex - y - 0.5f;
                    // distance to the nearest horizontal / vertical edge — a
                    // corner region is where both are within the radius
                    float cx = Mathf.Min(px, BtnTex - px);
                    float cy = Mathf.Min(py, BtnTex - py);
                    float a = 1f;
                    if (cx < r && cy < r)
                    {
                        float dx = cx - r, dy = cy - r;
                        float dist = Mathf.Sqrt(dx * dx + dy * dy);
                        a = Mathf.Clamp01(r - dist + 0.5f);
                    }
                    tex.SetPixel(x, y, new Color(c.r, c.g, c.b, c.a * a));
                }
            }
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.hideFlags = HideFlags.HideAndDontSave;
            tex.Apply();
            return tex;
        }

        static Texture2D Solid(Color c)
        {
            var t = new Texture2D(2, 2, TextureFormat.RGBA32, false);
            for (int x = 0; x < 2; x++)
                for (int y = 0; y < 2; y++)
                    t.SetPixel(x, y, c);
            t.filterMode = FilterMode.Point;
            t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.HideAndDontSave;
            t.Apply();
            return t;
        }

        /// <summary>1px rule in --line, used for the group dividers.</summary>
        public static void Rule(Rect r)
        {
            var old = GUI.color;
            GUI.color = Line;
            GUI.DrawTexture(r, TexWhite);
            GUI.color = old;
        }

        public static void Fill(Rect r, Color c)
        {
            var old = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(r, TexWhite);
            GUI.color = old;
        }

        public static void Box(Rect r, Color c, float w = 1f)
        {
            Fill(new Rect(r.x, r.y, r.width, w), c);
            Fill(new Rect(r.x, r.yMax - w, r.width, w), c);
            Fill(new Rect(r.x, r.y, w, r.height), c);
            Fill(new Rect(r.xMax - w, r.y, w, r.height), c);
        }

        // ── rounded panel ────────────────────────────────────────────────
        // IMGUI has no rounded primitives, so the corner is pre-rendered into
        // a (radius + border)-sized texture and nine-sliced: the four corners
        // are drawn at native size, the edges as plain rects. The corner shape
        // is symmetric across its diagonal, so one texture serves all four
        // corners regardless of flip. The radius is live-tunable from the
        // SETTINGS tab — RebuildRoundTextures regenerates it on change.
        public static int RoundR = 10;
        const int RoundT = 2;
        public static int RoundS => RoundR + RoundT;

        public static void RebuildRoundTextures()
        {
            TexRoundFill = RoundTexture(false, false, false);
            TexRoundFillMirror = RoundTexture(false, true, false);
            TexRoundStroke = RoundTexture(true, false, false);
            TexRoundStrokeMirror = RoundTexture(true, true, false);
            TexRoundFillBot = RoundTexture(false, false, true);
            TexRoundFillMirrorBot = RoundTexture(false, true, true);
            TexRoundStrokeBot = RoundTexture(true, false, true);
            TexRoundStrokeMirrorBot = RoundTexture(true, true, true);
        }

        /// <summary>Panel background with the same 10px rounded corners.</summary>
        public static void RoundedFill(Rect r, Color c)
        {
            if (r.width < RoundS * 2 || r.height < RoundS * 2)
            {
                Fill(r, c);
                return;
            }
            float s = RoundS;
            var old = GUI.color;
            GUI.color = c;
            // TL and BR use the base (non-mirrored) corner; TR and BL mirror
            // horizontally. The bottom corners are generated with y+0.5 so the
            // arc aligns with the panel's bottom edge.
            GUI.DrawTexture(new Rect(r.x, r.y, s, s), TexRoundFill);
            GUI.DrawTexture(new Rect(r.xMax - s, r.y, s, s), TexRoundFillMirror);
            GUI.DrawTexture(new Rect(r.x, r.yMax - s, s, s), TexRoundFillBot);
            GUI.DrawTexture(new Rect(r.xMax - s, r.yMax - s, s, s), TexRoundFillMirrorBot);
            GUI.color = old;
            Fill(new Rect(r.x + s, r.y, r.width - 2 * s, s), c);
            Fill(new Rect(r.x + s, r.yMax - s, r.width - 2 * s, s), c);
            Fill(new Rect(r.x, r.y + s, s, r.height - 2 * s), c);
            Fill(new Rect(r.xMax - s, r.y + s, s, r.height - 2 * s), c);
            Fill(new Rect(r.x + s, r.y + s, r.width - 2 * s, r.height - 2 * s), c);
        }

        /// <summary>Rounded 2px border, matching the panel's corner radius.</summary>
        public static void RoundedBox(Rect r, Color c)
        {
            if (r.width < RoundS * 2 || r.height < RoundS * 2)
            {
                Box(r, c, RoundT);
                return;
            }
            float s = RoundS, w = RoundT;
            var old = GUI.color;
            GUI.color = c;
            GUI.DrawTexture(new Rect(r.x, r.y, s, s), TexRoundStroke);
            GUI.DrawTexture(new Rect(r.xMax - s, r.y, s, s), TexRoundStrokeMirror);
            GUI.DrawTexture(new Rect(r.x, r.yMax - s, s, s), TexRoundStrokeBot);
            GUI.DrawTexture(new Rect(r.xMax - s, r.yMax - s, s, s), TexRoundStrokeMirrorBot);
            GUI.color = old;
            Fill(new Rect(r.x + s, r.y, r.width - 2 * s, w), c);
            Fill(new Rect(r.x + s, r.yMax - w, r.width - 2 * s, w), c);
            Fill(new Rect(r.x, r.y + s, w, r.height - 2 * s), c);
            Fill(new Rect(r.xMax - w, r.y + s, w, r.height - 2 * s), c);
        }

        /// <summary>
        /// Pre-renders one rounded corner as a white texture with alpha — the
        /// fill (inside the rounded rect) or the stroke (the 2px border band).
        /// Coverage is anti-aliased over 1px. Pixel centre (px, py) is evaluated
        /// on the y-flipped axis: Texture2D row 0 is the BOTTOM of the texture
        /// and GUI.DrawTexture renders it at the rect's bottom, so the coverage
        /// y must be inverted or the corner draws upside down.
        /// </summary>
        static Texture2D RoundTexture(bool stroke, bool mirror, bool bottom)
        {
            var tex = new Texture2D(RoundS, RoundS, TextureFormat.RGBA32, false);
            for (int y = 0; y < RoundS; y++)
            {
                for (int x = 0; x < RoundS; x++)
                {
                    int mx = mirror ? RoundS - 1 - x : x;
                    float px = mx + 0.5f;
                    // Top corners invert Y (cutout at texture top → panel top).
                    // Bottom corners don't (cutout at texture bottom → panel bottom).
                    float py = bottom ? (y + 0.5f) : (RoundS - y - 0.5f);
                    float a = stroke ? RoundStrokeCoverage(px, py) : RoundFillCoverage(px, py);
                    tex.SetPixel(x, y, new Color(1f, 1f, 1f, a));
                }
            }
            tex.filterMode = FilterMode.Bilinear;
            tex.wrapMode = TextureWrapMode.Clamp;
            tex.hideFlags = HideFlags.HideAndDontSave;
            tex.Apply();
            return tex;
        }

        /// <summary>Inside the rounded rect: the arc quadrant or the straight sides.</summary>
        static float RoundFillCoverage(float px, float py)
        {
            if (px >= RoundR || py >= RoundR) return 1f;
            float dx = px - RoundR, dy = py - RoundR;
            float dist = Mathf.Sqrt(dx * dx + dy * dy);
            return Mathf.Clamp01(RoundR - dist + 0.5f);
        }

        /// <summary>
        /// The 2px border band: the arc annulus between radius 8 and 10 in the
        /// corner quadrant, plus the straight strips along the two edges.
        /// </summary>
        static float RoundStrokeCoverage(float px, float py)
        {
            float band;
            if (px <= RoundR && py <= RoundR)
            {
                float dx = px - RoundR, dy = py - RoundR;
                float dist = Mathf.Sqrt(dx * dx + dy * dy);
                band = Mathf.Min(RoundR - dist, dist - (RoundR - RoundT));
            }
            else if (px >= RoundR && py < RoundR)
            {
                band = Mathf.Min(py, RoundT - py); // top edge strip
            }
            else if (py >= RoundR && px < RoundR)
            {
                band = Mathf.Min(px, RoundT - px); // left edge strip
            }
            else
            {
                band = -1f; // beyond the corner — outside the rounded rect
            }
            return Mathf.Clamp01(band + 0.5f);
        }
    }
}

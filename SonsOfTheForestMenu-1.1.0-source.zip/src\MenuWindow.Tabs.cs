// ═══════════════════════════════════════════════════════════════════════════
//  MenuWindow.Tabs.cs · the tab bodies and spawn-list renderers
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// The twelve tab bodies plus their local state and the spawn-list
    /// renderers. Each tab is pure presentation: it reads feature state, draws
    /// controls, and writes back only what the user changed — the actual game
    /// effects live in Features / DirectGameApi / EngineCheats / Scene / etc.
    /// </summary>
    public partial class MenuWindow
    {
        // ── tab state ────────────────────────────────────────────────────
        string _itemId = "392", _itemQty = "1", _search = "";
        string _mutQty = "1", _aniQty = "1", _compQty = "1";
        int _selMutant = -1, _selAnimal = -1, _selCompanion = -1;

        // teleport spots
        string _spotName = "";

        // settings tab — Steam key save feedback (shown under the field)
        string _keyStatus;
        bool _keyStatusOk;

        // world tab — season selection tracking
        int _seasonIdx = -1;

        // cutscene tab
        string _cutsceneName = "";

        // console tab
        string _cmdSearch = "", _cmdLine = "";
        readonly List<string> _history = new List<string>();

        // ── spawn data (wiki's addcharacter list, arity-checked) ─────────
        /// <summary>Friendly / story characters from the wiki's addcharacter list.</summary>
        static readonly (string Key, string Label, bool Boss)[] Companions =
        {
            ("robby","Kelvin",false), ("virginia","Virginia",false),
            ("timmy","Timmy",false), ("helicopter","Helicopter",false),
            ("mrpuffton","Mr. Puffton",true), ("mrspuffton","Mrs. Puffton",true),
        };

        /// <summary>Mutants, bosses and cannibal variants from the wiki's addcharacter list.</summary>
        static readonly (string Key, string Label, bool Boss)[] Mutants =
        {
            ("fingers","Fingers",false), ("twins","Twins",false),
            ("creepyvirginia","Creepy Virginia",false), ("armsy","Armsy",true),
            ("demonboss","Demon Boss",true), ("bossmutant","Mutant Boss",true),
            ("demon","Demon",false), ("cannibal goldmask","Gold Mask",false),
            ("cannibal carl","Carl",false), ("cannibal billy","Billy",false),
            ("cannibal danny","Danny",false), ("cannibal andy","Andy",false),
            ("cannibal greg","Greg (effigies)",false), ("cannibal eddy","Eddy (spears)",false),
            ("cannibal lgor","Igor (charges)",false), ("cannibalnight","Night Cannibal",false),
            ("painted male","Painted Cannibal",false), ("femalecannibal angel","Angel",false),
            ("femalecannibal crystal","Crystal",false), ("femalecannibal destiny","Destiny",false),
            ("femalecannibal brandy","Brandy",false), ("femalecannibal Elise","Elise",false),
            ("male","Male Cannibal",false), ("female","Female Cannibal",false),
            ("family","Assorted Cannibals",false), ("heavy","Heavy Cannibal",false),
            ("fat","Red Fat Cannibal",false), ("malefat","Fat Male",false),
            ("femalefat","Fat Female",false), ("muddymale","Muddy Male",false),
            ("muddyfemale","Muddy Female",false), ("muddy","Muddy (grass pile)",false),
            ("fire","Fire Cannibal",false), ("holey","Holey",false),
            ("legsy","Legsy",false), ("slug","Sluggy",false),
            ("john2","John 2.0",false), ("mrpuffy","Mr. Puffy",false),
            ("misspuffy","Mrs. Puffy",false), ("puffybossmale","Puffy Boss Male",false),
            ("puffybossfemale","Puffy Boss Female",false), ("spotted male","Spotted Male",false),
            ("spotted female","Spotted Female",false), ("baby","Baby",false),
            ("frank","Frank",false),
        };

        static readonly (string Key, string Label, bool Hostile)[] Animals =
        {
            ("deer","Deer",false), ("moose","Moose",false), ("rabbit","Rabbit",false),
            ("squirrel","Squirrel",false), ("raccoon","Raccoon",false),
            ("shark","Shark",true), ("killerwhale","Orca",true),
            ("eagle","Eagle",false), ("seagull","Seagull",false),
            ("turtle","Turtle",false), ("landturtle","Tortoise",false),
            ("bat","Bat",false), ("duck","Duck",false), ("gull","Gull",false),
            ("skunk","Skunk",false), ("bluebird","Bluebird",false),
            ("hummingbird","Hummingbird",false),
        };

        static readonly string[] Seasons = { "Spring", "Summer", "Autumn", "Winter" };

        // Lazy-generated season icons, drawn on the same 48×48 anti-aliased
        // canvas as the section-header icons (Disc / Stroke / Poly / BuildIcon
        // in Widgets.cs) and using the same closed Theme.Icon* palette. Their
        // colours are baked in, so the chip draw no longer tints them.
        static Texture2D[] _seasonIcons;
        static Texture2D SeasonIcon(int i)
        {
            if (_seasonIcons == null)
            {
                _seasonIcons = new Texture2D[4];
                _seasonIcons[0] = BuildIcon(FlowerShape);
                _seasonIcons[1] = BuildIcon(SunShape);
                _seasonIcons[2] = BuildIcon(LeafShape);
                _seasonIcons[3] = BuildIcon(SnowShape);
            }
            return _seasonIcons[i];
        }

        /// <summary>Spring — five-petal bloom on a stem.</summary>
        static void FlowerShape(Color32[] p)
        {
            Stroke(p, 24f, 26f, 22f, 45f, 2.6f, Theme.IconMoss);
            Poly(p, new[] { 22f, 36f, 12f, 32f, 11f, 39f, 21f, 41f }, Theme.IconOlive);
            for (int k = 0; k < 5; k++)
            {
                float a = k * Mathf.PI * 2f / 5f - Mathf.PI / 2f;
                Disc(p, 24f + Mathf.Cos(a) * 11f, 20f + Mathf.Sin(a) * 11f,
                     7.5f, Theme.IconBone);
            }
            Disc(p, 24f, 20f, 6f, Theme.IconGold);
            Disc(p, 22f, 18f, 2.4f, Theme.IconAmber);
        }

        /// <summary>Summer — sun with alternating long and short rays.</summary>
        static void SunShape(Color32[] p)
        {
            for (int k = 0; k < 8; k++)
            {
                float a = k * Mathf.PI / 4f;
                float cs = Mathf.Cos(a), sn = Mathf.Sin(a);
                float len = (k % 2 == 0) ? 21f : 18f;
                Stroke(p, 24f + cs * 13f, 24f + sn * 13f,
                          24f + cs * len, 24f + sn * len, 3.4f, Theme.IconAmber);
            }
            Disc(p, 24f, 24f, 12f, Theme.IconGold);
            Disc(p, 20f, 20f, 4f, Lift(Theme.IconGold, 0.5f));
        }

        /// <summary>Autumn — falling leaf, rust fading to gold at the tip.</summary>
        static void LeafShape(Color32[] p)
        {
            Poly(p, new[] { 39f, 8f, 41f, 21f, 33f, 35f, 17f, 41f, 9f, 32f,
                            13f, 18f, 26f, 10f }, Theme.IconRust);
            Poly(p, new[] { 39f, 8f, 41f, 21f, 33f, 35f, 26f, 38f }, Theme.IconGold);
            Stroke(p, 38f, 9f, 13f, 40f, 2.2f, Theme.IconEmber);
            Stroke(p, 29f, 19f, 33f, 26f, 1.6f, Theme.IconEmber);
            Stroke(p, 21f, 28f, 25f, 35f, 1.6f, Theme.IconEmber);
        }

        /// <summary>Winter — six-armed snowflake with barbs.</summary>
        static void SnowShape(Color32[] p)
        {
            for (int arm = 0; arm < 6; arm++)
            {
                float a = arm * Mathf.PI / 3f;
                float cs = Mathf.Cos(a), sn = Mathf.Sin(a);
                Stroke(p, 24f, 24f, 24f + cs * 20f, 24f + sn * 20f, 2.8f,
                       Theme.IconSky);
                float bx = 24f + cs * 13f, by = 24f + sn * 13f;
                Stroke(p, bx, by, bx + (cs * 0.5f - sn * 0.866f) * 7f,
                                  by + (sn * 0.5f + cs * 0.866f) * 7f, 2.2f,
                       Theme.IconSteel);
                Stroke(p, bx, by, bx + (cs * 0.5f + sn * 0.866f) * 7f,
                                  by + (sn * 0.5f - cs * 0.866f) * 7f, 2.2f,
                       Theme.IconSteel);
            }
            Disc(p, 24f, 24f, 4.5f, Theme.IconBone);
        }

        // ── tab bodies ───────────────────────────────────────────────────
        void TabPlayer()
        {
            Lede("Vitals are held at ceiling while enabled. Needs a loaded save.");
            Group("Survival");
            Features.GodMode     = Switch("God Mode", Features.GodMode, true);
            Features.InfStamina  = Switch("Infinite Stamina", Features.InfStamina);
            Features.MaxStrength = Switch("Max Strength", Features.MaxStrength);
            Features.NoFallDamage = Switch("No Fall Damage", Features.NoFallDamage);
            Group("Needs");
            Features.NoHunger     = Switch("No Hunger", Features.NoHunger);
            Features.NoThirst     = Switch("No Thirst", Features.NoThirst);
            Features.NoCold       = Switch("No Cold", Features.NoCold);
            Features.AlwaysRested = Switch("Always Rested", Features.AlwaysRested);
            Features.InfLung      = Switch("Infinite Lung Capacity", Features.InfLung);

            Group("Game Cheats");
            SwitchRows(Actions.PlayerSwitches);

            Group("Actions");
            ActionRows(Actions.PlayerActions);

            Group("Values");
            ValueRows(Actions.PlayerValues, "pval");

            Group("Status Effects");
            float efW = ColW(2);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("STOP BURNING", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("StopBurning");
            GUILayout.Space(6);
            if (GUILayout.Button("GET CLEAN", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("GotClean");
            GUILayout.EndHorizontal();
            GUILayout.Space(4);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("ADRENALINE", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("AdrenalineRush");
            GUILayout.Space(6);
            if (GUILayout.Button("CLEAR SKUNK", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("ClearSkunkSmell");
            GUILayout.EndHorizontal();
            GUILayout.Space(4);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("GET MUDDY", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("GotMud");
            GUILayout.Space(6);
            if (GUILayout.Button("GET BLOODY", Theme.Btn, GUILayout.Height(26), GUILayout.Width(efW)))
                DirectGameApi.StatusEffect("GotBloody");
            GUILayout.EndHorizontal();
            GUILayout.Space(4);
            if (GUILayout.Button("POISON ME", Theme.BtnPrimary,
                                 GUILayout.Height(26)))
                DirectGameApi.StatusEffect("HitPoison");
        }


        void TabOnline()
        {
            Lede("Multiplayer administration. Kick and disconnect act on the session " +
                 "you are hosting.");

            Group("Roster");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("REFRESH", Theme.Btn, GUILayout.Height(24),
                                 GUILayout.Width(110)))
                _rosterDirty = true;
            GUILayout.Label(Roster.Status, Theme.Lede);
            GUILayout.EndHorizontal();
            GUILayout.Space(3);

            if (_rosterDirty)
            {
                Roster.Refresh();
                _rosterDirty = false;
            }

            for (int i = 0; i < Roster.Players.Count; i++)
            {
                var p = Roster.Players[i];
                GUILayout.BeginHorizontal(GUILayout.Height(24));

                var tagStyle = p.IsAdmin ? AdminTagStyle() : Theme.RowTag;
                string tag = p.IsLocal ? "YOU" : (p.IsAdmin ? "ADMIN" :
                    (p.IsAlive ? "ALIVE" : "DEAD"));
                if (GUILayout.Button("", Theme.RowStyle, GUILayout.Height(24)))
                    _rosterDirty = true;
                var r = GUILayoutUtility.GetLastRect();

                // steam avatar (or placeholder) at the left of the row
                var av = Avatars.Get(p.SteamId);
                if (av == null)
                {
                    Theme.Fill(new Rect(r.x + 3, r.y + 2, 20, 20), Theme.FieldBg);
                    Theme.Box(new Rect(r.x + 3, r.y + 2, 20, 20), Theme.Dead, 1f);
                }
                else
                {
                    GUI.DrawTexture(new Rect(r.x + 3, r.y + 2, 20, 20), av);
                    Theme.Box(new Rect(r.x + 3, r.y + 2, 20, 20), Theme.Dead, 1f);
                }
                GUI.Label(new Rect(r.x + 27, r.y, r.width - 34, r.height), p.Name,
                          Theme.RowStyle);
                var tagW = tagStyle.CalcSize(new GUIContent(tag)).x + 10f;
                float tagX = r.xMax - 58 - tagW;
                GUI.Label(new Rect(tagX, r.y, tagW, r.height), tag, tagStyle);

                if (p.IsLocal)
                {
                    GUILayout.Space(146);
                }
                else
                {
                    if (GUILayout.Button("TP", Theme.Btn, GUILayout.Width(36),
                                         GUILayout.Height(24)))
                        Roster.TeleportTo(i);
                    if (GUILayout.Button("BRING", Theme.Btn, GUILayout.Width(52),
                                         GUILayout.Height(24)))
                        Roster.Bring(i);
                    if (GUILayout.Button("KILL", Theme.BtnPrimary, GUILayout.Width(44),
                                         GUILayout.Height(24)))
                        Roster.Kill(i);
                    if (GUILayout.Button("REVIVE", Theme.Btn, GUILayout.Width(56),
                                         GUILayout.Height(24)))
                        Roster.Revive(i);
                }
                GUILayout.EndHorizontal();
            }

            if (Roster.Players.Count <= 1 && !_rosterDirty)
                GUILayout.Label("No remote players in the list yet — hosts see " +
                                "connected players here.", Theme.Lede);

            Group("Session");
            ActionRows(Actions.MultiplayerActions);
            Group("Targeted");
            ValueRows(Actions.MultiplayerValues, "mval");
            Group("Network Debug");
            SwitchRows(Actions.MultiplayerSwitches);
        }

        /// <summary>
        /// Mod preferences. Currently the Steam Web API key, which powers the
        /// roster avatars on the ONLINE and MAP tabs — it lives here rather
        /// than on ONLINE so the multiplayer view stays focused on players.
        /// </summary>
        void TabSettings()
        {
            Lede("Mod preferences. The Steam Web API key powers player avatars " +
                 "on the ONLINE and MAP tabs.");

            Group("Steam API Key");
            GUILayout.Label(
                "Paste your Steam Web API key to show player avatars. " +
                "Get one free at steamcommunity.com/dev/apikey",
                Theme.Lede);
            GUILayout.BeginHorizontal();
            _steamKey = HintField("steamkey", _steamKey,
                                  "Paste your 32-character Steam Web API key…");
            GUILayout.Space(6);
            if (GUILayout.Button("SAVE KEY", Theme.BtnPrimary,
                                 GUILayout.Width(100), GUILayout.Height(24)))
                SaveSteamKey();
            GUILayout.EndHorizontal();
            if (_keyStatus != null)
                GUILayout.Label(_keyStatus, KeyStatusStyle(_keyStatusOk));
            GUILayout.Space(6);

            Group("Menu Hotkey");
            Lede("Click REBIND, then press the key you want. Escape cancels, and " +
                 "the new key is saved to disk immediately.");

            GUILayout.BeginHorizontal(GUILayout.Height(26));
            GUILayout.Label("Open / close menu", Theme.DialLabel, GUILayout.Width(190));
            GUILayout.Label(Plugin.ToggleKeyGlyph, Theme.Kbd,
                            GUILayout.Width(64), GUILayout.Height(24));
            GUILayout.Space(RowGap);

            if (GUILayout.Button(_rebindArmed ? "PRESS A KEY…" : "REBIND",
                                 _rebindArmed ? Theme.BtnPrimary : Theme.Btn,
                                 GUILayout.Width(140), GUILayout.Height(24)))
            {
                _rebindArmed = !_rebindArmed;
                _rebindOk = false;
                _rebindStatus = _rebindArmed
                    ? "Listening — press any key, or Escape to cancel."
                    : null;
            }
            GUILayout.EndHorizontal();

            if (!string.IsNullOrEmpty(_rebindStatus))
                GUILayout.Label(_rebindStatus, KeyStatusStyle(_rebindOk));

            GUILayout.Space(6);

            Group("Appearance");
            Lede("Live preview — applies immediately and persists on exit.");
            Plugin.MenuOpacity = Dial("Menu Opacity", Plugin.MenuOpacity, 0.3f, 1f);
            Plugin.CornerRadius = Dial("Corner Radius", Plugin.CornerRadius,
                                       4f, 20f, "0");
            Group("Scrolling");
            Plugin.ScrollSensitivity = Dial("Scroll Sensitivity",
                                            Plugin.ScrollSensitivity, 0.25f, 3f);
        }

        /// <summary>
        /// SAVE KEY handler. Writes the config AND flushes it to disk right
        /// away (BepInEx otherwise only writes on exit), hot-reloads the key in
        /// Avatars, and reports the result inline under the field — success,
        /// cleared, or a warning when the text doesn't look like a Steam key
        /// (32 hex chars), which is the usual reason "nothing happens" when
        /// avatars never load.
        /// </summary>
        void SaveSteamKey()
        {
            string k = _steamKey.Trim();
            Plugin.SteamApiKey = k;
            Plugin.SaveConfig();
            Avatars.SetApiKey(k);
            _rosterDirty = true; // refresh roster so the new key is tried

            Features.LastResult = string.IsNullOrEmpty(k)
                ? "Steam key cleared — avatars disabled"
                : "Steam key saved — avatars will load";

            if (string.IsNullOrEmpty(k))
            {
                _keyStatusOk = false;
                _keyStatus = "Key cleared — avatars disabled until you save a key.";
            }
            else if (!LooksLikeSteamKey(k))
            {
                _keyStatusOk = false;
                _keyStatus = "Saved, but that doesn't look like a Steam key " +
                             "(32 hex characters) — avatars will likely fail " +
                             "to load.";
            }
            else
            {
                _keyStatusOk = true;
                _keyStatus = "Saved to com.stormfest.sonsoftheforestmenu.cfg — " +
                             "avatars will load in-world.";
            }
        }

        /// <summary>Steam Web API keys are always 32 uppercase hex characters.</summary>
        static bool LooksLikeSteamKey(string k)
        {
            if (k.Length != 32) return false;
            for (int i = 0; i < k.Length; i++)
            {
                char c = k[i];
                bool hex = (c >= '0' && c <= '9') ||
                           (c >= 'A' && c <= 'F') ||
                           (c >= 'a' && c <= 'f');
                if (!hex) return false;
            }
            return true;
        }

        void TabCombat()
        {
            Lede("Radius commands act on everything around you at the given distance.");

            Group("Weapons");
            Features.InfAmmo   = Switch("Infinite Ammo", Features.InfAmmo);
            Features.RapidFire = Switch("Rapid Fire", Features.RapidFire);
            if (Features.RapidFire)
                Features.FireDelay = Dial("Fire Delay", Features.FireDelay,
                                           0.02f, 0.5f, "0.00");

            Group("Combat Tuning");
            Features.AiPause = Switch("Pause AI Simulation", Features.AiPause, true);
            Features.DamageTakenMult =
                Dial("Damage Taken", Features.DamageTakenMult, 0f, 10f);

            Group("Enemies");
            bool g = DirectGameApi.Ghost;
            bool g2 = Switch("Ghost Player (enemies ignore you)", g);
            if (g2 != g) DirectGameApi.Ghost = g2;
            SwitchRows(Actions.CombatSwitches);

            GUILayout.Space(4);
            if (FullButton("Kill All Loaded Actors"))
                DirectGameApi.KillAllActors();

            Group("Area Effects");
            ValueRows(Actions.RadiusValues, "rad");

            Group("Enemy Tuning");
            ValueRows(Actions.AiValues, "aival");

            Group("Cleanup");
            ActionRows(Actions.CombatActions);
        }

        /// <summary>Building, season, time and weather. Game-start rules live on GAME SETUP.</summary>
        void TabWorld()
        {
            Lede("On a dedicated server the host stays authoritative — these apply locally.");
            Group("Construction");
            Features.InstantBuild   = Switch("Instant Build", Features.InstantBuild);
            Features.InfiniteBuild  = Switch("Infinite Build (free ingredients)", Features.InfiniteBuild);
            Features.InfiniteLogs   = Switch("Infinite Held Items / Logs", Features.InfiniteLogs);
            Features.InfRope        = Switch("Infinite Rope Length", Features.InfRope);
            if (Features.InfRope)
                Features.RopeLength = Dial("Rope Length", Features.RopeLength, 50f, 1000f, "0");

            Group("Season");
            GUILayout.BeginHorizontal();
            for (int i = 0; i < Seasons.Length; i++)
            {
                GUILayout.Space(2);
                bool on = _seasonIdx == i;
                var chipStyle = on ? Theme.ChipOn : Theme.ChipOff;
                // 20px container, icon offset +3px — same as section-header icons.
                // No tint: each season icon bakes its own colours (spring bone
                // and gold, summer gold, autumn rust, winter sky).
                var iconRect = GUILayoutUtility.GetRect(22f, 20f,
                    GUILayout.Width(IconS + 6), GUILayout.Height(20f));
                var prev = GUI.color;
                GUI.color = Color.white;
                GUI.DrawTexture(new Rect(iconRect.x, iconRect.y + 3, IconS, IconS), SeasonIcon(i));
                GUI.color = prev;
                if (GUILayout.Button(Seasons[i].ToUpper(), chipStyle,
                                     GUILayout.Height(28), GUILayout.Width(72)))
                {
                    _seasonIdx = i;
                    Features.SetSeason(Seasons[i]);
                }
            }
            GUILayout.EndHorizontal();

            Group("World Cheats");
            SwitchRows(Actions.WorldSwitches);

            Group("Time & Weather");
            ValueRows(Actions.WorldValues, "world");

            Group("World Actions");
            ActionRows(Actions.WorldActions);

            GUILayout.Space(4);
            if (FullButton("Clear All Structures", Theme.BtnPrimary))
                DirectGameApi.ClearAllStructures();
        }

        /// <summary>
        /// The custom-game options normally chosen at world creation, applied
        /// live through setGameSetupSetting. Split off WORLD because these are
        /// rules for the whole save rather than things you do to it right now.
        /// </summary>
        void TabGameSetup()
        {
            Lede("The options you normally pick when creating a world, applied live.");
            Group("Game Setup — World");
            Lede("The custom-game options you normally pick at world creation, " +
                 "applied live via setGameSetupSetting.");
            SetupRows(Wiki.GameSetupWorld, "gsw");

            Group("Game Setup — Survival");
            SetupRows(Wiki.GameSetupSurvival, "gss");
        }


        void TabCheats()
        {
            Lede("The game's own cheat flags, read back live from Sons.Settings.Cheats " +
                 "— these persist independently of the console switches.");

            Group("Engine Cheats");
            bool a = EngineCheats.CheatGod;
            bool b = Switch("God Mode (engine flag)", a, true);
            if (b != a) EngineCheats.CheatGod = b;

            a = EngineCheats.CheatEnergy;
            b = Switch("Infinite Energy", a);
            if (b != a) EngineCheats.CheatEnergy = b;

            a = EngineCheats.CheatNoSurvival;
            b = Switch("No Survival Drain", a);
            if (b != a) EngineCheats.CheatNoSurvival = b;

            a = EngineCheats.CheatOneHitTrees;
            b = Switch("One-Hit Tree Cutting", a);
            if (b != a) EngineCheats.CheatOneHitTrees = b;

            GUILayout.Space(6);
            if (FullButton("Reset All Cheat Flags", Theme.Btn))
                EngineCheats.ResetCheats();

            Group("Water");
            if (FullButton("Toggle Freeze Ocean", Theme.Btn))
                EngineCheats.ToggleFreezeWater();

            Group("Armour");
            GUILayout.Label("Status: " + EngineCheats.ArmourStatus, Theme.Lede);
            if (FullButton("Refresh Armour Status", Theme.Btn))
                EngineCheats.RefreshArmour();

            Group("Achievements");
            GUILayout.Label(EngineCheats.AchievementTotal > 0
                ? EngineCheats.AchievementUnlocked + " of " + EngineCheats.AchievementTotal + " unlocked"
                : "Not loaded yet — refresh to read them.", Theme.Lede);
            float achGap = 10f;
            float achW = ColW(3, achGap);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button("REFRESH", Theme.Btn, GUILayout.Height(26), GUILayout.Width(achW)))
                EngineCheats.RefreshAchievements();
            GUILayout.Space(achGap);
            if (GUILayout.Button("UNLOCK ALL", Theme.BtnPrimary, GUILayout.Height(26), GUILayout.Width(achW)))
                EngineCheats.UnlockAllAchievements();
            GUILayout.Space(achGap);
            if (GUILayout.Button("RESET ALL", Theme.BtnPrimary, GUILayout.Height(26), GUILayout.Width(achW)))
                EngineCheats.ResetAllAchievements();
            GUILayout.EndHorizontal();

            if (EngineCheats.AchievementNames.Count > 0)
            {
                GUILayout.Space(4);
                int max = Mathf.Min(EngineCheats.AchievementNames.Count, 40);
                for (int i = 0; i < max; i++)
                    GUILayout.Label(EngineCheats.AchievementNames[i], Theme.RowId);
                if (EngineCheats.AchievementNames.Count > max)
                    GUILayout.Label("… and " + (EngineCheats.AchievementNames.Count - max) + " more",
                                    Theme.Build);
            }

            Group("World Simulation");
            int n = EngineCheats.SimActorCount();
            GUILayout.Label(n >= 0
                ? "Simulated actors: " + n
                : "World simulation not available.", Theme.Lede);
        }

        void TabGear()
        {
            Lede("Tuning for equipment and vehicles. Each needs the item to exist " +
                 "in the loaded world.");

            Group("Hang Glider");
            DirectGameApi.GliderForward  = Dial("Forward Force",  DirectGameApi.GliderForward, 1f, 80f, "0.0");
            DirectGameApi.GliderPitchUp  = Dial("Pitch Up Force", DirectGameApi.GliderPitchUp, 0f, 40f, "0.0");
            DirectGameApi.GliderDown     = Dial("Down Pitch",     DirectGameApi.GliderDown,    0f, 40f, "0.0");
            GearApply("Apply Glider", () => DirectGameApi.ApplyGlider());

            Group("Knight V");
            DirectGameApi.KnightVSpeed = Dial("Max Speed", DirectGameApi.KnightVSpeed, 5f, 120f, "0.0");
            GearApply("Apply Knight V", () => DirectGameApi.ApplyKnightV());

            Group("Flashlight");
            DirectGameApi.FlashlightIntensity = Dial("Intensity",  DirectGameApi.FlashlightIntensity, 0f, 30f, "0.0");
            DirectGameApi.FlashlightDrain     = Dial("Drain Rate", DirectGameApi.FlashlightDrain,     0f, 5f,  "0.00");
            GearApply("Apply Flashlight", () => DirectGameApi.ApplyFlashlight());

            Group("Rebreather");
            DirectGameApi.RebreatherAir   = Dial("Air Consumption", DirectGameApi.RebreatherAir,   0f, 5f,  "0.00");
            DirectGameApi.RebreatherLight = Dial("Light Intensity", DirectGameApi.RebreatherLight, 0f, 30f, "0.0");
            GearApply("Apply Rebreather", () => DirectGameApi.ApplyRebreather());
        }

        /// <summary>
        /// Everything drawn over the world: actor ESP, item ESP, the radar, and
        /// the game's own debug overlays. DISPLAY used to be a separate page for
        /// the overlay switches alone, which put two halves of one idea in two
        /// places.
        /// </summary>
        void TabVision()
        {
            Lede("Overlays drawn on top of the world. Range is shared by actor and item ESP.");
            Group("Actors");
            Esp.Enabled  = Switch("Enable Actor ESP", Esp.Enabled, true);
            Esp.Enemies  = Switch("Enemies", Esp.Enemies);
            Esp.Animals  = Switch("Animals", Esp.Animals);
            Esp.Friendly = Switch("Friendly", Esp.Friendly);
            Esp.ShowDead = Switch("Show Dead", Esp.ShowDead);

            Group("Item ESP");
            ItemEsp.Enabled = Switch("Enable Item ESP", ItemEsp.Enabled, true);
            ItemEsp.ShowItems       = Switch("Items", ItemEsp.ShowItems);
            ItemEsp.ShowContainers  = Switch("Containers (crates / storage)", ItemEsp.ShowContainers);
            ItemEsp.ShowCollectibles = Switch("Collectibles (bags / artifacts)", ItemEsp.ShowCollectibles);
            ItemEsp.ShowWaypoints   = Switch("Waypoints (GPS)", ItemEsp.ShowWaypoints);

            Group("Range & Radar");
            Esp.MaxDistance = Dial("Max Distance", Esp.MaxDistance, 25f, 600f, "0");
            ItemEsp.Radar = Switch("Radar", ItemEsp.Radar);
            if (ItemEsp.Radar)
                ItemEsp.RadarRange = Dial("Radar Range", ItemEsp.RadarRange, 25f, 400f, "0");

            GUILayout.Label("Tracking " + Esp.LastDrawn + " actor(s), " +
                            ItemEsp.LastDrawn + " item(s).", Theme.Lede);

            Group("Overlays");
            SwitchRows(Actions.DisplaySwitches);
            Group("Actions");
            ActionRows(Actions.DisplayActions);
            Group("Values");
            ValueRows(Actions.DisplayValues, "dval");
        }


        /// <summary>Speed, jump, swim and free flight. Teleport moved to its own page.</summary>
        void TabMovement()
        {
            Lede("Multipliers apply live. Undo restores the values captured on load.");
            Group("On Foot");
            Features.RunSpeed = Dial("Run Speed", Features.RunSpeed, 0.5f, 40f);
            Features.JumpMult = Dial("Jump Multiplier", Features.JumpMult, 0.5f, 12f);
            Features.SwimSpeed = Dial("Swim Speed", Features.SwimSpeed, 0.5f, 30f);

            Group("Game Movement Cheats");
            SwitchRows(Actions.MovementSwitches);

            Group("Flight");
            Features.Fly = Switch("Fly  (WASD / Space / C)", Features.Fly);
            Features.FlySpeed = Dial("Fly Speed", Features.FlySpeed, 2f, 60f, "0.0");

            Group("Actions");
            ActionRows(Actions.MovementActions);

            GUILayout.Space(6);
            if (GUILayout.Button("UNDO ALL", Theme.Btn, GUILayout.Height(26)))
            {
                Features.RestoreBaseline();
                Features.LastResult = "Movement restored";
            }
        }

        /// <summary>
        /// Everything about getting somewhere: the island map, saved spots and
        /// the wiki's named locations. The map itself is drawn by
        /// <see cref="TabTeleportMap"/> outside the scroll view — it handles its
        /// own clicks and cannot live inside one.
        /// </summary>
        void TabTeleport()
        {
            Group("Teleport & Camera");
            ValueRows(Actions.MovementValues, "mvval");

            Group("Saved Spots");
            GUILayout.BeginHorizontal();
            _spotName = HintField("spotname", _spotName, "Name this spot…",
                                  GUILayout.Width(170), GUILayout.Height(24));
            GUILayout.Space(6);
            if (GUILayout.Button("SAVE HERE", Theme.Btn,
                                 GUILayout.Width(110), GUILayout.Height(24)))
                Teleport.SaveCurrent(_spotName.Trim());
            GUILayout.EndHorizontal();
            GUILayout.Space(3);

            // Mark-and-sweep delete: record the index during the row loop, then
            // remove after it — removing mid-loop would shift every later index.
            int deleteSpot = -1;
            for (int i = 0; i < Teleport.Spots.Count && i < 30; i++)
            {
                GUILayout.BeginHorizontal(GUILayout.Height(22));
                if (GUILayout.Button("TP", Theme.Btn, GUILayout.Width(40),
                                     GUILayout.Height(22)))
                    Teleport.TeleportTo(i);
                if (GUILayout.Button("✕", Theme.BtnPrimary, GUILayout.Width(28),
                                     GUILayout.Height(22)))
                    deleteSpot = i;
                var r = GUILayoutUtility.GetLastRect();
                GUI.Label(new Rect(r.x + 76, r.y, r.width - 80, r.height),
                          Teleport.Spots[i].Name, Theme.RowStyle);
                GUILayout.EndHorizontal();
            }
            if (deleteSpot >= 0) Teleport.RemoveAt(deleteSpot);
            if (Teleport.Spots.Count == 0)
                GUILayout.Label("No spots saved yet — name one above and SAVE HERE.",
                                Theme.Lede);

            Group("Named Locations (wiki)");
            Lede("One-click goto targets — bunkers, caves, crash sites and " +
                 "community-found loot spots.");
            GUILayout.BeginHorizontal();
            if (GUILayout.Button((_locOpen ? "▴ " : "▾ ") +
                                 (_locSel >= 0
                                     ? Wiki.Locations[_locSel].Label
                                     : "SELECT A LOCATION (" + Wiki.Locations.Length + ")"),
                                 Theme.Btn, GUILayout.Height(26),
                                 GUILayout.ExpandWidth(true)))
                _locOpen = !_locOpen;
            GUILayout.Space(RowGap);

            if (GUILayout.Button("TP", Theme.BtnPrimary,
                                 GUILayout.Width(44), GUILayout.Height(26)))
            {
                if (_locSel >= 0)
                    Features.RunCmd("goto " + Wiki.Locations[_locSel].Target);
            }
            GUILayout.EndHorizontal();

            if (_locOpen)
            {
                // Height comes from the pane, not a fixed row count.
                //
                // This used to reserve a flat 15 rows (330px). Once TELEPORT
                // gained the map the content viewport dropped to 123–258px
                // depending on panel size, so the list overflowed at every size
                // and only a sliver was ever visible. Sizing to the viewport
                // keeps the whole list on screen and lets the wheel do the rest.
                const float rowH = 22f;
                const int maxRows = 15;
                const int minRows = 4;
                const float keepVisible = 56f;   // page context left around it

                int fits = Mathf.FloorToInt((_contentViewportH - keepVisible) / rowH);
                int rows = Mathf.Clamp(fits, minRows,
                                       Mathf.Min(maxRows, Wiki.Locations.Length));

                float boxH = rowH * rows;
                var box = GUILayoutUtility.GetRect(0f, boxH,
                                                   GUILayout.ExpandWidth(true));

                // Publish the list's position in pane coordinates so DrawPane
                // knows to leave the wheel alone while the cursor is over it.
                //
                // Guarded against degenerate rects: GUILayoutUtility.GetRect
                // returns a placeholder during Layout passes, and writing that
                // through left a zero-size rect behind, so the containment test
                // in DrawPane never matched and the list could not be scrolled.
                if (box.width > 1f && box.height > 1f)
                {
                    _locBoxInPane = new Rect(PAD + box.x,
                                             _contentViewportTop + box.y - _scroll.y,
                                             box.width, box.height);
                }

                float totalH = Wiki.Locations.Length * rowH;
                float max = Mathf.Max(0f, totalH - boxH);

                // The list scrolls itself. Doing it here rather than in DrawPane
                // means `box` and the cursor are in the same coordinate space,
                // so the hit test is exact instead of a reconstruction.
                Event wheel = Event.current;
                if (wheel.type == EventType.ScrollWheel && box.Contains(wheel.mousePosition))
                {
                    _locScroll.y += wheel.delta.y * 10f * Plugin.ScrollSensitivity;
                    wheel.Use();
                }

                _locScroll.y = Mathf.Clamp(_locScroll.y, 0f, max);

                Theme.Fill(box, Theme.Ink);
                Theme.Box(box, Theme.Line, 1f);

                int first = (int)(_locScroll.y / rowH);
                GUI.BeginClip(box);
                for (int r = first; r < Wiki.Locations.Length; r++)
                {
                    float y = r * rowH - _locScroll.y;
                    if (y > boxH) break;
                    bool picked = r == _locSel;
                    // Solid hover/pick strip, white text on dark background
                    var label = (picked ? "● " : "   ") + Wiki.Locations[r].Label;
                    if (GUI.Button(new Rect(0, y, box.width, rowH),
                                   label, Theme.DropdownRow))
                    {
                        _locSel = r;
                        _locOpen = false;
                        Features.RunCmd("goto " + Wiki.Locations[r].Target);
                    }
                    if (picked)
                        Theme.Fill(new Rect(0, y, box.width, rowH), Theme.RustWash);
                }
                GUI.EndClip();
                GUILayout.Space(4);
            }
        }


        void TabSpawn()
        {
            Lede("Spawns route through the game's debug console and land at your feet.");

            Group("Items");
            GUILayout.BeginHorizontal();
            GUILayout.Label("ID", Theme.Build, GUILayout.Width(18));
            _itemId = GUILayout.TextField(_itemId, Theme.Field, GUILayout.Width(70));
            GUILayout.Space(8);
            GUILayout.Label("QTY", Theme.Build, GUILayout.Width(28));
            _itemQty = GUILayout.TextField(_itemQty, Theme.Field, GUILayout.Width(50));
            GUILayout.Space(8);
            if (GUILayout.Button("ADD", Theme.BtnPrimary, GUILayout.Width(70), GUILayout.Height(24)))
            {
                int id, qty;
                if (int.TryParse(_itemId, out id))
                {
                    if (!int.TryParse(_itemQty, out qty)) qty = 1;
                    Features.SpawnItem(id, qty);
                }
                else Features.LastResult = "Item ID must be a number";
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(4);
            ActionRows(Actions.ItemActions);
            ValueRows(Actions.ItemValues, "ival");

            GUILayout.Space(6);
            GUILayout.BeginHorizontal();
            GUILayout.Label("SEARCH", Theme.Build, GUILayout.Width(50));
            _search = HintField("itemsearch", _search, "Search items…");
            GUILayout.EndHorizontal();
            DrawItemList();

            Group("Companions & Story");
            SpawnList(2);

            Group("Mutants & Cannibals");
            SpawnList(0);

            Group("Animals");
            SpawnList(1);

            Group("Prefabs (Bolt)");
            Lede("Props spawned through the game's Bolt prefab table — " +
                 "spawns a few metres in front of you.");
            float pfW = ColW(2);
            for (int i = 0; i < Scene.Prefabs.Length; i += 2)
            {
                GUILayout.BeginHorizontal();
                for (int k = i; k < i + 2 && k < Scene.Prefabs.Length; k++)
                {
                    if (GUILayout.Button(Scene.Prefabs[k].Label.ToUpper(),
                                         Theme.Btn, GUILayout.Height(26),
                                         GUILayout.Width(pfW)))
                        Scene.SpawnPrefab(k);
                    if (k < i + 1 && k < Scene.Prefabs.Length - 1)
                        GUILayout.Space(6);
                }
                GUILayout.EndHorizontal();
                GUILayout.Space(4);
            }

            Group("Cutscenes");
            Lede("Played through CutsceneManager — these are the wiki-listed " +
                 "ones that work. Any other cutscene name can be typed below.");
            // Rounded buttons laid edge to edge lose their corners against each
            // other and read as one continuous bar, so every horizontal run is
            // separated by RowGap — the same gap the paired action rows use.
            GUILayout.BeginHorizontal();
            for (int i = 0; i < Scene.Cutscenes.Length; i++)
            {
                if (i > 0) GUILayout.Space(RowGap);

                if (GUILayout.Button(Scene.Cutscenes[i].Label.ToUpper(),
                                     Theme.Btn, GUILayout.Height(24)))
                    Scene.PlayCutscene(Scene.Cutscenes[i].Name);
            }
            GUILayout.EndHorizontal();

            GUILayout.Space(RowGap);

            GUILayout.BeginHorizontal();
            _cutsceneName = HintField("cutname", _cutsceneName, "Cutscene name…",
                                      GUILayout.Width(180));
            GUILayout.Space(RowGap);

            if (GUILayout.Button("PLAY NAME", Theme.BtnPrimary,
                                 GUILayout.Height(24)))
                Scene.PlayCutscene(_cutsceneName.Trim());
            GUILayout.Space(RowGap);

            if (GUILayout.Button("SKIP", Theme.Btn, GUILayout.Height(24)))
                Scene.SkipCutscene();
            GUILayout.EndHorizontal();

            string active = Scene.ActiveCutscene();
            if (active != null)
                GUILayout.Label(active, Theme.Lede);
        }

        void TabConsole()
        {
            Lede("Every command the game's own debug console exposes — " +
                 Commands.All.Length + " of them. Type one, or pick from the list.");

            Group("Common (wiki)");
            // Four-column equal-width grid with consistent gaps between
            // every button so rounded corners never crowd each other.
            float cmnGap = 10f;
            float cmnW = ColW(4, cmnGap);
            string[] rowA = { "ADD ALL ITEMS", "CAVE LIGHT", "INVISIBLE", "CREEPY VILLAGE" };
            string[] rowB = { "KILL RADIUS 50", "SUPER JUMP", "SPEEDY RUN", "ENERGY HACK" };
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(rowA[0], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("addAllItems");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowA[1], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("caveLight on");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowA[2], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("invisible on");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowA[3], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("creepyVillage");
            GUILayout.EndHorizontal();
            GUILayout.Space(6);
            GUILayout.BeginHorizontal();
            if (GUILayout.Button(rowB[0], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("killRadius 50");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowB[1], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("superJump on");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowB[2], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("speedyrun on");
            GUILayout.Space(cmnGap);
            if (GUILayout.Button(rowB[3], Theme.Btn, GUILayout.Width(cmnW), GUILayout.Height(26)))
                Features.RunCmd("energyhack on");
            GUILayout.EndHorizontal();

            Group("Run");
            GUILayout.BeginHorizontal();
            GUI.SetNextControlName("cmdline");
            _cmdLine = HintField("cmdline", _cmdLine, "Type a console command…");
            GUILayout.Space(6);
            bool run = GUILayout.Button("RUN", Theme.BtnPrimary,
                                        GUILayout.Width(70), GUILayout.Height(24));
            GUILayout.EndHorizontal();

            // live description of the typed command, from the wiki
            string desc;
            if (_cmdLine.Trim().Length > 0 &&
                Wiki.Desc.TryGetValue(_cmdLine.Trim().ToLowerInvariant(), out desc))
                GUILayout.Label(desc, Theme.Lede);

            // Enter also runs, when focus is in the command box
            if (!run && Event.current.type == EventType.KeyDown &&
                (Event.current.keyCode == KeyCode.Return ||
                 Event.current.keyCode == KeyCode.KeypadEnter) &&
                GUI.GetNameOfFocusedControl() == "cmdline")
            {
                run = true;
                Event.current.Use();
            }

            if (run && _cmdLine.Trim().Length > 0)
            {
                string c = _cmdLine.Trim();
                Features.RunCmd(c);
                _history.Insert(0, c);
                if (_history.Count > 12) _history.RemoveAt(_history.Count - 1);
                _cmdLine = "";
            }

            if (_history.Count > 0)
            {
                Group("Recent");
                for (int i = 0; i < _history.Count; i++)
                {
                    GUILayout.BeginHorizontal(GUILayout.Height(20));
                    if (GUILayout.Button("", Theme.RowStyle, GUILayout.Height(20)))
                        _cmdLine = _history[i];
                    var r = GUILayoutUtility.GetLastRect();
                    GUI.Label(new Rect(r.x + 8, r.y, r.width - 60, r.height),
                              _history[i], Theme.RowId);
                    GUILayout.EndHorizontal();
                }
            }

            Group("All Commands");
            GUILayout.BeginHorizontal();
            GUILayout.Label("SEARCH", Theme.Build, GUILayout.Width(50));
            _cmdSearch = HintField("cmdsearch", _cmdSearch, "Search commands…");
            GUILayout.EndHorizontal();
            GUILayout.Space(4);

            string q = _cmdSearch.Trim().ToLowerInvariant();
            int shown = 0;
            for (int i = 0; i < Commands.All.Length && shown < 60; i++)
            {
                string c = Commands.All[i];
                if (q.Length > 0 &&
                    Commands.Lower[i].IndexOf(q, StringComparison.Ordinal) < 0)
                    continue;

                GUILayout.BeginHorizontal(GUILayout.Height(20));
                if (GUILayout.Button("", Theme.RowStyle, GUILayout.Height(20)))
                    _cmdLine = c;
                var r = GUILayoutUtility.GetLastRect();
                GUI.Label(new Rect(r.x + 8, r.y, r.width - 70, r.height), c, Theme.RowStyle);
                GUILayout.EndHorizontal();
                shown++;

                if (shown == 1 && q.Length > 0)
                {
                    string first;
                    if (Wiki.Desc.TryGetValue(c.ToLowerInvariant(), out first))
                        GUILayout.Label(first, Theme.Lede);
                }
            }

            if (shown == 0)
                GUILayout.Label("No command matches \"" + _cmdSearch + "\".", Theme.Lede);
            else if (shown >= 60)
                GUILayout.Label("Showing first 60 — refine the search.", Theme.Build);
        }

        // ── spawn list / item list renderers ─────────────────────────────
        static int ParseQty(string s)
        {
            int q;
            return int.TryParse(s, out q) && q > 0 ? q : 1;
        }

        void DrawItemList()
        {
            var items = Game.Items;
            if (items == null)
            {
                GUILayout.Label("Item database is empty — load a save to populate it.",
                                Theme.Lede);
                return;
            }

            int shown = 0;
            int total;
            try { total = items.Count; } catch { return; } // db torn down — show nothing
            string q = _search.Trim().ToLowerInvariant();

            for (int i = 0; i < total && shown < 40; i++)
            {
                string name; int id;
                try
                {
                    var d = items[i];
                    if (d == null) continue;
                    name = d._name;
                    id = d._id;
                }
                catch { continue; } // one item torn down mid-list — skip it
                if (string.IsNullOrEmpty(name)) continue;
                if (q.Length > 0 &&
                    name.ToLowerInvariant().IndexOf(q, StringComparison.Ordinal) < 0 &&
                    id.ToString().IndexOf(q, StringComparison.Ordinal) < 0)
                    continue;

                GUILayout.BeginHorizontal(GUILayout.Height(22));
                if (GUILayout.Button("", Theme.RowStyle, GUILayout.Height(22)))
                    _itemId = id.ToString();
                var r = GUILayoutUtility.GetLastRect();
                GUI.Label(new Rect(r.x + 8, r.y, 46, r.height), id.ToString(), Theme.RowId);
                GUI.Label(new Rect(r.x + 58, r.y, r.width - 70, r.height), name, Theme.RowStyle);
                GUILayout.EndHorizontal();
                shown++;
            }

            if (shown == 0)
                GUILayout.Label("No item matches \"" + _search + "\".", Theme.Lede);
            else if (shown >= 40)
                GUILayout.Label("Showing first 40 matches — refine the search.", Theme.Build);
        }

        /// <summary>
        /// Selectable spawn list for one roster: 0 = mutants/cannibals,
        /// 1 = animals, 2 = companions. Deliberately takes a plain int and
        /// touches fields directly — Il2CppInterop cannot marshal
        /// Func/Action/ref parameters on an injected MonoBehaviour, and warns
        /// at registration if it sees them.
        /// </summary>
        void SpawnList(int which)
        {
            int count = which == 0 ? Mutants.Length : which == 1 ? Animals.Length : Companions.Length;
            int selected = which == 0 ? _selMutant : which == 1 ? _selAnimal : _selCompanion;
            string qty = which == 0 ? _mutQty : which == 1 ? _aniQty : _compQty;

            GUILayout.BeginHorizontal();
            GUILayout.Label("COUNT", Theme.Build, GUILayout.Width(44));
            qty = GUILayout.TextField(qty, Theme.Field, GUILayout.Width(46));
            GUILayout.Space(8);
            bool go = GUILayout.Button("SPAWN SELECTED", Theme.BtnPrimary,
                                       GUILayout.Width(160), GUILayout.Height(24));
            GUILayout.EndHorizontal();
            GUILayout.Space(4);

            for (int i = 0; i < count; i++)
            {
                GUILayout.BeginHorizontal(GUILayout.Height(22));
                bool sel = selected == i;
                var st = sel ? Theme.SwitchOn : Theme.RowStyle;
                if (GUILayout.Button("", st, GUILayout.Height(22))) selected = i;
                var r = GUILayoutUtility.GetLastRect();
                if (sel) Theme.Fill(new Rect(r.x, r.y, 2, r.height), Theme.RustBright);
                string label = which == 0 ? Mutants[i].Label
                             : which == 1 ? Animals[i].Label : Companions[i].Label;
                bool boss = which == 0 ? Mutants[i].Boss
                          : which == 1 ? Animals[i].Hostile : Companions[i].Boss;
                GUI.Label(new Rect(r.x + 10, r.y, r.width - 80, r.height), label, Theme.RowStyle);
                if (boss)
                {
                    GUI.Label(new Rect(r.xMax - 60, r.y, 54, r.height), "BOSS",
                              BossTagStyle());
                }
                GUILayout.EndHorizontal();
            }

            // write the (possibly changed) selection and quantity back
            if (which == 0)      { _selMutant = selected; _mutQty = qty; }
            else if (which == 1) { _selAnimal = selected; _aniQty = qty; }
            else                 { _selCompanion = selected; _compQty = qty; }

            if (go)
            {
                if (selected >= 0 && selected < count)
                {
                    string key = which == 0 ? Mutants[selected].Key
                               : which == 1 ? Animals[selected].Key : Companions[selected].Key;
                    Features.SpawnCharacter(key, ParseQty(qty));
                }
                else Features.LastResult = "Select a target first";
            }
        }
    }
}

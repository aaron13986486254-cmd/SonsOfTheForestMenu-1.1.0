// ═══════════════════════════════════════════════════════════════════════════
//  Cyberfox1337xAttribute.cs · authorship marker carried by every type
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Authorship marker. Every type in this assembly carries one.
///
/// <para><b>Why an attribute and not a name prefix.</b> The handle belongs in
/// the structure, not in the identifiers. Prefixing type names would put it in
/// every call site — <c>Cyberfox1337xSafe.Get(...)</c> — which reads as branding
/// rather than authorship and makes the code worse everywhere it is used. An
/// attribute is real structure: it is compiled into assembly metadata, it is
/// visible to reflection and to any analyser, it greps in one pass, and it costs
/// nothing at runtime.</para>
///
/// <para><b>Authorship is unconditional.</b> Every type here was written for
/// this plugin, so every type is marked — including the ones whose <i>names</i>
/// are dictated from outside. Authorship and naming freedom are two different
/// facts, and conflating them would mean leaving the Harmony patches and the
/// injected MonoBehaviour looking unauthored when they are not.</para>
///
/// <para><b><see cref="Bound"/> records the constraint.</b> Where a type's
/// name, shape or member names are fixed by something external — a Unity
/// message, a Harmony target, IL2CPP injection, a BepInEx config key, a
/// serialised file layout — that is stated on the marker. Read it as: we wrote
/// this, and here is the part of it we are not free to rename.</para>
///
/// <code>
/// [Cyberfox1337x("guarded interop seam")]
/// [Cyberfox1337x("saved spots", Bound = "JSON keys in sonsofthedead_spots.json")]
/// [Cyberfox1337x(Bound = "Harmony: Prefix matched by name")]
/// </code>
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct |
                AttributeTargets.Enum | AttributeTargets.Interface,
                AllowMultiple = false, Inherited = false)]
[Cyberfox1337x]
internal sealed class Cyberfox1337xAttribute : Attribute
{
    // Members are public rather than internal because C# requires a named
    // attribute argument to be a public, non-static, read-write property or
    // field (CS0617). The attribute class itself stays internal, so this
    // widens nothing outside the assembly.

    /// <summary>
    /// Author handle. Aliases <see cref="Signature.Author"/> rather than
    /// repeating the literal, so the handle is defined in exactly one place.
    /// </summary>
    public const string Handle = Signature.Author;

    /// <summary>
    /// One line on the type's role, for when the class name alone does not
    /// place it in the architecture. Optional, passed positionally.
    /// </summary>
    public string Role { get; }

    /// <summary>
    /// What fixes this type's naming, when something does. Null means the type
    /// is ours end to end and may be renamed freely. Set as a named argument.
    /// </summary>
    public string Bound { get; set; }

    internal Cyberfox1337xAttribute(string role = null) => Role = role;

    /// <summary>Author, role and constraint in one line, for diagnostics.</summary>
    public override string ToString()
    {
        string described = Role is null ? Handle : $"{Handle} · {Role}";
        return Bound is null ? described : $"{described} · bound: {Bound}";
    }
}

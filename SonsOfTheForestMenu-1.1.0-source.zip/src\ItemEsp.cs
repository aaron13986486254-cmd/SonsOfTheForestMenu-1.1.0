// ═══════════════════════════════════════════════════════════════════════════
//  ItemEsp.cs · item, container and waypoint ESP with radar
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using UnityEngine;
using HarmonyLib;
using Sons.Gameplay;
using Sons.Gameplay.Artifact;
using Sons.Gameplay.GPS;
using Sons.Inventory;
using Sons.Items.Core;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// World-item ESP: pickups, loot crates, storage, artifacts and GPS
    /// waypoints, plus a radar overlay. Mirrors the reference menu's behaviour:
    /// a registry keyed by instance id that items join when they enable and
    /// leave when they are collected / taken / destroyed, so labels do not
    /// flicker and collected items vanish immediately.
    ///
    /// All game members were verified against global-metadata.dat before
    /// writing (see the check.py run in the build notes).
    /// </summary>
    [Cyberfox1337x("item ESP")]
    internal static class ItemEsp
    {
        public static bool Enabled, ShowItems, ShowContainers, ShowCollectibles,
                           ShowWaypoints, ShowDead, Radar;
        public static float RadarRange = 150f;
        public static int LastDrawn;

        // ── registry ─────────────────────────────────────────────────────
        struct Entry
        {
            public Vector3 Pos;
            public bool Collected;
        }

        static readonly HashSet<PickUp> _pickups = new HashSet<PickUp>();
        static readonly HashSet<DroppedInventoryItemsPickup> _bags =
            new HashSet<DroppedInventoryItemsPickup>();
        static readonly HashSet<ContainerItemSpawner> _crates =
            new HashSet<ContainerItemSpawner>();
        static readonly HashSet<InWorldAutoStorage> _autoStorage =
            new HashSet<InWorldAutoStorage>();
        static readonly HashSet<StructureStorage> _storage =
            new HashSet<StructureStorage>();
        static readonly HashSet<ArtifactStructure> _artifacts =
            new HashSet<ArtifactStructure>();
        static readonly HashSet<GPSLocator> _gps = new HashSet<GPSLocator>();

        static readonly Dictionary<int, Entry> _entries =
            new Dictionary<int, Entry>();
        static readonly Dictionary<int, string> _names =
            new Dictionary<int, string>();

        static bool _bootstrapped;
        static float _nextScan;

        static int Id(Component c) => c != null && c.gameObject != null
            ? c.gameObject.GetInstanceID() : 0;

        // ── registration (called from the Harmony hooks + bootstrap) ─────
        public static void RegisterPickup(PickUp p)
        {
            if (p == null) return;
            var bag = p as DroppedInventoryItemsPickup;
            if (bag != null) _bags.Add(bag);
            else _pickups.Add(p);
            int id = Id(p);
            if (id != 0)
                _entries[id] = new Entry { Pos = SafePos(p), Collected = p._isCollected };
        }

        public static void RegisterContainer(ContainerItemSpawner c)
        {
            if (c == null) return;
            _crates.Add(c);
            int id = Id(c);
            if (id != 0) _entries[id] = new Entry { Pos = SafePos(c) };
        }

        public static void RegisterAutoStorage(InWorldAutoStorage s)
        {
            if (s == null) return;
            _autoStorage.Add(s);
            int id = Id(s);
            if (id != 0) _entries[id] = new Entry { Pos = SafePos(s) };
        }

        public static void RegisterStorage(StructureStorage s)
        {
            if (s == null) return;
            _storage.Add(s);
            int id = Id(s);
            if (id != 0) _entries[id] = new Entry { Pos = SafePos(s) };
        }

        public static void RegisterArtifact(ArtifactStructure a)
        {
            if (a == null) return;
            _artifacts.Add(a);
            int id = Id(a);
            if (id != 0) _entries[id] = new Entry { Pos = SafePos(a) };
        }

        /// <summary>Positions + names of tracked GPS waypoints (for the map).</summary>
        public static void CollectGps(List<Vector3> pos, List<string> name)
        {
            foreach (var g in _gps)
            {
                if (g == null) continue;
                pos.Add(SafePos(g));
                name.Add(GpsName(g));
            }
        }

        public static void RegisterGps(GPSLocator g)
        {
            if (g == null) return;
            _gps.Add(g);
            int id = Id(g);
            if (id != 0) _entries[id] = new Entry { Pos = SafePos(g) };
        }

        /// <summary>Pickup hidden (fake-drop swap, disable) — keep it tracked.</summary>
        public static void ReRegisterPickup(PickUp p)
        {
            if (p == null) return;
            int id = Id(p);
            if (id != 0 && !_entries.ContainsKey(id)) RegisterPickup(p);
        }

        public static void ForgetCollected(PickUp p)
        {
            if (p == null) return;
            int id = Id(p);
            if (id == 0) return;
            Entry e;
            if (_entries.TryGetValue(id, out e))
            {
                e.Collected = true;
                _entries[id] = e;
            }
        }

        public static void UnregisterPickup(PickUp p)
        {
            if (p == null) return;
            var bag = p as DroppedInventoryItemsPickup;
            if (bag != null) _bags.Remove(bag);
            else _pickups.Remove(p);
            int id = Id(p);
            if (id != 0) _entries.Remove(id);
        }

        static Vector3 SafePos(Component c)
        {
            // component may be destroyed between registry read and use — the
            // per-frame callers treat Vector3.zero as "skip this entry"
            try { var t = c.transform; return t != null ? t.position : Vector3.zero; }
            catch { return Vector3.zero; }
        }

        // ── bootstrap: seed the registry with what already exists ────────
        static void EnsureBootstrapped()
        {
            if (_bootstrapped) return;
            _bootstrapped = true;

            var ps = UnityEngine.Object.FindObjectsOfType<PickUp>();
            if (ps != null) for (int i = 0; i < ps.Length; i++) RegisterPickup(ps[i]);
            var cs = UnityEngine.Object.FindObjectsOfType<ContainerItemSpawner>();
            if (cs != null) for (int i = 0; i < cs.Length; i++) RegisterContainer(cs[i]);
            var as_ = UnityEngine.Object.FindObjectsOfType<InWorldAutoStorage>();
            if (as_ != null) for (int i = 0; i < as_.Length; i++) RegisterAutoStorage(as_[i]);
            var st = UnityEngine.Object.FindObjectsOfType<StructureStorage>();
            if (st != null) for (int i = 0; i < st.Length; i++) RegisterStorage(st[i]);
            var ar = UnityEngine.Object.FindObjectsOfType<ArtifactStructure>();
            if (ar != null) for (int i = 0; i < ar.Length; i++) RegisterArtifact(ar[i]);
            var gs = UnityEngine.Object.FindObjectsOfType<GPSLocator>();
            if (gs != null) for (int i = 0; i < gs.Length; i++) RegisterGps(gs[i]);
        }

        // ── labels ───────────────────────────────────────────────────────
        static string ItemName(int itemId)
        {
            string cached;
            if (_names.TryGetValue(itemId, out cached)) return cached;
            string name = null;
            try
            {
                var d = ItemDatabaseManager.ItemById(itemId);
                if (d != null)
                {
                    var ui = d._uiData;
                    if (ui != null) name = ui.GetTitleLocalized();
                    if (string.IsNullOrEmpty(name)) name = d.Name;
                }
            }
            catch { } // database read failed — fall through to the id fallback
            if (string.IsNullOrEmpty(name)) name = "item " + itemId;
            _names[itemId] = name;
            return name;
        }

        // ── per-frame draw ───────────────────────────────────────────────
        static readonly GUIContent _gc = new GUIContent();

        public static void Draw()
        {
            LastDrawn = 0;
            if (!Enabled || !Game.InWorld) return;

            // Only Repaint renders — see Esp.Draw. Everything below (candidate
            // gathering, sorting, projecting, radar) is skipped on Layout and
            // input-event passes.
            if (Event.current != null && Event.current.type != EventType.Repaint) return;

            EnsureBootstrapped();
            if (Time.unscaledTime > _nextScan)
            {
                _nextScan = Time.unscaledTime + 3f;
                Prune();
            }

            var cam = Game.Cam;
            if (cam == null) return;
            var self = Game.PlayerTransform;
            Vector3 origin = self != null ? self.position : cam.transform.position;

            // snapshot the sets so hooks firing mid-frame cannot break iteration
            _cands.Clear();
            float max = Esp.MaxDistance;

            if (ShowItems)
            {
                foreach (var p in _pickups)
                    if (p != null) AddCandidate(_cands, p.transform.position, ItemName(p._itemId), Theme.Bone, max, origin);
            }
            if (ShowCollectibles)
            {
                foreach (var b in _bags)
                    if (b != null) AddCandidate(_cands, b.transform.position, ItemName(b._itemId), Theme.Live, max, origin);
                foreach (var a in _artifacts)
                    if (a != null) AddCandidate(_cands, a.transform.position, "Artifact", Theme.RustBright, max, origin);
            }
            if (ShowContainers)
            {
                foreach (var c in _crates)
                    if (c != null) AddCandidate(_cands, c.transform.position, "Crate", Theme.Olive, max, origin);
                foreach (var s in _autoStorage)
                    if (s != null) AddCandidate(_cands, s.transform.position, "Auto Storage", Theme.Olive, max, origin);
                foreach (var s in _storage)
                    if (s != null) AddCandidate(_cands, s.transform.position, "Storage", Theme.Olive, max, origin);
            }
            if (ShowWaypoints)
            {
                foreach (var g in _gps)
                {
                    if (g == null) continue;
                    string label = GpsName(g);
                    AddCandidate(_cands, g.transform.position, label, Theme.RustBright, max, origin);
                }
            }

            // nearest first, capped so labels never flood the screen
            _cands.Sort((a, b) => a.Dist.CompareTo(b.Dist));
            int budget = Mathf.Min(_cands.Count, 80);
            for (int i = 0; i < budget; i++)
                DrawPoint(_cands[i], cam);

            if (Radar) DrawRadar(origin, self != null ? self.eulerAngles.y : 0f);
        }

        struct Candidate
        {
            public Vector3 Pos;
            public string Label;
            public Color Color;
            public float Dist;
        }

        static readonly List<Candidate> _cands = new List<Candidate>(64);

        static void AddCandidate(List<Candidate> list, Vector3 pos, string label, Color color, float max, Vector3 origin)
        {
            float d = Vector3.Distance(origin, pos);
            if (d > max) return;
            list.Add(new Candidate { Pos = pos, Label = label, Color = color, Dist = d });
        }

        static string GpsName(GPSLocator g)
        {
            try
            {
                var poi = g._pointOfInterestName;
                if (!string.IsNullOrEmpty(poi)) return poi;
            }
            catch { } // gps component torn down mid-frame — try the next source
            try
            {
                var text = g.Text;
                if (!string.IsNullOrEmpty(text)) return text;
            }
            catch { } // same — fall back to the generic label
            return "Waypoint";
        }

        static void DrawPoint(Candidate c, Camera cam)
        {
            try
            {
                var top = cam.WorldToScreenPoint(c.Pos + Vector3.up * 1.2f);
                if (top.z <= 0f) return;
                float sx = top.x;
                float sy = Screen.height - top.y;
                float size = 7f;
                var r = new Rect(sx - size * 0.5f, sy - size * 0.5f, size, size);
                Theme.Fill(r, c.Color);
                Theme.Fill(new Rect(r.x - 1, r.y - 1, r.width + 2, 1f), Theme.Ink);
                Theme.Fill(new Rect(r.x - 1, r.yMax, r.width + 2, 1f), Theme.Ink);

                if (c.Label != null)
                {
                    var label = c.Label;
                    if (c.Dist >= 100f) label += "  " + ((int)c.Dist) + "m";
                    var style = Theme.EspLabel;
                    _gc.text = label;
                    var sz = style.CalcSize(_gc);
                    var lr = new Rect(sx - sz.x * 0.5f, sy + 4f, sz.x, sz.y);
                    lr.x = Mathf.Clamp(lr.x, 4f, Screen.width - sz.x - 4f);
                    lr.y = Mathf.Clamp(lr.y, 4f, Screen.height - sz.y - 4f);
                    var prev = style.normal.textColor;
                    try
                    {
                        style.normal.textColor = c.Color;
                        GUI.Label(lr, _gc, style);
                    }
                    finally { style.normal.textColor = prev; }
                }
                LastDrawn++;
            }
            catch { } // candidate despawned mid-draw — next frame re-prunes
        }

        /// <summary>Drops entries whose component was destroyed without OnDestroy firing.</summary>
        static void Prune()
        {
            try
            {
                _pickups.RemoveWhere(p => p == null);
                _bags.RemoveWhere(b => b == null);
                _crates.RemoveWhere(c => c == null);
                _autoStorage.RemoveWhere(s => s == null);
                _storage.RemoveWhere(s => s == null);
                _artifacts.RemoveWhere(a => a == null);
                _gps.RemoveWhere(g => g == null);
            }
            catch { } // sets mutated by a despawn during the sweep — next frame retries
        }

        // ── radar ────────────────────────────────────────────────────────
        static Texture2D _circleTex;

        static Texture2D CircleTex()
        {
            if (_circleTex != null) return _circleTex;
            const int N = 128;
            var t = new Texture2D(N, N, TextureFormat.RGBA32, false);
            var center = new Vector2(N * 0.5f, N * 0.5f);
            float radius = N * 0.5f - 1f;
            for (int y = 0; y < N; y++)
                for (int x = 0; x < N; x++)
                {
                    float d = Vector2.Distance(new Vector2(x + 0.5f, y + 0.5f), center);
                    float a = d <= radius ? 1f : 0f;
                    t.SetPixel(x, y, new Color(0.02f, 0.02f, 0.015f, 0.55f * a));
                }
            t.wrapMode = TextureWrapMode.Clamp;
            t.hideFlags = HideFlags.HideAndDontSave;
            t.Apply();
            _circleTex = t;
            return t;
        }

        static void DrawRadar(Vector3 origin, float yawDeg)
        {
            const float size = 170f;
            var corner = new Vector2(Screen.width - size - 14f, Screen.height - size - 14f);
            var rect = new Rect(corner.x, corner.y, size, size);

            GUI.DrawTexture(rect, CircleTex());
            Theme.Box(new Rect(rect.x - 1, rect.y - 1, rect.width + 2, rect.height + 2), Theme.Line, 1f);

            // heading notch
            float hx = corner.x + size * 0.5f;
            Theme.Fill(new Rect(hx - 1f, corner.y - 2f, 2f, 5f), Theme.RustBright);

            float range = Mathf.Max(RadarRange, 10f);
            float cs = Mathf.Cos(-yawDeg * Mathf.Deg2Rad);
            float sn = Mathf.Sin(-yawDeg * Mathf.Deg2Rad);
            float half = size * 0.5f - 5f;

            BlipSet(corner, origin, cs, sn, half, range, _pickups, Theme.Bone);
            BlipSet(corner, origin, cs, sn, half, range, _bags, Theme.Live);
            BlipSet(corner, origin, cs, sn, half, range, _crates, Theme.Olive);
            BlipSet(corner, origin, cs, sn, half, range, _autoStorage, Theme.Olive);
            BlipSet(corner, origin, cs, sn, half, range, _storage, Theme.Olive);
            BlipSet(corner, origin, cs, sn, half, range, _artifacts, Theme.RustBright);
            BlipSet(corner, origin, cs, sn, half, range, _gps, Theme.RustBright);
        }

        static void BlipSet<T>(Vector2 corner, Vector3 origin, float cs, float sn, float half,
                         float range, HashSet<T> set, Color color) where T : Component
        {
            foreach (var c in set)
            {
                if (c == null) continue;
                Vector3 pos;
                try { pos = c.transform.position; } catch { continue; } // despawned — skip
                Vector3 rel = pos - origin;
                if (Mathf.Abs(rel.x) > range || Mathf.Abs(rel.z) > range) continue;

                float rx = rel.x * cs - rel.z * sn;
                float rz = rel.x * sn + rel.z * cs;

                float cx = corner.x + half + rx / range * half;
                float cy = corner.y + half - rz / range * half;
                if (cx < corner.x + 3f || cx > corner.x + 168f ||
                    cy < corner.y + 3f || cy > corner.y + 168f) continue;

                Theme.Fill(new Rect(cx - 1.5f, cy - 1.5f, 3f, 3f), color);
            }
        }
    }

    // ── Harmony hooks keeping the registry in sync with the world ───────
    [HarmonyPatch(typeof(PickUp), "OnEnable")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_OnEnable
    {
        static void Postfix(PickUp __instance) => ItemEsp.RegisterPickup(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "OnDisable")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_OnDisable
    {
        static void Postfix(PickUp __instance) => ItemEsp.ReRegisterPickup(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "OnDestroy")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_OnDestroy
    {
        static void Postfix(PickUp __instance) => ItemEsp.UnregisterPickup(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "Collect")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_Collect
    {
        static void Postfix(PickUp __instance) => ItemEsp.ForgetCollected(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "Take")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_Take
    {
        static void Postfix(PickUp __instance) => ItemEsp.ForgetCollected(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "DoFakeDrop")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_DoFakeDrop
    {
        static void Postfix(PickUp __instance) => ItemEsp.ReRegisterPickup(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "ResetIsCollected")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_ResetIsCollected
    {
        static void Postfix(PickUp __instance) => ItemEsp.ReRegisterPickup(__instance);
    }

    [HarmonyPatch(typeof(PickUp), "SpawnPickupPrefab")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_PickUp_SpawnPickupPrefab
    {
        static void Postfix(PickUp __instance) => ItemEsp.ReRegisterPickup(__instance);
    }

    [HarmonyPatch(typeof(ContainerItemSpawner), "OnEnable")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_Crate_OnEnable
    {
        static void Postfix(ContainerItemSpawner __instance) => ItemEsp.RegisterContainer(__instance);
    }

    [HarmonyPatch(typeof(GPSLocator), "OnEnable")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_Gps_OnEnable
    {
        static void Postfix(GPSLocator __instance) => ItemEsp.RegisterGps(__instance);
    }

    [HarmonyPatch(typeof(ArtifactStructure), "OnEnable")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_Artifact_OnEnable
    {
        static void Postfix(ArtifactStructure __instance) => ItemEsp.RegisterArtifact(__instance);
    }

    // InWorldAutoStorage declares no OnEnable in this build (Start /
    // OnTriggerEnter / TweenInPosition are its lifecycle methods), so hook
    // Start — it fires when the storage comes alive, same registration intent.
    [HarmonyPatch(typeof(InWorldAutoStorage), "Start")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_AutoStorage_Start
    {
        static void Postfix(InWorldAutoStorage __instance) => ItemEsp.RegisterAutoStorage(__instance);
    }

    [HarmonyPatch(typeof(StructureStorage), "Awake")]
    [Cyberfox1337x("ESP registry hook", Bound = "Harmony target; Postfix matched by name")]
    internal static class Patch_Storage_Awake
    {
        static void Postfix(StructureStorage __instance) => ItemEsp.RegisterStorage(__instance);
    }
}

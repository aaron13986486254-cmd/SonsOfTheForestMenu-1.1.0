// ═══════════════════════════════════════════════════════════════════════════
//  Diag.cs · the plugin's only route to the BepInEx log
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Concurrent;
using BepInEx.Logging;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Thin front for <see cref="ManualLogSource"/>.
///
/// Nothing else in the plugin touches the BepInEx sink directly. Routing every
/// line through one place buys three things that matter here:
///
///   • <b>Survivable before Load.</b> Every method no-ops until <see cref="Bind"/>
///     runs, so a static initialiser that logs cannot null-ref during boot.
///   • <b>Suppression.</b> <see cref="Once"/> collapses repeat messages from a
///     per-frame site to a single line. The menu ticks every frame while the
///     world simulates underneath; an unsuppressed warning there produces
///     thousands of lines a minute and buries the one that matters.
///   • <b>One secret-safety seam.</b> The Steam Web API key is the only secret
///     this plugin holds. <see cref="Redact"/> is the single approved way to
///     put anything key-shaped into a log line.
///
/// Thread-safe: <see cref="Avatars"/> logs from thread-pool workers.
/// </summary>
[Cyberfox1337x]
internal static class Diag
{
    static ManualLogSource _sink;

    /// <summary>Sites that have already emitted, for <see cref="Once"/>.</summary>
    static readonly ConcurrentDictionary<string, bool> _seen = new();

    /// <summary>Attaches the BepInEx sink. Called once, first thing in Load.</summary>
    internal static void Bind(ManualLogSource sink) => _sink = sink;

    internal static void Info(string message) => _sink?.LogInfo(message);

    internal static void Warn(string message) => _sink?.LogWarning(message);

    internal static void Error(string message) => _sink?.LogError(message);

    /// <summary>
    /// Emits <paramref name="message"/> the first time this site reports, then
    /// stays silent for it. Use for anything reachable from a per-frame path.
    /// </summary>
    internal static void Once(string site, string message)
    {
        if (_seen.TryAdd(site, true))
            _sink?.LogWarning($"{message}  (further reports from '{site}' suppressed)");
    }

    /// <summary>
    /// Formats an exception for a log line: type and message, never the stack
    /// trace. Traces leak absolute install paths, and none of the failures this
    /// plugin catches are diagnosable from a trace anyway — they are almost all
    /// "the object was torn down between two frames".
    /// </summary>
    internal static string Describe(Exception error) =>
        error is null ? "(no detail)" : $"{error.GetType().Name}: {error.Message}";

    /// <summary>
    /// Masks a secret down to a length and a four-character tail, enough to
    /// tell two keys apart in a log without disclosing either. The only
    /// sanctioned way to mention the Steam Web API key in output.
    /// </summary>
    internal static string Redact(string secret)
    {
        if (string.IsNullOrEmpty(secret)) return "(unset)";
        return secret.Length <= 4
            ? $"(set, {secret.Length} chars)"
            : $"(set, {secret.Length} chars, ends {secret.Substring(secret.Length - 4)})";
    }
}

// ═══════════════════════════════════════════════════════════════════════════
//  Roster.cs · multiplayer player list and admin lookup
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using UnityEngine;
using TheForest.Utils;
using Sons.Multiplayer;
using Sons.Multiplayer.Gui;
// BoltEntity / BoltConnection live in the global namespace (assembly "bolt").

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// One row in the player list. Local first, then every remote player the
    /// game's player-list knows about (via its KnownPlayerData dictionary).
    /// </summary>
    [Cyberfox1337x("roster row")]
    public struct RemotePlayer
    {
        public string Name;
        public ulong SteamId;
        public Vector3 Position;
        public bool IsAlive;
        public bool IsLocal;
        public bool IsAdmin;
        public BoltEntity Entity;
    }

    /// <summary>
    /// Live multiplayer roster. Mirrors the reference menu's approach: read the
    /// game's own PlayerListBase._knownPlayers dictionary and match each
    /// PlayerName tag up the hierarchy to its BoltEntity.
    /// </summary>
    [Cyberfox1337x]
    internal static class Roster
    {
        public static readonly List<RemotePlayer> Players = new List<RemotePlayer>();
        public static string Status = "";

        static ulong _cachedMyId;
        static float _cachedMyIdTime;

        /// <summary>Local player's Steam ID, cached for 15s between refreshes.</summary>
        public static ulong MySteamId()
        {
            if (_cachedMyId != 0 && Time.time - _cachedMyIdTime < 15f)
                return _cachedMyId;
            Refresh();
            for (int i = 0; i < Players.Count; i++)
            {
                if (Players[i].IsLocal && Players[i].SteamId != 0)
                {
                    _cachedMyId = Players[i].SteamId;
                    _cachedMyIdTime = Time.time;
                    return _cachedMyId;
                }
            }
            return 0;
        }

        public static void Refresh()
        {
            Players.Clear();
            Status = "";
            try
            {
                var local = LocalPlayer._instance;
                if (local == null) { Status = "not in a world"; return; }

                var localEntity = local.GetComponent<BoltEntity>();
                var lv = LocalPlayer.Vitals;

                var roles = UnityEngine.Object.FindObjectOfType<MultiplayerPlayerRoles>();
                var known = PlayerListBase._knownPlayers;

                // The local player is NOT in the game's known-players dict, so
                // its SteamId comes from the game's own CoopSteamServer (already
                // initialized by the game). Fallback chain:
                //   1. CoopSteamServer.SteamId (game's own)
                //   2. Steamworks.SteamUser.GetSteamID (direct API)
                //   3. known-players dict (host sometimes has an entry)
                //   4. 0 (placeholder tile, no avatar fetch)
                ulong localSteamId = 0;
                try
                {
                    var csid = CoopSteamServer.SteamId;
                    if (csid.IsValid()) localSteamId = (ulong)csid;
                }
                catch (Exception ex)
                {
                    Diag.Warn("coop steam id: " + ex.Message);
                }
                if (localSteamId == 0)
                {
                    try
                    {
                        var sid = Steamworks.SteamUser.GetSteamID();
                        if (sid.IsValid()) localSteamId = (ulong)sid;
                    }
                    catch (Exception ex)
                    {
                        Diag.Warn("steam id: " + ex.Message);
                    }
                }
                if (localSteamId == 0 && known != null && localEntity != null)
                {
                    var ld = FindData(known, localEntity);
                    if (ld != null) localSteamId = ld.SteamId;
                }

                // Steam display name for the local row, not the literal "You".
                string localName = null;
                try
                {
                    localName = Steamworks.SteamFriends.GetPersonaName();
                }
                catch (Exception ex)
                {
                    Diag.Warn("steam name: " + ex.Message);
                }
                if (string.IsNullOrEmpty(localName)) localName = "You";

                Players.Add(new RemotePlayer
                {
                    Name = localName,
                    SteamId = localSteamId,
                    Position = local.transform.position,
                    IsAlive = lv != null && lv.IsAlive(),
                    IsLocal = true,
                    IsAdmin = true,
                    Entity = localEntity,
                });

                if (known == null) { Status = Players.Count + " player(s)"; return; }

                var names = UnityEngine.Object.FindObjectsOfType<PlayerName>();
                if (names == null) { Status = Players.Count + " player(s)"; return; }

                for (int i = 0; i < names.Length; i++)
                {
                    var pn = names[i];
                    if (pn == null) continue;
                    var entity = pn.GetComponentInParent<BoltEntity>();
                    if (entity == null) continue;
                    if (localEntity != null && entity == localEntity) continue;

                    PlayerListBase.KnownPlayerData knownData = FindData(known, entity);

                    var tr = entity.transform;
                    var pos = tr != null ? tr.position : Vector3.zero;

                    var vitals = entity.GetComponentInChildren<Vitals>();
                    ulong steamId = knownData != null ? knownData.SteamId : 0;

                    Players.Add(new RemotePlayer
                    {
                        Name = knownData != null && !string.IsNullOrEmpty(knownData.Name)
                            ? knownData.Name : "(unnamed)",
                        SteamId = steamId,
                        Position = pos,
                        IsAlive = vitals != null && vitals.IsAlive(),
                        IsLocal = false,
                        IsAdmin = roles != null && steamId != 0
                            && (roles.IsAdmin(steamId) || roles.IsOwner(steamId)),
                        Entity = entity,
                    });
                }

                Status = Players.Count + " player(s)";
            }
            catch (Exception e)
            {
                Status = "roster unavailable";
                Diag.Warn("roster refresh: " + e.Message);
            }

            // queue avatar fetches for every player with a Steam id
            for (int i = 0; i < Players.Count; i++)
                if (Players[i].SteamId != 0) Avatars.Ensure(Players[i].SteamId);
        }

        static PlayerListBase.KnownPlayerData FindData(
            Il2CppSystem.Collections.Generic.Dictionary<BoltConnection, PlayerListBase.KnownPlayerData> known,
            BoltEntity entity)
        {
            var it = known.GetEnumerator();
            while (it.MoveNext())
            {
                var kv = it.Current;
                var d = kv.Value;
                if (d != null && d.BoltEntity == entity) return d;
            }
            return null;
        }

        /// <summary>
        /// Lightweight avatar prefetch used right after the world loads: builds
        /// the player list (local + any already-known remote players) and queues
        /// avatar fetches, so the ONLINE / MAP tabs show cached pictures
        /// immediately instead of placeholders. Called from the per-frame tick,
        /// not from OnGUI, so it never races the tab draw.
        /// </summary>
        public static void Prefetch()
        {
            try
            {
                Refresh(); // already queues Avatars.Ensure for every SteamId
            }
            catch (Exception e)
            {
                Diag.Warn("avatar prefetch: " + e.Message);
            }
        }

        public static bool TryGet(int index, out RemotePlayer p)
        {
            if (index >= 0 && index < Players.Count) { p = Players[index]; return true; }
            p = default;
            return false;
        }

        /// <summary>Move the local player to the named player's position.</summary>
        public static void TeleportTo(int index)
        {
            RemotePlayer p;
            if (!TryGet(index, out p) || p.IsLocal) return;
            try
            {
                LocalPlayer._instance.Goto(p.Position);
                Features.LastResult = "Teleported to " + p.Name;
            }
            catch (Exception e) { Features.LastResult = "Teleport failed"; Diag.Warn(e.Message); }
        }

        /// <summary>Move the named player to the local player's position.</summary>
        public static void Bring(int index)
        {
            RemotePlayer p;
            if (!TryGet(index, out p) || p.IsLocal || p.Entity == null) return;
            try
            {
                var me = LocalPlayer._instance;
                p.Entity.transform.position = me.transform.position + Vector3.up * 1.5f;
                Features.LastResult = "Brought " + p.Name;
            }
            catch (Exception e) { Features.LastResult = "Bring failed"; Diag.Warn(e.Message); }
        }

        public static void Kill(int index)
        {
            RemotePlayer p;
            if (!TryGet(index, out p) || p.IsLocal || p.Entity == null) return;
            try
            {
                var v = p.Entity.GetComponentInChildren<Vitals>();
                if (v != null) { v.TriggerDeath(); Features.LastResult = "Killed " + p.Name; }
                else Features.LastResult = "No vitals on " + p.Name;
            }
            catch (Exception e) { Features.LastResult = "Kill failed"; Diag.Warn(e.Message); }
        }

        public static void Revive(int index)
        {
            RemotePlayer p;
            if (!TryGet(index, out p) || p.IsLocal || p.Entity == null) return;
            try
            {
                var v = p.Entity.GetComponentInChildren<Vitals>();
                if (v != null) { v.SetFullHealth(); Features.LastResult = "Revived " + p.Name; }
                else Features.LastResult = "No vitals on " + p.Name;
            }
            catch (Exception e) { Features.LastResult = "Revive failed"; Diag.Warn(e.Message); }
        }
    }
}

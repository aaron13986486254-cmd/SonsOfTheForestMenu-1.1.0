// ═══════════════════════════════════════════════════════════════════════════
//  Map.cs · sampled terrain map and markers
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using System;
using System.Collections.Generic;
using UnityEngine;
using TheForest.Utils;

namespace Cyberfox1337x.SonsOfTheForest
{
    /// <summary>
    /// Satellite-style island map matching the in-game GPS tracker. A 256×256
    /// grid of downward raycasts records terrain height; from that a 1024×1024
    /// texture is built using three-octave fractal noise, slope analysis and
    /// water-body detection. The palette is tuned for the GPS look — light
    /// greys/tans for open ground, layered greens for forest, blue for water,
    /// grey-brown for rock, white for the snow cap.
    ///
    /// Markers (save spots, GPS, bunkers, players) are overlaid; clicking a
    /// marker or open ground teleports there. Sampling runs in chunks across
    /// frames so opening the tab never hitches.
    /// </summary>
    [Cyberfox1337x]
    internal static class Map
    {
        // World bounds — the island is roughly ±2000 in both axes
        const float MinX = -2100f, MaxX = 2100f;
        const float MinZ = -2100f, MaxZ = 2100f;
        const int    Grid = 256;           // samples per axis (65 536 total)
        const int    PerFrame = 512;       // raycasts per tick (~128 frames ≈ 2s)

        static float[]   _heights;         // Grid² raw height samples
        static float[]   _flatness;        // local-height-variance (for water)
        static Texture2D _tex;
        static bool      _sampling;
        static int       _sampleIdx;

        public static bool Ready    => _tex != null;
        public static bool Sampling => _sampling;
        public static float Progress => _heights == null ? 0f
            : (float)_sampleIdx / _heights.Length;

        // ── sampling ───────────────────────────────────────────────────
        public static void BeginSample()
        {
            _heights   = new float[Grid * Grid];
            _flatness  = new float[Grid * Grid];
            _tex       = null;
            _sampling  = true;
            _sampleIdx = 0;
        }

        public static void TickSample()
        {
            if (!_sampling || _heights == null || !Game.InWorld) return;
            int end = Mathf.Min(_sampleIdx + PerFrame, _heights.Length);
            for (int i = _sampleIdx; i < end; i++)
            {
                int gx = i % Grid, gz = i / Grid;
                float x = MinX + (gx + 0.5f) / Grid * (MaxX - MinX);
                float z = MinZ + (gz + 0.5f) / Grid * (MaxZ - MinZ);
                _heights[i] = SampleHeight(x, z);
            }
            _sampleIdx = end;
            if (_sampleIdx >= _heights.Length)
            {
                BuildFlatness();
                BuildTexture();
                _flatness = null;  // free 512 KB after texture is built
                _sampling = false;
            }
        }

        static float SampleHeight(float x, float z)
        {
            try
            {
                RaycastHit hit;
                if (Physics.Raycast(new Vector3(x, 5000f, z), Vector3.down,
                                    out hit, 12000f))
                    return hit.point.y;
                return -200f; // open ocean
            }
            catch { return -200f; }
        }

        static float CellSize => (MaxX - MinX) / Grid;

        static float HeightAtCell(int gx, int gz)
        {
            if (gx < 0) gx = 0; else if (gx >= Grid) gx = Grid - 1;
            if (gz < 0) gz = 0; else if (gz >= Grid) gz = Grid - 1;
            return _heights[gz * Grid + gx];
        }

        /// <summary>
        /// For every cell compute the variance of heights in a 3×3 neighbourhood.
        /// Cells near sea level with very low variance are lakes or rivers —
        /// the game map renders them as water.
        /// </summary>
        static void BuildFlatness()
        {
            for (int gz = 0; gz < Grid; gz++)
            {
                for (int gx = 0; gx < Grid; gx++)
                {
                    float h0 = HeightAtCell(gx, gz);
                    float hL = HeightAtCell(gx - 1, gz), hR = HeightAtCell(gx + 1, gz);
                    float hD = HeightAtCell(gx, gz - 1), hU = HeightAtCell(gx, gz + 1);
                    float dL = hL - h0, dR = hR - h0, dD = hD - h0, dU = hU - h0;
                    _flatness[gz * Grid + gx] = (dL * dL + dR * dR + dD * dD + dU * dU);
                }
            }
        }

        // ── texture building ─────────────────────────────────────────────
        // 4 texels per cell → Grid*4 (1024) square texture
        const int Scl = 4;

        static void BuildTexture()
        {
            var tex  = new Texture2D(Grid * Scl, Grid * Scl, TextureFormat.RGBA32, false);
            var cols = new Color[Grid * Scl * Grid * Scl];
            for (int gz = 0; gz < Grid; gz++)
            {
                for (int gx = 0; gx < Grid; gx++)
                {
                    float h = _heights[gz * Grid + gx];
                    float f = _flatness[gz * Grid + gx];
                    for (int dy = 0; dy < Scl; dy++)
                    {
                        for (int dx = 0; dx < Scl; dx++)
                        {
                            float wx = MinX + (gx + (dx + 0.5f) / Scl) / Grid * (MaxX - MinX);
                            float wz = MinZ + (gz + (dy + 0.5f) / Scl) / Grid * (MaxZ - MinZ);
                            cols[(gz * Scl + dy) * Grid * Scl + (gx * Scl + dx)] =
                                TerrainColor(h, f, wx, wz);
                        }
                    }
                }
            }
            tex.SetPixels(cols);
            tex.Apply(false);
            tex.wrapMode   = TextureWrapMode.Clamp;
            tex.filterMode = FilterMode.Bilinear;
            _tex = tex;
        }

        // ── palette ─────────────────────────────────────────────────────
        // Satellite-style: blue water, tan beach, layered greens for forest,
        // grey-brown rock, white snow. Every swatch has a bright and dark
        // variant so the 3-octave noise can break up flat bands.

        // water
        static readonly Color WDeep   = new Color(0.04f, 0.08f, 0.20f);
        static readonly Color WOcean  = new Color(0.07f, 0.16f, 0.34f);
        static readonly Color WShal   = new Color(0.10f, 0.26f, 0.38f);
        static readonly Color WRiver  = new Color(0.12f, 0.30f, 0.44f);

        // land — warm earth tones underneath, layered green on top
        static readonly Color Sand    = new Color(0.72f, 0.66f, 0.52f);
        static readonly Color SandD   = new Color(0.58f, 0.53f, 0.41f);
        static readonly Color Grass   = new Color(0.46f, 0.54f, 0.32f);
        static readonly Color GrassL  = new Color(0.58f, 0.64f, 0.42f);
        static readonly Color Forest  = new Color(0.28f, 0.38f, 0.18f);
        static readonly Color ForestD = new Color(0.18f, 0.27f, 0.10f);
        static readonly Color Rock    = new Color(0.44f, 0.43f, 0.38f);
        static readonly Color RockL   = new Color(0.52f, 0.51f, 0.46f);
        static readonly Color Snow    = new Color(0.92f, 0.93f, 0.91f);
        static readonly Color SnowS   = new Color(0.85f, 0.86f, 0.84f);

        /// <summary>
        /// Maps height + local flatness + 3-octave fractal noise to a colour.
        /// Flat cells near sea level → water (lakes/rivers). Otherwise height
        /// bands set the base colour; noise varies it so the map reads as
        /// natural terrain rather than a contour plot.
        /// </summary>
        static Color TerrainColor(float h, float flat, float x, float z)
        {
            // 3-octave fractal noise for natural terrain variation
            float n1 = Fbm(x * 0.0025f, z * 0.0025f, 3);  // ~800 m blobs
            float n2 = Fbm(x * 0.012f,  z * 0.012f,  2);  // ~170 m patches
            float n3 = Fbm(x * 0.06f,  z * 0.06f,   2);  // ~33 m grain
            float nr = n1 * 0.5f + n2 * 0.3f + n3 * 0.2f; // blended noise

            // ── water ──
            if (h <= -80f)  return Vary(WDeep,  nr, 0.06f);
            if (h <= -15f)  return Vary(WOcean, nr, 0.08f);
            if (h <= -3f)   return Vary(WShal,  nr, 0.10f);

            // flat cells near sea level → rivers / lakes
            if (h <= 4f && flat < 8f)
                return Vary(WRiver, nr, 0.12f);

            // ── beach ──
            if (h <= 8f)    return n2 > 0.55f ? Vary(SandD, nr, 0.05f)
                                              : Vary(Sand,  nr, 0.08f);

            // ── coastal grassland (most of the island's habitable ring) ──
            if (h <= 30f)
            {
                if      (n1 > 0.60f) return Vary(Forest,  nr, 0.12f);
                else if (n1 > 0.42f) return Vary(Grass,   nr, 0.14f);
                else                 return Vary(GrassL,  nr, 0.10f);
            }

            // ── forest belt ──
            if (h <= 120f)
            {
                if      (n1 > 0.55f) return Vary(ForestD, nr, 0.10f);
                else if (n1 > 0.35f) return Vary(Forest,  nr, 0.12f);
                else                 return Vary(Grass,   nr, 0.10f);
            }

            // ── highland: mixed forest and exposed rock faces ──
            if (h <= 280f)
            {
                float s = Mathf.Sqrt(flat) / (2f * CellSize); // approximate slope
                if (s > 0.7f) return Vary(Rock,  nr, 0.10f);
                return n1 > 0.40f ? Vary(ForestD, nr, 0.10f)
                                  : Vary(Forest,  nr, 0.12f);
            }

            // ── alpine ──
            if (h <= 450f)
            {
                float s = Mathf.Sqrt(flat) / (2f * CellSize);
                if (s > 0.5f) return Vary(Rock,  nr, 0.08f);
                return n1 > 0.45f ? Vary(RockL, nr, 0.10f)
                                  : Vary(Grass, nr, 0.08f);
            }

            // ── snow cap ──
            if (h <= 650f) return Vary(SnowS, nr, 0.04f);
            return Vary(Snow, nr, 0.03f);
        }

        static Color Vary(Color c, float t, float amp)
        {
            float s = 1f - amp + t * amp * 2f;
            return new Color(c.r * s, c.g * s, c.b * s, 1f);
        }

        // ── fractal noise ───────────────────────────────────────────────
        /// <summary>
        /// Fractional Brownian motion — octaves of value noise at halving
        /// amplitudes. Produces richer terrain patterns than a single call.
        /// </summary>
        static float Fbm(float x, float z, int octaves)
        {
            float v = 0f, amp = 1f, max = 0f;
            for (int i = 0; i < octaves; i++)
            {
                v   += Noise(x, z) * amp;
                max += amp;
                amp *= 0.5f;
                x   *= 2f;
                z   *= 2f;
            }
            return v / max;
        }

        /// <summary>Deterministic value noise, 0–1, bilinearly smoothed.</summary>
        static float Noise(float x, float z)
        {
            int ix = Mathf.FloorToInt(x), iz = Mathf.FloorToInt(z);
            float fx = x - ix, fz = z - iz;
            fx = fx * fx * (3f - 2f * fx);
            fz = fz * fz * (3f - 2f * fz);
            float a = Hash(ix, iz), b = Hash(ix + 1, iz);
            float c = Hash(ix, iz + 1), d = Hash(ix + 1, iz + 1);
            return Mathf.Lerp(Mathf.Lerp(a, b, fx), Mathf.Lerp(c, d, fx), fz);
        }

        static float Hash(int x, int z)
        {
            uint h = (uint)(x * 374761393 + z * 668265263);
            h = (h ^ (h >> 13)) * 1274126177u;
            return (h ^ (h >> 16)) / (float)uint.MaxValue;
        }

        // ── drawing ────────────────────────────────────────────────────
        struct Marker
        {
            public Vector3 Pos;
            public string  Label;
            public Color   Color;
            public int     TeleportIndex; // -1 = plain Goto
            public ulong   SteamId;       // != 0 → draw avatar
            public bool    Bunker;        // red P square
        }

        static readonly Vector3[] BunkerPos =
        {
            new Vector3(-477.71f,  86.52f,   713.86f),   // Bunker A
            new Vector3(-1136.85f, 280.74f, -1103.40f),  // Bunker B
            new Vector3( 1109.97f, 129.03f,  1007.63f),  // Bunker C
            new Vector3(-1192.75f, 66.94f,   140.70f),   // Entertainment
            new Vector3(-1015.25f, 99.56f,  1040.33f),   // Food & Dining
            new Vector3( 1756.66f, 40.33f,   552.78f),   // Luxury
            new Vector3( 1238.51f, 239.69f, -657.45f),   // Residential
        };
        static readonly string[] BunkerName =
        {
            "Bunker A", "Bunker B", "Bunker C", "Bunker Entertainment",
            "Bunker Food", "Bunker Luxury", "Bunker Residential",
        };

        static GUIStyle _gridStyle, _markerLabel, _markerShadow, _legendStyle;
        static readonly List<Marker>   _markers  = new List<Marker>(32);
        static readonly List<Vector3>  _gpsPos   = new List<Vector3>(8);
        static readonly List<string>   _gpsNames = new List<string>(8);
        static readonly GUIContent _gc = new GUIContent();

        public static void Draw(Rect pane)
        {
            if (Game.InWorld && !_sampling && _tex == null)
                BeginSample();
            if (_sampling)
            {
                TickSample();
                DrawProgress(pane);
                return;
            }
            if (_tex == null)
            {
                GUI.Label(new Rect(pane.x + 16, pane.y + 16, pane.width - 32, 40),
                          "Load a save to sample the island.", Theme.Lede);
                return;
            }

            float side = Mathf.Min(pane.width - 24f, pane.height - 24f);
            var map = new Rect(pane.x + (pane.width - side) * 0.5f,
                               pane.y + (pane.height - side) * 0.5f, side, side);
            GUI.DrawTexture(map, _tex);
            Theme.Box(map, Theme.Line, 1f);

            // coordinate grid every 500 world units
            if (_gridStyle == null)
            {
                _gridStyle = new GUIStyle(Theme.Build);
                _gridStyle.normal.textColor = Theme.Dead;
            }
            for (float g = -2000f; g <= 2000f; g += 500f)
            {
                float ux = (g - MinX) / (MaxX - MinX);
                float uz = (g - MinZ) / (MaxZ - MinZ);
                if (ux > 0f && ux < 1f)
                {
                    Theme.Fill(new Rect(map.x + ux * map.width, map.y, 1, map.height), Theme.Line);
                    GUI.Label(new Rect(map.x + ux * map.width + 3, map.y + 3, 40, 12),
                              g.ToString("0"), _gridStyle);
                    GUI.Label(new Rect(map.x + ux * map.width + 3, map.yMax - 15, 40, 12),
                              g.ToString("0"), _gridStyle);
                }
                if (uz > 0f && uz < 1f)
                {
                    Theme.Fill(new Rect(map.x, map.y + (1f - uz) * map.height, map.width, 1), Theme.Line);
                    var lbl = g.ToString("0");
                    var lw  = _gridStyle.CalcSize(new GUIContent(lbl)).x;
                    GUI.Label(new Rect(map.x + 3, map.y + (1f - uz) * map.height - 6,
                                       Mathf.Min(lw + 6f, 46f), 12), lbl, _gridStyle);
                }
            }
            GUI.Label(new Rect(map.xMax - 30, map.y + 3, 26, 12), "N↑", _gridStyle);

            // markers
            var markers = _markers;
            markers.Clear();
            for (int i = 0; i < Teleport.Spots.Count; i++)
                markers.Add(new Marker { Pos = Teleport.Spots[i].Pos,
                    Label = Teleport.Spots[i].Name, Color = Theme.Bone, TeleportIndex = i });
            _gpsPos.Clear(); _gpsNames.Clear();
            ItemEsp.CollectGps(_gpsPos, _gpsNames);
            for (int i = 0; i < _gpsPos.Count; i++)
                markers.Add(new Marker { Pos = _gpsPos[i], Label = _gpsNames[i],
                    Color = Theme.RustBright, TeleportIndex = -1 });
            for (int i = 0; i < BunkerPos.Length; i++)
                markers.Add(new Marker { Pos = BunkerPos[i], Label = BunkerName[i],
                    Color = Theme.RustBright, TeleportIndex = -1, Bunker = true });

            ulong localSteamId = 0;
            for (int i = 0; i < Roster.Players.Count; i++)
            {
                var p = Roster.Players[i];
                if (p.IsLocal) { localSteamId = p.SteamId; continue; }
                markers.Add(new Marker { Pos = p.Position, Label = p.Name,
                    Color = Theme.Olive, TeleportIndex = -1, SteamId = p.SteamId });
            }
            var me = Game.PlayerTransform;
            if (me != null)
                markers.Add(new Marker { Pos = me.position, Label = "You",
                    Color = Theme.Live, TeleportIndex = -1, SteamId = localSteamId });

            DrawMarkers(map, markers);
            DrawLegend(map, markers.Count);
            HandleClick(map, markers);
        }

        static void DrawMarkers(Rect map, List<Marker> markers)
        {
            if (_markerLabel == null)
            {
                _markerLabel = new GUIStyle(Theme.Build);
                _markerLabel.normal.textColor = Theme.Paper;
                _markerShadow = new GUIStyle(_markerLabel);
                _markerShadow.normal.textColor = new Color(0f, 0f, 0f, 0.85f);
            }
            var label  = _markerLabel;
            var shadow = _markerShadow;

            for (int i = 0; i < markers.Count; i++)
            {
                var m = markers[i];
                float u = (m.Pos.x - MinX) / (MaxX - MinX);
                float v = (m.Pos.z - MinZ) / (MaxZ - MinZ);
                if (u < 0f || u > 1f || v < 0f || v > 1f) continue;
                float x = map.x + u * map.width;
                float y = map.y + (1f - v) * map.height;

                var av = m.SteamId != 0 ? Avatars.Get(m.SteamId) : null;
                if (m.Bunker)
                {
                    Theme.Fill(new Rect(x - 6f, y - 6f, 12, 12), new Color(0, 0, 0, 0.8f));
                    Theme.Fill(new Rect(x - 5f, y - 5f, 10, 10), Theme.RustBright);
                    _gc.text = "P";
                    var ps = label.CalcSize(_gc);
                    var pr = new Rect(x - ps.x * 0.5f - 1f, y - ps.y * 0.5f - 2f,
                                      ps.x + 2f, ps.y + 2f);
                    var prev = label.normal.textColor;
                    label.normal.textColor = Theme.Paper;
                    GUI.Label(pr, _gc, label);
                    label.normal.textColor = prev;
                }
                else if (av != null)
                {
                    Theme.Fill(new Rect(x - 8f, y - 8f, 16, 16), new Color(0, 0, 0, 0.8f));
                    GUI.DrawTexture(new Rect(x - 7f, y - 7f, 14, 14), av);
                }
                else
                {
                    Theme.Fill(new Rect(x - 3.5f, y - 3.5f, 7, 7), new Color(0, 0, 0, 0.8f));
                    Theme.Fill(new Rect(x - 2f, y - 2f, 4, 4), m.Color);
                }

                _gc.text = m.Label;
                float tw = label.CalcSize(_gc).x;
                float lx = x + 6f, ly = y - 7f;
                if (lx + tw > map.xMax) lx = x - tw - 6f;
                var lbl = new Rect(lx, ly, tw, 14);
                GUI.Label(new Rect(lx + 1, ly + 1, tw, 14), _gc, shadow);
                GUI.Label(lbl, _gc, label);
            }
        }

        static void DrawLegend(Rect map, int count)
        {
            if (_legendStyle == null)
            {
                _legendStyle = new GUIStyle(Theme.Build);
                _legendStyle.normal.textColor = Theme.Ash;
            }
            var style = _legendStyle;
            float y = map.yMax + 8f, x = map.x;
            string[] names = { "SPOTS", "GPS", "BUNKERS", "PLAYERS", "YOU" };
            Color[]  cols  = { Theme.Bone, Theme.RustBright, Theme.RustBright,
                               Theme.Olive, Theme.Live };
            for (int i = 0; i < names.Length; i++)
            {
                Theme.Fill(new Rect(x, y + 4, 7, 7), cols[i]);
                GUI.Label(new Rect(x + 10, y, 90, 14), names[i], style);
                x += 100f;
            }
            GUI.Label(new Rect(map.xMax - 190, y, 190, 14),
                      count + " MARKER(S) — CLICK TO TP", style);
        }

        // ── clicks ─────────────────────────────────────────────────────
        static void HandleClick(Rect map, List<Marker> markers)
        {
            var e = Event.current;
            if (e == null) return;
            if (e.type != EventType.MouseDown || e.button != 0) return;
            if (!map.Contains(e.mousePosition)) return;

            float u = (e.mousePosition.x - map.x) / map.width;
            float v = 1f - (e.mousePosition.y - map.y) / map.height;
            float wx = MinX + u * (MaxX - MinX);
            float wz = MinZ + v * (MaxZ - MinZ);
            e.Use();

            Marker? hit = null;
            float best = 14f;
            for (int i = 0; i < markers.Count; i++)
            {
                float mu = (markers[i].Pos.x - MinX) / (MaxX - MinX);
                float mv = (markers[i].Pos.z - MinZ) / (MaxZ - MinZ);
                if (mu < 0f || mu > 1f || mv < 0f || mv > 1f) continue;
                float mx = map.x + mu * map.width;
                float my = map.y + (1f - mv) * map.height;
                float d  = Vector2.Distance(e.mousePosition, new Vector2(mx, my));
                if (d < best) { best = d; hit = markers[i]; }
            }

            if (hit.HasValue)
            {
                var m = hit.Value;
                if (m.TeleportIndex >= 0) Teleport.TeleportTo(m.TeleportIndex);
                else Goto(m.Pos);
                return;
            }
            Goto(new Vector3(wx, HeightAt(wx, wz) + 1f, wz));
        }

        static float HeightAt(float x, float z)
        {
            if (_heights == null) return 5f;
            int gx = (int)Mathf.Clamp((x - MinX) / (MaxX - MinX) * Grid, 0, Grid - 1);
            int gz = (int)Mathf.Clamp((z - MinZ) / (MaxZ - MinZ) * Grid, 0, Grid - 1);
            return _heights[gz * Grid + gx];
        }

        static void Goto(Vector3 pos)
        {
            try
            {
                var local = LocalPlayer._instance;
                if (local == null) { Features.LastResult = "Needs a loaded world"; return; }
                local.Goto(pos);
                Features.LastResult = "Teleported (" + pos.x.ToString("0") + ", "
                                      + pos.z.ToString("0") + ")";
            }
            catch (Exception ex)
            {
                Features.LastResult = "Teleport failed";
                Diag.Warn("map goto: " + ex.Message);
            }
        }

        static void DrawProgress(Rect pane)
        {
            var style = new GUIStyle(Theme.Lede);
            style.alignment = TextAnchor.MiddleCenter;
            GUI.Label(new Rect(pane.x, pane.y + pane.height * 0.4f - 20f,
                               pane.width, 40),
                      "SAMPLING ISLAND  " + (Progress * 100f).ToString("0") + "%",
                      style);
            var bar = new Rect(pane.x + pane.width * 0.2f,
                               pane.y + pane.height * 0.5f,
                               pane.width * 0.6f, 6f);
            Theme.Fill(bar, Theme.FieldBg);
            Theme.Fill(new Rect(bar.x, bar.y, bar.width * Progress, bar.height),
                       Theme.RustBright);
        }
    }
}
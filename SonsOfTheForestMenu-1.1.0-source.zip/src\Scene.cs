// ═══════════════════════════════════════════════════════════════════════════
//  Scene.cs · Bolt prefab spawning and cutscene playback
//  Sons of the Forest Menu — cyberfox1337x
// ═══════════════════════════════════════════════════════════════════════════

using Bolt;
using Sons.Cutscenes;
using TheForest.Utils;
using UnityEngine;

namespace Cyberfox1337x.SonsOfTheForest;

/// <summary>
/// Prefab spawning and cutscene playback.
///
/// <para>The community wiki documents these as the console commands
/// <c>addprefab</c> and <c>playcutscene</c>, but neither is in the game's
/// <c>DebugConsole</c> table — they live on the separate F1 cheat console. So
/// instead of sending text at a console that will not answer, both route
/// through the real APIs:</para>
///
/// <list type="bullet">
///   <item>prefabs — <c>BoltPrefabs.X</c> yields a <see cref="PrefabId"/>,
///         spawned with <c>BoltNetwork.Instantiate</c>.</item>
///   <item>cutscenes — <c>CutsceneManager.QueueNextCutscene</c>, skipped with
///         <c>SkipActiveCutscene</c>.</item>
/// </list>
///
/// <para>Verified against the interop metadata: <c>BoltPrefabs</c> exposes 694
/// static prefab getters, and <c>CutsceneManager</c> has
/// <c>QueueNextCutscene(String) -&gt; Boolean</c>.</para>
/// </summary>
[Cyberfox1337x("prefabs and cutscenes")]
internal static class Scene
{
    /// <summary>Metres in front of the player to place a spawned prefab.</summary>
    const float SpawnForwardOffset = 3f;

    /// <summary>Metres above the player, so props do not spawn inside terrain.</summary>
    const float SpawnUpOffset = 1f;

    /// <summary>
    /// One spawnable prop: display label paired with the accessor that resolves
    /// its Bolt prefab id.
    ///
    /// <para>A table of label+getter rather than parallel arrays and a switch —
    /// the two halves cannot drift out of sync, and adding a prop is one line.
    /// Only entries verified to exist as <c>BoltPrefabs</c> getters are listed;
    /// the wiki's editor-only names (CutTree, MuzzleFlash, PoolToy, …) are not
    /// in the Bolt prefab table and were left out.</para>
    /// </summary>
    internal readonly struct PrefabEntry
    {
        internal string Label { get; }
        internal System.Func<PrefabId> Resolve { get; }

        internal PrefabEntry(string label, System.Func<PrefabId> resolve)
        {
            Label = label;
            Resolve = resolve;
        }
    }

    /// <summary>Curated spawnable props, in menu order.</summary>
    internal static readonly PrefabEntry[] Prefabs =
    {
        new("Golf Cart",           () => BoltPrefabs.GolfCart),
        new("Snow Cart",           () => BoltPrefabs.SnowGolfCart),
        new("Weapon Case Black",   () => BoltPrefabs.WeaponCaseBlack),
        new("Weapon Case Blue",    () => BoltPrefabs.WeaponCaseBlue),
        new("Weapon Case Green",   () => BoltPrefabs.WeaponCaseGreen),
        new("Weapon Case Orange",  () => BoltPrefabs.WeaponCaseOrange),
        new("Suitcase Blue",       () => BoltPrefabs.SuitcaseBlueContainer),
        new("Suitcase Red",        () => BoltPrefabs.SuitcaseRedContainer),
        new("Storage Crate A",     () => BoltPrefabs.StorageCrateA),
        new("Storage Crate B",     () => BoltPrefabs.StorageCrateB),
        new("Wooden Crate",        () => BoltPrefabs.WoodenCrateContainer),
        new("Log Sled",            () => BoltPrefabs.BasicLogSledStructure),
        new("Propane Burner",      () => BoltPrefabs.PropaneBurner),
        new("Radio (bar)",         () => BoltPrefabs.BarRadio),
        new("Radio (gym)",         () => BoltPrefabs.GymRadio),
        new("Radio (indoors)",     () => BoltPrefabs.RadioIndoors),
        new("Turtle Egg",          () => BoltPrefabs.TurtleEggPickup),
        new("Dead Squirrel",       () => BoltPrefabs.DeadSquirrel),
        new("Dead Rabbit",         () => BoltPrefabs.DeadRabbit),
        new("Solafite Armour",     () => BoltPrefabs.SolafiteArmourPickup),
        new("Golden Armour",       () => BoltPrefabs.GoldenArmourPickup),
        new("Shiitake Mushrooms",  () => BoltPrefabs.ShiitakeMushroomPickup),
    };

    /// <summary>Cutscenes the wiki marks as working, label paired with id.</summary>
    internal static readonly (string Label, string Name)[] Cutscenes =
    {
        ("Ocean Crash", "HelicopterOceanCrashCutscene"),
        ("Snow Crash",  "HelicopterSnowCrashCutscene"),
        ("Tree Crash",  "HelicopterTreeCrashCutscene"),
        ("Sleeping",    "SleepingCutscene"),
    };

    // ── prefabs ─────────────────────────────────────────────────────────

    /// <summary>
    /// Spawns the indexed prop a few metres in front of the player, matching
    /// the player's own rotation so vehicles face the way they are looking.
    /// </summary>
    internal static void SpawnPrefab(int index)
    {
        if (!Game.InWorld)
        {
            Features.LastResult = "Needs a loaded world";
            return;
        }

        if (index < 0 || index >= Prefabs.Length) return;

        PrefabEntry entry = Prefabs[index];

        bool spawned = Safe.Run("scene.spawn-prefab", entry, prefab =>
        {
            LocalPlayer local = LocalPlayer._instance;
            if (local == null) return;

            Transform origin = local.transform;
            Vector3 position = origin.position
                             + origin.forward * SpawnForwardOffset
                             + Vector3.up * SpawnUpOffset;

            BoltNetwork.Instantiate(prefab.Resolve(), position, origin.rotation);
        }, Noise.Warn);

        Features.LastResult = spawned
            ? $"Spawned {entry.Label}"
            : $"Could not spawn {entry.Label}";
    }

    // ── cutscenes ───────────────────────────────────────────────────────

    /// <summary>
    /// Queues a cutscene by name. The name is passed straight through, because
    /// the SPAWN tab offers a free-text field alongside the curated list and
    /// the game is the only authority on which names it knows.
    /// </summary>
    /// <returns>False if no world is loaded or the game rejected the name.</returns>
    internal static bool PlayCutscene(string name)
    {
        if (!Game.InWorld)
        {
            Features.LastResult = "Needs a loaded world";
            return false;
        }

        if (string.IsNullOrWhiteSpace(name)) return false;

        bool queued = Safe.Get("scene.queue-cutscene", name,
            CutsceneManager.QueueNextCutscene, fallback: false, noise: Noise.Warn);

        Features.LastResult = queued
            ? $"Queued cutscene {name}"
            : $"Unknown cutscene: {name}";

        return queued;
    }

    /// <summary>Cuts the running cutscene short.</summary>
    internal static void SkipCutscene()
    {
        bool skipped = Safe.Run("scene.skip-cutscene",
            CutsceneManager.SkipActiveCutscene, Noise.Warn);

        Features.LastResult = skipped ? "Cutscene skipped" : "Skip failed";
    }

    /// <summary>
    /// Name of the cutscene currently playing, or null when none is.
    /// Transient noise: the manager legitimately does not exist outside a
    /// loaded world, and the SPAWN tab polls this while drawing.
    /// </summary>
    internal static string ActiveCutscene()
    {
        Cutscene active = Safe.Get("scene.active-cutscene",
            () => CutsceneManager.GetActiveCutScene());

        return active == null ? null : $"Playing: {NameOf(active)}";
    }

    /// <summary>
    /// Best-effort display name. The GameObject name is the readable one; the
    /// component name is the fallback when the object is already being torn
    /// down, which is common at exactly the moment a cutscene ends.
    /// </summary>
    static string NameOf(Cutscene cutscene)
    {
        string objectName = Safe.Get("scene.cutscene-object-name", cutscene,
            c => c.gameObject == null ? null : c.gameObject.name);

        if (!string.IsNullOrEmpty(objectName)) return objectName;

        return Safe.Get("scene.cutscene-name", cutscene, c => c.name, fallback: "?");
    }
}
